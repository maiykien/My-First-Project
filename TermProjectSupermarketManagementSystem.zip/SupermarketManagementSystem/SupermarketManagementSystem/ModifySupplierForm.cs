﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SupermarketManagementSystem
{
    public partial class ModifySupplierForm : Form
    {

        SupplierForm supplierForm;
        public ModifySupplierForm()
        {
            InitializeComponent();
            LoadSupplierFromDatabase();
        }

        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=SupermarketProductManagementSystem.accdb";


        private void DeleteSupplierForm_Load(object sender, EventArgs e)
        {
            LoadSupplierFromDatabase();
            LoadCategory();
        }

        private void LoadSupplierFromDatabase()
        {
            string query = "SELECT * FROM Suppliers";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                conn.Open();
                using (OleDbDataAdapter adap = new OleDbDataAdapter(query, conn))
                {

                    DataTable dt = new DataTable();
                    adap.Fill(dt);
                    dgvSupplier.DataSource = dt;
                }
            }
        }

        private void LoadCategory()
        {
            string[] nameCategogy = { "Select a Category", "Fruits", "Bakery", "Dairy", "Frozen Food", "Vegetables", "Pantry", "Meat" };
            foreach (string name in nameCategogy)
            {
                cboCategory.Items.Add(name);
            }

            cboCategory.SelectedIndex = 0;
        }

        private int SupplierID;
        private void dgvSupplier_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvSupplier.SelectedRows.Count > 0)
            {

                DataGridViewRow row = dgvSupplier.SelectedRows[0];
                SupplierID = Convert.ToInt32(row.Cells["SupplierID"].Value);
                txtSupplierName.Text = row.Cells["SupplierName"].Value.ToString();
                txtContactNumber.Text = row.Cells["ContactNumber"].Value.ToString();
                txtEmail.Text = row.Cells["SupplierEmail"].Value.ToString();
                txtAddress.Text = row.Cells["SupplierAddress"].Value.ToString();
            }
        }
        private void btnSaveChange_Click(object sender, EventArgs e)
        {
            Supplier sup = new Supplier();

            sup.SupplierName = txtSupplierName.Text;
            sup.ContactNumber = txtContactNumber.Text;
            sup.SupplierEmail = txtEmail.Text;
            sup.SupplierAddress = txtAddress.Text;
            sup.SupplierCategory = cboCategory.SelectedItem.ToString();

            var confirmResult = MessageBox.Show($" Do you want to save it ?", "Confirm Save", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            try
            {
                if (confirmResult == DialogResult.Yes)
                {
                    sup.UpdateSupplierToDatabase(SupplierID);
                    LoadSupplierFromDatabase();
                    ClearSupplierFormFields();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while saving the supplier: " + ex.Message);
            }
        }
        private void ClearSupplierFormFields()
        {
            txtSupplierName.Clear();
            txtContactNumber.Clear();
            txtEmail.Clear();
            txtAddress.Clear();

        }
        public void btnReturnSupplier_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
