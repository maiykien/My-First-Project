﻿namespace SupermarketManagementSystem
{
    partial class RegisterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            btnCancel = new Button();
            btnRegister = new Button();
            txtPassword = new TextBox();
            txtUserName = new TextBox();
            lblPassword = new Label();
            lblUserName = new Label();
            txtConfirmPassword = new TextBox();
            txtEmail = new TextBox();
            lblConfirmPassWord = new Label();
            label3 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            label1.Location = new Point(338, 56);
            label1.Name = "label1";
            label1.Size = new Size(204, 30);
            label1.TabIndex = 0;
            label1.Text = "Register New User";
            // 
            // btnCancel
            // 
            btnCancel.BackColor = Color.FromArgb(255, 255, 128);
            btnCancel.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnCancel.Location = new Point(483, 478);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(146, 46);
            btnCancel.TabIndex = 13;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = false;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnRegister
            // 
            btnRegister.BackColor = Color.Cyan;
            btnRegister.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnRegister.Location = new Point(285, 478);
            btnRegister.Name = "btnRegister";
            btnRegister.Size = new Size(146, 46);
            btnRegister.TabIndex = 12;
            btnRegister.Text = "Register";
            btnRegister.UseVisualStyleBackColor = false;
            btnRegister.Click += btnRegister_Click;
            // 
            // txtPassword
            // 
            txtPassword.BackColor = Color.FromArgb(255, 255, 128);
            txtPassword.BorderStyle = BorderStyle.FixedSingle;
            txtPassword.Font = new Font("Segoe UI", 11F, FontStyle.Underline);
            txtPassword.Location = new Point(261, 222);
            txtPassword.Name = "txtPassword";
            txtPassword.PasswordChar = '*';
            txtPassword.Size = new Size(368, 32);
            txtPassword.TabIndex = 11;
            // 
            // txtUserName
            // 
            txtUserName.BackColor = Color.FromArgb(255, 255, 192);
            txtUserName.BorderStyle = BorderStyle.FixedSingle;
            txtUserName.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            txtUserName.Location = new Point(261, 146);
            txtUserName.Name = "txtUserName";
            txtUserName.Size = new Size(368, 32);
            txtUserName.TabIndex = 10;
            // 
            // lblPassword
            // 
            lblPassword.AutoSize = true;
            lblPassword.Font = new Font("Segoe UI Symbol", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblPassword.Location = new Point(154, 221);
            lblPassword.Name = "lblPassword";
            lblPassword.Size = new Size(101, 25);
            lblPassword.TabIndex = 9;
            lblPassword.Text = "Password:";
            // 
            // lblUserName
            // 
            lblUserName.AutoSize = true;
            lblUserName.Font = new Font("Segoe UI Symbol", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblUserName.Location = new Point(142, 145);
            lblUserName.Name = "lblUserName";
            lblUserName.Size = new Size(113, 25);
            lblUserName.TabIndex = 8;
            lblUserName.Text = "User Name:";
            // 
            // txtConfirmPassword
            // 
            txtConfirmPassword.BackColor = Color.FromArgb(255, 255, 128);
            txtConfirmPassword.BorderStyle = BorderStyle.FixedSingle;
            txtConfirmPassword.Font = new Font("Segoe UI", 11F, FontStyle.Underline);
            txtConfirmPassword.Location = new Point(261, 288);
            txtConfirmPassword.Name = "txtConfirmPassword";
            txtConfirmPassword.PasswordChar = '*';
            txtConfirmPassword.Size = new Size(368, 32);
            txtConfirmPassword.TabIndex = 14;
            // 
            // txtEmail
            // 
            txtEmail.BackColor = Color.FromArgb(255, 255, 128);
            txtEmail.BorderStyle = BorderStyle.FixedSingle;
            txtEmail.Font = new Font("Segoe UI", 11F, FontStyle.Underline);
            txtEmail.Location = new Point(261, 360);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(368, 32);
            txtEmail.TabIndex = 15;
            // 
            // lblConfirmPassWord
            // 
            lblConfirmPassWord.AutoSize = true;
            lblConfirmPassWord.Font = new Font("Segoe UI Symbol", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblConfirmPassWord.Location = new Point(77, 290);
            lblConfirmPassWord.Name = "lblConfirmPassWord";
            lblConfirmPassWord.Size = new Size(178, 25);
            lblConfirmPassWord.TabIndex = 16;
            lblConfirmPassWord.Text = "Confirm Password:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Symbol", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(191, 360);
            label3.Name = "label3";
            label3.Size = new Size(64, 25);
            label3.TabIndex = 17;
            label3.Text = "Email:";
            // 
            // RegisterForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(974, 599);
            Controls.Add(label3);
            Controls.Add(lblConfirmPassWord);
            Controls.Add(txtEmail);
            Controls.Add(txtConfirmPassword);
            Controls.Add(btnCancel);
            Controls.Add(btnRegister);
            Controls.Add(txtPassword);
            Controls.Add(txtUserName);
            Controls.Add(lblPassword);
            Controls.Add(lblUserName);
            Controls.Add(label1);
            Name = "RegisterForm";
            Text = "RegisterForm";
            Load += RegisterForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button btnCancel;
        private Button btnRegister;
        private TextBox txtPassword;
        private TextBox txtUserName;
        private Label lblPassword;
        private Label lblUserName;
        private TextBox txtConfirmPassword;
        private TextBox txtEmail;
        private Label lblConfirmPassWord;
        private Label label3;
    }
}