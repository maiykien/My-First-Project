﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SupermarketManagementSystem
{
    class Product
    {
        // the Prvate field to store product properties. 
        private string productName; // Product Name
        private string productDescription; // Description of the Product
        private double productPrice; // Price of the product
        private int stockLevel; // Stock Level
        private string productCategory; // Category of the product
        private string productImageURL; // Product Image
        private string supplierName; // Product's supplier

        // Public property for productName with getter and setter.
        public string ProductName
        {

            get { return productName; }
            set { productName = value; }
        }

        //  Getter and setter for ProductDescription
        public string ProductDescription
        {
            get { return productDescription; }
            set { productDescription = value; }
        }


        //  Getter and setter for ProductPrice
        public double ProductPrice
        {
            get { return productPrice; }
            set { productPrice = value; }
        }

        //  Getter and setter for StockLevel

        public int StockLevel
        {
            get { return stockLevel; }
            set { stockLevel = value; }
        }

        //  Getter and setter for ProductCategory
        public string ProductCategory
        {
            get { return productCategory; }
            set { productCategory = value; }
        }

        //  Getter and setter for ProductImageURL

        public string ProductImageURL
        {
            get { return productImageURL; }
            set { productImageURL = value; }
        }


        //  Getter and setter for SupplierName
        public string SupplierName
        {
            get { return supplierName; }
            set { supplierName = value; }
        }

        public Product()
        {
        }


        // This is constructor to initlialize a product with specific  values. 
        public Product(string productName, string productDescription, double productPrice, int stockLevel, string productCategory, string productImageURL)
        {
            this.productName = productName;
            this.productDescription = productDescription;
            this.productPrice = productPrice;
            this.stockLevel = stockLevel;
            this.productCategory = productCategory;
            this.productImageURL = productImageURL;
        }

        // Initialize the connectionString.
        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=SupermarketProductManagementSystem.accdb";


        // I need to load all the product into the data griad
        public void AddProductToDatabase(Product product)
        {
            string query = "INSERT INTO Products(ProductName, ProductDescription, Price, StockLevel, Category, ProductImageURL)" +
                 "VALUES(@ProductName, @ProductDescription, @Price, @StockLevel, @Category, @ProductImageURL)";

            try
            {
                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    conn.Open();
                    // Create a command for executing the query.
                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        // Create a command for executing the query
                        cmd.Parameters.AddWithValue("@ProductName", ProductName);
                        cmd.Parameters.AddWithValue("@ProductDescription", ProductDescription);
                        cmd.Parameters.AddWithValue("@Price", ProductPrice);
                        cmd.Parameters.AddWithValue("@StockLevel", StockLevel);
                        cmd.Parameters.AddWithValue("@Category", ProductCategory);
                        cmd.Parameters.AddWithValue("@ProductImageURL", ProductImageURL);

                        // I will process to Execute the query
                        cmd.ExecuteNonQuery();
                        MessageBox.Show(" Saved Product into database successfully! ");
                        conn.Close();

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while saving product!!" + ex.Message);
            }
        }

        // Preventing the case we will add the same productname in the Database 
        // and was made the confused for the user.
        // Using the method true/false to detect is same or not same.
        public bool IsDuplicateName(string productName)
        {
            bool result = false;

            // SQL query to count occurrences of the product name.
            string query = "SELECT COUNT(*) FROM Products WHERE ProductName = @ProductName";

            try
            {
                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    // Open a connection and execute the query
                    conn.Open();
                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@ProductName", productName);

                        // check the count of duplicate in the database.
                        int count = (int)cmd.ExecuteScalar();

                        // Check the condition if the count > 0, there is duplicate. 
                        result = count > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                // Display an error message if an exception occurs
                MessageBox.Show("Error  checking for duplicates: " + ex.Message);

            }
            return result;
        }

        public DataTable LoadDataFromDatabase(string category)
        {
            string query = "SELECT * FROM Products";

            try
            {
                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    conn.Open();
                    using (OleDbDataAdapter adapter = new OleDbDataAdapter(query, conn))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt); // Fill the DataTable with query results
                        return dt; // Return the populated DataTable
                    }
                }
            }
            catch (Exception ex)
            {
                // Show an error message if any exception occurs during the operation. 
                MessageBox.Show("Error loading data from the database: " + ex.Message, "Error");
                return null;  // Return null instead of an integer on error
            }
        }

        public DataTable LoadProductByCategory(string category)
        {
            // Query the statement to load all the products based on Category
            string query = "SELECT * FROM Products WHERE Category = ?";

            try
            {
                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    conn.Open();
                    // Using OLEDBADAPTER to execute the query and populate  a database
                    using (OleDbDataAdapter adapter = new OleDbDataAdapter(query, conn))
                    {
                        // Adding the parameter using OleDbParameter for OleDbCommand
                        adapter.SelectCommand.Parameters.AddWithValue("?", category);

                        DataTable dt = new DataTable();
                        adapter.Fill(dt); // Fill the DataTable with data
                        return dt; // Return the populated DataTable
                    }
                }
            }
            catch (Exception ex)
            {
                // Show an error message if any exception occurs during the operation.
                MessageBox.Show("Error loading data into the data grid view: " + ex.Message, "Error");
                return null; // Return the populated DataTable
            }
            
        }

        // This method To Save Product into the database.
        public void SaveChangeProductToDatabase(string productName)
        {
            // Query to update the product details in the database for the given product name.
            string query = "UPDATE Products SET ProductDescription = @ProductDescription, Price = @Price, StockLevel = @StockLevel, ProductImageURL = @ProductImageURL WHERE ProductName = @ProductName";

            try
            {

                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    conn.Open();
                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        //Bind the paramters with the respective values.
                        cmd.Parameters.AddWithValue("@ProductDesciption", productDescription);
                        cmd.Parameters.AddWithValue("@Price", ProductPrice);
                        cmd.Parameters.AddWithValue("@StockLevel", StockLevel);
                        cmd.Parameters.AddWithValue("@ProductImageURL", ProductImageURL);
                        cmd.Parameters.AddWithValue("@ProductName", productName);
                        cmd.ExecuteNonQuery();

                        MessageBox.Show("Saved Change Successfully!");
                    }
                }
            }
            catch (Exception ex) 
            {
                // That would be showing the error if any exception occurs during the operation. 
                MessageBox.Show("Error to save to Database: " + ex.Message);
            }
        }

        // Detele Product from the database and update datagrid view. 
        public void DeleteProductFromDatabase(string productName)
        {
            // Query to delete the product with the given name from the Product table
            string query = "DELETE FROM Products WHERE ProductName = @ProductName";

            try
            {
                // Create the connection to the database using the connection string.
                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    conn.Open(); // Open the database connection.
                    // Create an OleDbCommand to execute the SQL query.
                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        // Bind the product name parameter to the query. 
                        cmd.Parameters.AddWithValue("@ProductName", productName);
                        // Execute the command to delete the product form database.
                        cmd.ExecuteNonQuery();
                        // Display a success message to inform the user. 
                        MessageBox.Show($"Product '{productName}' deleted successfully!");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting product from database: " + ex.Message);
            }
        }
        // I wrote this method for update supplier name by category.
        public void UpdateSupplierNamesByCategory()
        {
            //  Get supplier names and their categories from the Suppliers table
            string selectQuery = @"SELECT Category, SupplierName FROM Suppliers";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                conn.Open(); // Open the database connection

                // Load the supplier-category mapping into a DataTable
                DataTable supplierCategoryTable = new DataTable();
                using (OleDbDataAdapter adapter = new OleDbDataAdapter(selectQuery, conn))
                {
                    adapter.Fill(supplierCategoryTable);
                }
                // Iterate through each supplier-category pair. 
                foreach (DataRow row in supplierCategoryTable.Rows)
                {
                    string category = row["Category"].ToString(); // Get the category
                    string supplierName = row["SupplierName"].ToString(); // Get the supplier name.

                    // Query to update the SupplierName field in the Products Table
                    string updateQuery = @"
                    UPDATE Products
                    SET SupplierName = @SupplierName
                    WHERE Category = @Category AND SupplierName IS NULL";

                    using (OleDbCommand updateCmd = new OleDbCommand(updateQuery, conn))
                    {
                        // Bind the parameters with the respective values
                        updateCmd.Parameters.AddWithValue("@SupplierName", supplierName);
                        updateCmd.Parameters.AddWithValue("@Category", category);
                        // Execute the update command
                        updateCmd.ExecuteNonQuery();
                    }
                }
            }
        }
    }
}


