﻿namespace SupermarketManagementSystem
{
    partial class UpdatePasswordForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtNewPassword = new TextBox();
            lblPassword = new Label();
            txtConfirmPassword = new TextBox();
            txtCurrentPassword = new TextBox();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            btnUpdateNewPassword = new Button();
            btnReturnUser = new Button();
            SuspendLayout();
            // 
            // txtNewPassword
            // 
            txtNewPassword.BackColor = SystemColors.InactiveCaption;
            txtNewPassword.Location = new Point(184, 142);
            txtNewPassword.Name = "txtNewPassword";
            txtNewPassword.Size = new Size(280, 27);
            txtNewPassword.TabIndex = 37;
            // 
            // lblPassword
            // 
            lblPassword.AutoSize = true;
            lblPassword.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblPassword.Location = new Point(84, 143);
            lblPassword.Name = "lblPassword";
            lblPassword.Size = new Size(90, 23);
            lblPassword.TabIndex = 36;
            lblPassword.Text = "Password:";
            // 
            // txtConfirmPassword
            // 
            txtConfirmPassword.BackColor = SystemColors.InactiveCaption;
            txtConfirmPassword.Location = new Point(184, 188);
            txtConfirmPassword.Name = "txtConfirmPassword";
            txtConfirmPassword.Size = new Size(280, 27);
            txtConfirmPassword.TabIndex = 34;
            // 
            // txtCurrentPassword
            // 
            txtCurrentPassword.BackColor = SystemColors.InactiveCaption;
            txtCurrentPassword.BorderStyle = BorderStyle.FixedSingle;
            txtCurrentPassword.Location = new Point(184, 94);
            txtCurrentPassword.Name = "txtCurrentPassword";
            txtCurrentPassword.ReadOnly = true;
            txtCurrentPassword.Size = new Size(280, 27);
            txtCurrentPassword.TabIndex = 33;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label3.Location = new Point(17, 192);
            label3.Name = "label3";
            label3.Size = new Size(161, 23);
            label3.TabIndex = 31;
            label3.Text = "Confirm Password:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label2.Location = new Point(22, 98);
            label2.Name = "label2";
            label2.Size = new Size(156, 23);
            label2.TabIndex = 30;
            label2.Text = "Current Password:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Black", 13F);
            label1.Location = new Point(203, 24);
            label1.Name = "label1";
            label1.Size = new Size(201, 30);
            label1.TabIndex = 38;
            label1.Text = "Update Password";
            // 
            // btnUpdateNewPassword
            // 
            btnUpdateNewPassword.BackColor = Color.Lime;
            btnUpdateNewPassword.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnUpdateNewPassword.ForeColor = Color.Black;
            btnUpdateNewPassword.Location = new Point(32, 270);
            btnUpdateNewPassword.Name = "btnUpdateNewPassword";
            btnUpdateNewPassword.Size = new Size(239, 47);
            btnUpdateNewPassword.TabIndex = 39;
            btnUpdateNewPassword.Text = "Update New Password";
            btnUpdateNewPassword.UseVisualStyleBackColor = false;
            btnUpdateNewPassword.Click += btnUpdateNewPassword_Click;
            // 
            // btnReturnUser
            // 
            btnReturnUser.BackColor = Color.Magenta;
            btnReturnUser.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnReturnUser.ForeColor = Color.BlanchedAlmond;
            btnReturnUser.Location = new Point(303, 270);
            btnReturnUser.Name = "btnReturnUser";
            btnReturnUser.Size = new Size(239, 47);
            btnReturnUser.TabIndex = 40;
            btnReturnUser.Text = "Return User Form";
            btnReturnUser.UseVisualStyleBackColor = false;
            btnReturnUser.Click += btnReturnUser_Click;
            // 
            // UpdatePasswordForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.CadetBlue;
            ClientSize = new Size(703, 434);
            Controls.Add(btnReturnUser);
            Controls.Add(btnUpdateNewPassword);
            Controls.Add(label1);
            Controls.Add(txtNewPassword);
            Controls.Add(lblPassword);
            Controls.Add(txtConfirmPassword);
            Controls.Add(txtCurrentPassword);
            Controls.Add(label3);
            Controls.Add(label2);
            Name = "UpdatePasswordForm";
            Text = "UpdatePasswordForm";
            Load += UpdatePasswordForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtNewPassword;
        private Label lblPassword;
        private TextBox txtConfirmPassword;
        private TextBox txtCurrentPassword;
        private Label label3;
        private Label label2;
        private Label label1;
        private Button btnUpdateNewPassword;
        private Button btnReturnUser;
    }
}