﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SupermarketManagementSystem
{
    public partial class DeleteForm : Form
    {
        public DeleteForm()// constructor for the "deleteform" class
        {
            InitializeComponent(); // Initializes the form's components
            LoadCategory(); // Populates the category dropdown on form Load
            LoadProductToDatagridView(); // Loads products into the DataGridView. 
        }
        private void DeleteForm_Load(object sender, EventArgs e)
        {
        }
        private void LoadCategory() // Loads predefined categories into the category dropdown. 
        {
            string[] nameCategogy = { "Select a Category", "Fruits", "Bakery", "Dairy", "Frozen Food", "Vegetables", "Pantry", "Meat" };
            foreach (string name in nameCategogy)
            {
                cboCategory.Items.Add(name); // Adds each category name to the dropdown
            }

            cboCategory.SelectedIndex = 0; // Sets the default selected category to the first time. 
        }
        private void LoadProductToDatagridView() // this method to load all the products into the DataGridView. 
        {

            Product pro = new Product(); // Creates an instance of the "Product" class.
            DataTable dataTable = pro.LoadDataFromDatabase("Category"); // Retrieves data from the database. 
            dgvProductInventory.DataSource = dataTable; // Bing the data to the DataGridView. 

        }

        // Connection string for the database. 
        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=SupermarketProductManagementSystem.accdb";
        private void LoadProductFromDatabase() // Loads all products from the database into the DataGridView. 
        {
            string query = "SELECT * FROM Products";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                conn.Open(); // Opens the database connection. 
                using (OleDbDataAdapter adap = new OleDbDataAdapter(query, conn))
                {

                    DataTable dt = new DataTable(); // Create a new DataTable
                    adap.Fill(dt); // Fills the DataTable with query results. 
                    dgvProductInventory.DataSource = dt; // Binds the data to the DataGridView. 
                }
            }
        }

        private string productName;

        // Event handler for row selected changed.
        private void dgvProductInventory_SelectionChanged(object sender, EventArgs e)
        {
            // I will be check if the count of the product selected is greater than 0
            if (dgvProductInventory.SelectedRows.Count > 0)
            {
                // Intialize the DataGridViewRow
                DataGridViewRow row = dgvProductInventory.SelectedRows[0]; // Gets the selected row
                productName = row.Cells["ProductName"].Value.ToString(); // strore the data for the product name.
                txtName.Text = row.Cells["ProductName"].Value.ToString(); // Display product name in the text box
                txtDescription2.Text = row.Cells["ProductDescription"].Value.ToString(); // Display the product desciption in the textbox. 
                txtPrice2.Text = row.Cells["Price"].Value.ToString(); // Display the price in the TextBox. 
                txtStockLevel2.Text = row.Cells["StockLevel"].Value.ToString(); // Display  in the stock level.
                txtImageURL.Text = row.Cells["ProductImageURL"].Value.ToString(); // Display the Image URL.
                string imageURL = row.Cells["ProductImageURL"].Value?.ToString(); // For getting ht image URL. 

                if (!string.IsNullOrWhiteSpace(imageURL))
                {
                    try
                    {
                        pictureBoxImage.Load(imageURL); // Try to load the image from the URL or file path
                    }
                    catch
                    {
                        // Fallback to a "Not Found" image if loading fails
                        pictureBoxImage.Image = Image.FromFile(@"Images\ImageNotFound.jpg");
                    }
                }
                else
                {
                    // Show the "Not Found" image if the URL is empty or null
                    pictureBoxImage.Image = Image.FromFile(@"Images\ImageNotFound.jpg");
                }
            }
        }

        // Event handler for the Delete button click. 
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(productName)) // Checks if a product is selected. 
            {

                var confirmResult = MessageBox.Show($"Are you sure you want to delete the product '{productName}' ?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning); // Confirmation dialog. 
                try
                {
                    if (confirmResult == DialogResult.Yes) // Would be processed if the user confirms. 
                    {

                        Product product = new Product(); // Create an instance of the "Product" class.
                        product.DeleteProductFromDatabase(productName); // Delete the product from the database.  
                        LoadProductFromDatabase(); // Reload the product data. 

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while deleting Product " + ex.Message);
                }
            }

        }

        // Event  handler
        private void btnReturn_Click(object sender, EventArgs e)
        {
            this.Close(); // Close the form. 
        }
        private void cboCategory_SelectedIndexChanged(object sender, EventArgs e) // Event handler for category selection change
        {

            string selectedItem = cboCategory.SelectedItem.ToString(); // Getting the selected category.
            Product pro = new Product(); // Create an instance of the Product class
            DataTable dataTable = pro.LoadProductByCategory(selectedItem); // Retrueve products in the selected category
            dgvProductInventory.DataSource = dataTable; // Binds the data to the DataGridView. 
       
        }


    }
}

