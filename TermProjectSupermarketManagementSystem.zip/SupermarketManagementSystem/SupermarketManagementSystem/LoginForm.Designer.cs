﻿namespace SupermarketManagementSystem
{
    partial class LoginForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            lblUserName = new Label();
            lblPassword = new Label();
            txtUserName = new TextBox();
            txtPassword = new TextBox();
            btnLogIn = new Button();
            btnRegister = new Button();
            pictureBoxLogo = new PictureBox();
            chkShowPassword = new CheckBox();
            ((System.ComponentModel.ISupportInitialize)pictureBoxLogo).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.FromArgb(192, 255, 192);
            label1.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            label1.ForeColor = Color.Red;
            label1.Location = new Point(307, 25);
            label1.Name = "label1";
            label1.Size = new Size(460, 37);
            label1.TabIndex = 0;
            label1.Text = "Supermarket Management System";
            // 
            // lblUserName
            // 
            lblUserName.AutoSize = true;
            lblUserName.Font = new Font("Segoe UI Symbol", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblUserName.Location = new Point(29, 140);
            lblUserName.Name = "lblUserName";
            lblUserName.Size = new Size(113, 25);
            lblUserName.TabIndex = 1;
            lblUserName.Text = "User Name:";
            // 
            // lblPassword
            // 
            lblPassword.AutoSize = true;
            lblPassword.Font = new Font("Segoe UI Symbol", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblPassword.Location = new Point(41, 216);
            lblPassword.Name = "lblPassword";
            lblPassword.Size = new Size(101, 25);
            lblPassword.TabIndex = 3;
            lblPassword.Text = "Password:";
            // 
            // txtUserName
            // 
            txtUserName.BackColor = Color.FromArgb(255, 255, 192);
            txtUserName.BorderStyle = BorderStyle.FixedSingle;
            txtUserName.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            txtUserName.Location = new Point(148, 141);
            txtUserName.Name = "txtUserName";
            txtUserName.Size = new Size(368, 32);
            txtUserName.TabIndex = 4;
            // 
            // txtPassword
            // 
            txtPassword.BackColor = Color.FromArgb(255, 255, 128);
            txtPassword.BorderStyle = BorderStyle.FixedSingle;
            txtPassword.Font = new Font("Segoe UI", 11F, FontStyle.Underline);
            txtPassword.Location = new Point(148, 217);
            txtPassword.Name = "txtPassword";
            txtPassword.PasswordChar = '*';
            txtPassword.Size = new Size(368, 32);
            txtPassword.TabIndex = 5;
            // 
            // btnLogIn
            // 
            btnLogIn.BackColor = Color.Cyan;
            btnLogIn.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnLogIn.Location = new Point(148, 331);
            btnLogIn.Name = "btnLogIn";
            btnLogIn.Size = new Size(146, 46);
            btnLogIn.TabIndex = 6;
            btnLogIn.Text = "Log In";
            btnLogIn.UseVisualStyleBackColor = false;
            btnLogIn.Click += btnLogIn_Click;
            btnLogIn.Enter += btnLogIn_Enter;
            // 
            // btnRegister
            // 
            btnRegister.BackColor = Color.FromArgb(255, 255, 128);
            btnRegister.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnRegister.Location = new Point(324, 331);
            btnRegister.Name = "btnRegister";
            btnRegister.Size = new Size(146, 46);
            btnRegister.TabIndex = 7;
            btnRegister.Text = "Register";
            btnRegister.UseVisualStyleBackColor = false;
            btnRegister.Click += btnRegister_Click;
            // 
            // pictureBoxLogo
            // 
            pictureBoxLogo.Location = new Point(547, 94);
            pictureBoxLogo.Name = "pictureBoxLogo";
            pictureBoxLogo.Size = new Size(520, 388);
            pictureBoxLogo.TabIndex = 8;
            pictureBoxLogo.TabStop = false;
            // 
            // chkShowPassword
            // 
            chkShowPassword.AutoSize = true;
            chkShowPassword.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            chkShowPassword.Location = new Point(148, 277);
            chkShowPassword.Name = "chkShowPassword";
            chkShowPassword.Size = new Size(156, 27);
            chkShowPassword.TabIndex = 9;
            chkShowPassword.Text = "Show Password";
            chkShowPassword.UseVisualStyleBackColor = true;
            chkShowPassword.CheckedChanged += chkShowPassword_CheckedChange;
            // 
            // LoginForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1104, 533);
            Controls.Add(chkShowPassword);
            Controls.Add(pictureBoxLogo);
            Controls.Add(btnRegister);
            Controls.Add(btnLogIn);
            Controls.Add(txtPassword);
            Controls.Add(txtUserName);
            Controls.Add(lblPassword);
            Controls.Add(lblUserName);
            Controls.Add(label1);
            Name = "LoginForm";
            Text = "Login Form";
            Load += LoginForm_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBoxLogo).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label lblUserName;
        private Label lblPassword;
        private TextBox txtUserName;
        private TextBox txtPassword;
        private Button btnLogIn;
        private Button btnRegister;
        private PictureBox pictureBoxLogo;
        private CheckBox checkBox1;
        private CheckBox chkShowPassword;
    }
}
