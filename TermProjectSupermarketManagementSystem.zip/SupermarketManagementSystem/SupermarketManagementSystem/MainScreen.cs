﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SupermarketManagementSystem
{
    public partial class MainScreen : Form
    {
        // I put the field to store the username passed to this screen. 
        string userName;

        // Constructor for the MainScreen class.
        public MainScreen(string userName)
        {
            InitializeComponent(); // Initialize the form componenet
            this.userName = userName; // I will assigne the name to the class.
            lblGreeting.Text = $"Hello, " + userName + "!"; // Just want to set the greeting label text with the user name.
            lblDate.Text = DateTime.Now.ToString("MM/dd/yyyy"); // Display the curent date in MM/dd/yyyy
        }

        // I'm create event handler for the product button click.
        private void btnProduct_Click(object sender, EventArgs e)
        {
            ProductForm productForm = new ProductForm();
            productForm.ShowDialog();
        }
        // Create the event handler for Spplier click
        private void btnSupplier_Click(object sender, EventArgs e)
        {
            SupplierForm supplierForm = new SupplierForm();
            supplierForm.ShowDialog();
        }

        // Event handler for the "Customers" button click. 

        private void btnCustomers_Click(object sender, EventArgs e)
        {
            CustomerForm customerForm = new CustomerForm();
            customerForm.ShowDialog();
        }

        
        // Event handler for the "View Customer Order" button click.
        private void btnViewCustomerOrder_Click(object sender, EventArgs e)
        {
            ViewCustomerOrderForm view = new ViewCustomerOrderForm();
            view.ShowDialog();
        }


        // Event handler for Analysis button click. 
        private void btnAnalysis_Click(object sender, EventArgs e)
        {
            CustomerProductAnalysisForm customer = new CustomerProductAnalysisForm();
            customer.ShowDialog();
        }

        // Event handler for the "Manage User Account" button click.
        private void btnMangeUserAccount_Click(object sender, EventArgs e)
        {
            ManageUserAccountForm manage = new ManageUserAccountForm();
            manage.ShowDialog();
        }


        // Event handler for the "Log Out" button click. 
        private void btnLogOut_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Thank You For Using This System!");
            Application.Exit();

        }
    }
}
