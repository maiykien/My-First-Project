﻿namespace SupermarketManagementSystem
{
    partial class ProductForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvProductInventory = new DataGridView();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            txtProductName = new TextBox();
            txtPrice = new TextBox();
            txtStockLevel = new TextBox();
            cboCategory = new ComboBox();
            label5 = new Label();
            PictureBoxProductImage = new PictureBox();
            btnAddProduct = new Button();
            btnModifyProduct = new Button();
            btnDeleteProduct = new Button();
            btnReturnDashBoard = new Button();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            txtProductImageURL = new TextBox();
            txtDescription = new TextBox();
            label9 = new Label();
            pictureBoxImage = new PictureBox();
            lblProductImage = new Label();
            btnReloadProduct = new Button();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            txtName = new TextBox();
            txtDescription2 = new TextBox();
            txtPrice2 = new TextBox();
            txtStockLevel2 = new TextBox();
            txtCategory2 = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dgvProductInventory).BeginInit();
            ((System.ComponentModel.ISupportInitialize)PictureBoxProductImage).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxImage).BeginInit();
            SuspendLayout();
            // 
            // dgvProductInventory
            // 
            dgvProductInventory.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvProductInventory.Location = new Point(12, 44);
            dgvProductInventory.Name = "dgvProductInventory";
            dgvProductInventory.ReadOnly = true;
            dgvProductInventory.RowHeadersWidth = 51;
            dgvProductInventory.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvProductInventory.Size = new Size(530, 272);
            dgvProductInventory.TabIndex = 0;
            dgvProductInventory.CellClick += dgvProductInventory_CellClick;
            dgvProductInventory.SelectionChanged += dgvProductInventory_SelectionChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.FromArgb(255, 128, 128);
            label1.Font = new Font("Segoe UI Black", 14F, FontStyle.Bold);
            label1.Location = new Point(529, 9);
            label1.Name = "label1";
            label1.Size = new Size(361, 32);
            label1.TabIndex = 1;
            label1.Text = "Product Management System";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label2.Location = new Point(582, 57);
            label2.Name = "label2";
            label2.Size = new Size(130, 23);
            label2.TabIndex = 2;
            label2.Text = "Product Name:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label3.Location = new Point(650, 151);
            label3.Name = "label3";
            label3.Size = new Size(54, 23);
            label3.TabIndex = 3;
            label3.Text = "Price:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label4.Location = new Point(598, 190);
            label4.Name = "label4";
            label4.Size = new Size(106, 23);
            label4.TabIndex = 4;
            label4.Text = "Stock Level:";
            // 
            // txtProductName
            // 
            txtProductName.BackColor = SystemColors.InactiveCaption;
            txtProductName.BorderStyle = BorderStyle.FixedSingle;
            txtProductName.Location = new Point(736, 57);
            txtProductName.Name = "txtProductName";
            txtProductName.Size = new Size(280, 27);
            txtProductName.TabIndex = 5;
            // 
            // txtPrice
            // 
            txtPrice.BackColor = SystemColors.InactiveCaption;
            txtPrice.Location = new Point(736, 151);
            txtPrice.Name = "txtPrice";
            txtPrice.Size = new Size(280, 27);
            txtPrice.TabIndex = 6;
            // 
            // txtStockLevel
            // 
            txtStockLevel.BackColor = SystemColors.InactiveCaption;
            txtStockLevel.Location = new Point(736, 190);
            txtStockLevel.Name = "txtStockLevel";
            txtStockLevel.Size = new Size(280, 27);
            txtStockLevel.TabIndex = 7;
            // 
            // cboCategory
            // 
            cboCategory.BackColor = SystemColors.HighlightText;
            cboCategory.FormattingEnabled = true;
            cboCategory.Location = new Point(736, 233);
            cboCategory.Name = "cboCategory";
            cboCategory.Size = new Size(280, 28);
            cboCategory.TabIndex = 8;
            cboCategory.SelectedIndexChanged += cboCategory_SelectedIndexChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label5.Location = new Point(615, 238);
            label5.Name = "label5";
            label5.Size = new Size(89, 23);
            label5.TabIndex = 9;
            label5.Text = "Category:";
            // 
            // PictureBoxProductImage
            // 
            PictureBoxProductImage.Location = new Point(1022, 57);
            PictureBoxProductImage.Name = "PictureBoxProductImage";
            PictureBoxProductImage.Size = new Size(306, 238);
            PictureBoxProductImage.TabIndex = 10;
            PictureBoxProductImage.TabStop = false;
            // 
            // btnAddProduct
            // 
            btnAddProduct.BackColor = Color.Lime;
            btnAddProduct.ForeColor = Color.Black;
            btnAddProduct.Location = new Point(803, 322);
            btnAddProduct.Name = "btnAddProduct";
            btnAddProduct.Size = new Size(136, 43);
            btnAddProduct.TabIndex = 11;
            btnAddProduct.Text = "Add Product";
            btnAddProduct.UseVisualStyleBackColor = false;
            btnAddProduct.Click += btnAddProduct_Click;
            // 
            // btnModifyProduct
            // 
            btnModifyProduct.BackColor = Color.Yellow;
            btnModifyProduct.Location = new Point(650, 322);
            btnModifyProduct.Name = "btnModifyProduct";
            btnModifyProduct.Size = new Size(136, 43);
            btnModifyProduct.TabIndex = 12;
            btnModifyProduct.Text = "Mofidy Product";
            btnModifyProduct.UseVisualStyleBackColor = false;
            btnModifyProduct.Click += btnModifyProduct_Click;
            // 
            // btnDeleteProduct
            // 
            btnDeleteProduct.BackColor = Color.Fuchsia;
            btnDeleteProduct.Location = new Point(945, 322);
            btnDeleteProduct.Name = "btnDeleteProduct";
            btnDeleteProduct.Size = new Size(136, 43);
            btnDeleteProduct.TabIndex = 13;
            btnDeleteProduct.Text = "Delete Product";
            btnDeleteProduct.UseVisualStyleBackColor = false;
            btnDeleteProduct.Click += btnDeleteProduct_Click;
            // 
            // btnReturnDashBoard
            // 
            btnReturnDashBoard.BackColor = Color.Red;
            btnReturnDashBoard.ForeColor = Color.White;
            btnReturnDashBoard.Location = new Point(782, 530);
            btnReturnDashBoard.Name = "btnReturnDashBoard";
            btnReturnDashBoard.Size = new Size(194, 43);
            btnReturnDashBoard.TabIndex = 15;
            btnReturnDashBoard.Text = "Return to Dashboard";
            btnReturnDashBoard.UseVisualStyleBackColor = false;
            btnReturnDashBoard.Click += btnReturnDashBoard_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(638, 279);
            label6.Name = "label6";
            label6.Size = new Size(0, 20);
            label6.TabIndex = 16;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label7.Location = new Point(1111, 307);
            label7.Name = "label7";
            label7.Size = new Size(139, 23);
            label7.TabIndex = 17;
            label7.Text = "Image Category";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label8.Location = new Point(548, 272);
            label8.Name = "label8";
            label8.Size = new Size(170, 23);
            label8.TabIndex = 18;
            label8.Text = "Product Image URL:";
            // 
            // txtProductImageURL
            // 
            txtProductImageURL.BackColor = SystemColors.InactiveCaption;
            txtProductImageURL.Location = new Point(736, 272);
            txtProductImageURL.Name = "txtProductImageURL";
            txtProductImageURL.Size = new Size(280, 27);
            txtProductImageURL.TabIndex = 19;
            // 
            // txtDescription
            // 
            txtDescription.BackColor = SystemColors.InactiveCaption;
            txtDescription.Location = new Point(736, 105);
            txtDescription.Name = "txtDescription";
            txtDescription.Size = new Size(280, 27);
            txtDescription.TabIndex = 21;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label9.Location = new Point(548, 105);
            label9.Name = "label9";
            label9.Size = new Size(175, 23);
            label9.TabIndex = 20;
            label9.Text = "Product Description:";
            // 
            // pictureBoxImage
            // 
            pictureBoxImage.Location = new Point(12, 348);
            pictureBoxImage.Name = "pictureBoxImage";
            pictureBoxImage.Size = new Size(382, 266);
            pictureBoxImage.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBoxImage.TabIndex = 22;
            pictureBoxImage.TabStop = false;
            // 
            // lblProductImage
            // 
            lblProductImage.AutoSize = true;
            lblProductImage.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblProductImage.Location = new Point(12, 322);
            lblProductImage.Name = "lblProductImage";
            lblProductImage.Size = new Size(128, 23);
            lblProductImage.TabIndex = 24;
            lblProductImage.Text = "Product Image";
            // 
            // btnReloadProduct
            // 
            btnReloadProduct.BackColor = Color.MediumSlateBlue;
            btnReloadProduct.ForeColor = SystemColors.ButtonHighlight;
            btnReloadProduct.Location = new Point(803, 413);
            btnReloadProduct.Name = "btnReloadProduct";
            btnReloadProduct.Size = new Size(136, 43);
            btnReloadProduct.TabIndex = 25;
            btnReloadProduct.Text = "Reload Product";
            btnReloadProduct.UseVisualStyleBackColor = false;
            btnReloadProduct.Click += btnReloadProduct_Click;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold);
            label10.Location = new Point(400, 383);
            label10.Name = "label10";
            label10.Size = new Size(63, 20);
            label10.TabIndex = 26;
            label10.Text = "Name:";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold);
            label11.Location = new Point(400, 418);
            label11.Name = "label11";
            label11.Size = new Size(112, 20);
            label11.TabIndex = 27;
            label11.Text = "Description:";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold);
            label12.Location = new Point(408, 455);
            label12.Name = "label12";
            label12.Size = new Size(59, 20);
            label12.TabIndex = 28;
            label12.Text = "Price:";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold);
            label13.Location = new Point(400, 490);
            label13.Name = "label13";
            label13.Size = new Size(113, 20);
            label13.TabIndex = 29;
            label13.Text = "Stock Level:";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold);
            label14.Location = new Point(408, 530);
            label14.Name = "label14";
            label14.Size = new Size(90, 20);
            label14.TabIndex = 30;
            label14.Text = "Category:";
            // 
            // txtName
            // 
            txtName.BackColor = SystemColors.InactiveCaption;
            txtName.Location = new Point(518, 380);
            txtName.Name = "txtName";
            txtName.ReadOnly = true;
            txtName.Size = new Size(125, 27);
            txtName.TabIndex = 31;
            // 
            // txtDescription2
            // 
            txtDescription2.BackColor = SystemColors.InactiveCaption;
            txtDescription2.Location = new Point(518, 413);
            txtDescription2.Name = "txtDescription2";
            txtDescription2.ReadOnly = true;
            txtDescription2.Size = new Size(125, 27);
            txtDescription2.TabIndex = 32;
            // 
            // txtPrice2
            // 
            txtPrice2.BackColor = SystemColors.InactiveCaption;
            txtPrice2.Location = new Point(518, 448);
            txtPrice2.Name = "txtPrice2";
            txtPrice2.ReadOnly = true;
            txtPrice2.Size = new Size(125, 27);
            txtPrice2.TabIndex = 33;
            // 
            // txtStockLevel2
            // 
            txtStockLevel2.BackColor = SystemColors.InactiveCaption;
            txtStockLevel2.Location = new Point(518, 483);
            txtStockLevel2.Name = "txtStockLevel2";
            txtStockLevel2.ReadOnly = true;
            txtStockLevel2.Size = new Size(125, 27);
            txtStockLevel2.TabIndex = 34;
            // 
            // txtCategory2
            // 
            txtCategory2.BackColor = SystemColors.InactiveCaption;
            txtCategory2.Location = new Point(518, 523);
            txtCategory2.Name = "txtCategory2";
            txtCategory2.ReadOnly = true;
            txtCategory2.Size = new Size(125, 27);
            txtCategory2.TabIndex = 35;
            // 
            // ProductForm
            // 
            AutoScaleDimensions = new SizeF(9F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSize = true;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            BackColor = SystemColors.Highlight;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1457, 658);
            Controls.Add(txtCategory2);
            Controls.Add(txtStockLevel2);
            Controls.Add(txtPrice2);
            Controls.Add(txtDescription2);
            Controls.Add(txtName);
            Controls.Add(label14);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(btnReloadProduct);
            Controls.Add(lblProductImage);
            Controls.Add(pictureBoxImage);
            Controls.Add(txtDescription);
            Controls.Add(label9);
            Controls.Add(txtProductImageURL);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(btnReturnDashBoard);
            Controls.Add(btnDeleteProduct);
            Controls.Add(btnModifyProduct);
            Controls.Add(btnAddProduct);
            Controls.Add(PictureBoxProductImage);
            Controls.Add(label5);
            Controls.Add(cboCategory);
            Controls.Add(txtStockLevel);
            Controls.Add(txtPrice);
            Controls.Add(txtProductName);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(dgvProductInventory);
            Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            Name = "ProductForm";
            Text = "ProductFrom";
            Load += ProductFrom_Load;
            ((System.ComponentModel.ISupportInitialize)dgvProductInventory).EndInit();
            ((System.ComponentModel.ISupportInitialize)PictureBoxProductImage).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxImage).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgvProductInventory;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox txtProductName;
        private TextBox txtPrice;
        private TextBox txtStockLevel;
        private ComboBox cboCategory;
        private Label label5;
        private PictureBox PictureBoxProductImage;
        private Button btnAddProduct;
        private Button btnModifyProduct;
        private Button btnDeleteProduct;
        private Button btnReturnDashBoard;
        private Label label6;
        private Label label7;
        private Label label8;
        private TextBox txtProductImageURL;
        private TextBox txtDescription;
        private Label label9;
        private PictureBox pictureBoxImage;
        private Label lblProductImage;
        private Button btnReloadProduct;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label14;
        private TextBox txtName;
        private TextBox txtDescription2;
        private TextBox txtPrice2;
        private TextBox txtStockLevel2;
        private TextBox txtCategory2;
    }
}