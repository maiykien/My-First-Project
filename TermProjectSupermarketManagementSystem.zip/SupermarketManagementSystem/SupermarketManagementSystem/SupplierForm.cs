﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SupermarketManagementSystem
{
    public partial class SupplierForm : Form
    {
        public SupplierForm()
        {
            InitializeComponent(); // Initializes form components 
            LoadSupplierFromDatabase(); // Loads supplier data from database and display it in the form. 
            LoadCategory();  // Populate the category dropdown (combo box) with predefined categories. 
        }

        private void LoadCategory() // Populate the category combo box. 
        {
            string[] nameCategogy = { "Select a Category", "Fruits", "Bakery", "Dairy", "Frozen Food", "Vegetables", "Pantry", "Meat" };
            foreach (string name in nameCategogy) // Iterates through the categories.
            {
                cboCategory.Items.Add(name); // Adds each category to the combo box. 
            }

            cboCategory.SelectedIndex = 0; // Sets the default selected category
        }

        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=SupermarketProductManagementSystem.accdb";
        public void LoadSupplierFromDatabase() // Loads all supplier records from the database. 
        {
            string query = "SELECT * FROM Suppliers"; // SQL query to retrieve all suppliers. 

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                conn.Open();
                using (OleDbDataAdapter adap = new OleDbDataAdapter(query, conn))
                {

                    DataTable dt = new DataTable(); // Create the new Data Table
                    adap.Fill(dt); // Fills the DataTable with the query
                    dgvSupplier.DataSource = dt; // Binds the datatable to the datagridview to display data. 
                }
            }
        }
    
        private void btnAddSupplier_Click(object sender, EventArgs e)
        {
            // Collect data from the form
            string supplierName = txtSupplierName.Text; // Get the supplier name from the textbox
            string contactNumber = txtContactNumber.Text; // Get the contact Number supplier from the text box
            string supplierEmail = txtEmail.Text; // Get the supplier email from the textbox.
            string supplierAddress = txtAddress.Text; // Get the Address from the textbox
            string supplierCategory = cboCategory.SelectedItem.ToString(); // Get selected category from combo box. 

            // Create the Supplier object
            Supplier supplier = new Supplier(supplierName, contactNumber, supplierEmail, supplierAddress, supplierCategory);

            // Add the supplier to the database
            supplier.AddSupplierToDatabase(supplier);
            ClearSupplierFormFields();
            LoadSupplierFromDatabase();

        }

        private void ClearSupplierFormFields()
        {
            txtSupplierName.Clear(); // Clears the supplier name field.
            txtContactNumber.Clear(); // Clears the contact number field.
            txtEmail.Clear(); // Clears the email field.
            txtAddress.Clear(); // Clears the address field.
        }

        private void SupplierForm_Load_1(object sender, EventArgs e)
        {
        }

        private void btnEditSupplier_Click(object sender, EventArgs e)
        {
            ModifySupplierForm deleteSupplierForm = new ModifySupplierForm(); // Open the modify supplier form. 
            deleteSupplierForm.ShowDialog(); // Display the deletesupplierForm as a dialog
        }


        private void btnDeleteSupplier_Click(object sender, EventArgs e)
        {

            DeleteSupplierForm deleteSupplierForm = new DeleteSupplierForm(); // Opens the delete supplier form. 
            deleteSupplierForm.ShowDialog(); // Display the form as a dialog. 

        }

        private void btnReload_Click(object sender, EventArgs e)
        {
            // This is will call the LoadSupplier one is the button Reload is Click. 
            LoadSupplierFromDatabase();
        }

        private void btnReturnDashboard_Click(object sender, EventArgs e)
        {
            this.Close(); // Close the current form and return to the DashBoard. 
        }
    }
}
