﻿namespace SupermarketManagementSystem
{
    partial class CustomerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBoxCustomer = new PictureBox();
            label1 = new Label();
            txtPhoneNumber = new TextBox();
            label9 = new Label();
            txtCity = new TextBox();
            label8 = new Label();
            label6 = new Label();
            label5 = new Label();
            cboState = new ComboBox();
            txtAddress = new TextBox();
            txtEmail = new TextBox();
            txtCustomerName = new TextBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            txtZipCode = new TextBox();
            label7 = new Label();
            dgvCustomerView = new DataGridView();
            btnInsertCustomer = new Button();
            btnUpdateCustomer = new Button();
            btnDeleteCustomer = new Button();
            btnOrderForCustomer = new Button();
            btnReloadCustomer = new Button();
            btnReturn = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBoxCustomer).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvCustomerView).BeginInit();
            SuspendLayout();
            // 
            // pictureBoxCustomer
            // 
            pictureBoxCustomer.ErrorImage = Properties.Resources.LogoCustomer1;
            pictureBoxCustomer.Image = Properties.Resources.LogoCustomer1;
            pictureBoxCustomer.InitialImage = Properties.Resources.LogoCustomer1;
            pictureBoxCustomer.Location = new Point(894, 286);
            pictureBoxCustomer.Name = "pictureBoxCustomer";
            pictureBoxCustomer.Size = new Size(502, 311);
            pictureBoxCustomer.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBoxCustomer.TabIndex = 0;
            pictureBoxCustomer.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe Print", 14F, FontStyle.Bold);
            label1.Location = new Point(504, -13);
            label1.Name = "label1";
            label1.Size = new Size(350, 43);
            label1.TabIndex = 1;
            label1.Text = "Add Customer Information";
            // 
            // txtPhoneNumber
            // 
            txtPhoneNumber.BackColor = SystemColors.InactiveCaption;
            txtPhoneNumber.Location = new Point(193, 92);
            txtPhoneNumber.Name = "txtPhoneNumber";
            txtPhoneNumber.Size = new Size(280, 27);
            txtPhoneNumber.TabIndex = 34;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label9.Location = new Point(39, 92);
            label9.Name = "label9";
            label9.Size = new Size(136, 23);
            label9.TabIndex = 33;
            label9.Text = "Phone Number:";
            // 
            // txtCity
            // 
            txtCity.BackColor = SystemColors.InactiveCaption;
            txtCity.Location = new Point(193, 221);
            txtCity.Name = "txtCity";
            txtCity.Size = new Size(280, 27);
            txtCity.TabIndex = 32;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label8.Location = new Point(114, 263);
            label8.Name = "label8";
            label8.Size = new Size(57, 23);
            label8.TabIndex = 31;
            label8.Text = "State:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(95, 266);
            label6.Name = "label6";
            label6.Size = new Size(0, 20);
            label6.TabIndex = 30;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label5.Location = new Point(124, 225);
            label5.Name = "label5";
            label5.Size = new Size(47, 23);
            label5.TabIndex = 29;
            label5.Text = "City:";
            // 
            // cboState
            // 
            cboState.BackColor = SystemColors.HighlightText;
            cboState.FormattingEnabled = true;
            cboState.Location = new Point(193, 258);
            cboState.Name = "cboState";
            cboState.Size = new Size(280, 28);
            cboState.TabIndex = 28;
            // 
            // txtAddress
            // 
            txtAddress.BackColor = SystemColors.InactiveCaption;
            txtAddress.Location = new Point(193, 177);
            txtAddress.Name = "txtAddress";
            txtAddress.Size = new Size(280, 27);
            txtAddress.TabIndex = 27;
            // 
            // txtEmail
            // 
            txtEmail.BackColor = SystemColors.InactiveCaption;
            txtEmail.Location = new Point(193, 138);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(280, 27);
            txtEmail.TabIndex = 26;
            // 
            // txtCustomerName
            // 
            txtCustomerName.BackColor = SystemColors.InactiveCaption;
            txtCustomerName.BorderStyle = BorderStyle.FixedSingle;
            txtCustomerName.Location = new Point(193, 44);
            txtCustomerName.Name = "txtCustomerName";
            txtCustomerName.Size = new Size(280, 27);
            txtCustomerName.TabIndex = 25;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label4.Location = new Point(92, 177);
            label4.Name = "label4";
            label4.Size = new Size(79, 23);
            label4.TabIndex = 24;
            label4.Text = "Address:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label3.Location = new Point(111, 138);
            label3.Name = "label3";
            label3.Size = new Size(64, 23);
            label3.TabIndex = 23;
            label3.Text = "Email: ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label2.Location = new Point(39, 44);
            label2.Name = "label2";
            label2.Size = new Size(144, 23);
            label2.TabIndex = 22;
            label2.Text = "Customer Name:";
            // 
            // txtZipCode
            // 
            txtZipCode.BackColor = SystemColors.InactiveCaption;
            txtZipCode.Location = new Point(193, 302);
            txtZipCode.Name = "txtZipCode";
            txtZipCode.Size = new Size(280, 27);
            txtZipCode.TabIndex = 36;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label7.Location = new Point(89, 306);
            label7.Name = "label7";
            label7.Size = new Size(82, 23);
            label7.TabIndex = 35;
            label7.Text = "ZipCode:";
            // 
            // dgvCustomerView
            // 
            dgvCustomerView.BackgroundColor = Color.CadetBlue;
            dgvCustomerView.CellBorderStyle = DataGridViewCellBorderStyle.Raised;
            dgvCustomerView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvCustomerView.GridColor = SystemColors.HotTrack;
            dgvCustomerView.Location = new Point(489, 44);
            dgvCustomerView.Name = "dgvCustomerView";
            dgvCustomerView.ReadOnly = true;
            dgvCustomerView.RowHeadersWidth = 51;
            dgvCustomerView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvCustomerView.Size = new Size(907, 233);
            dgvCustomerView.TabIndex = 38;
            dgvCustomerView.SelectionChanged += dgvCustomerView_SelectionChanged;
            // 
            // btnInsertCustomer
            // 
            btnInsertCustomer.BackColor = Color.Yellow;
            btnInsertCustomer.Font = new Font("Segoe Print", 10F, FontStyle.Bold);
            btnInsertCustomer.Location = new Point(235, 356);
            btnInsertCustomer.Name = "btnInsertCustomer";
            btnInsertCustomer.Size = new Size(165, 43);
            btnInsertCustomer.TabIndex = 39;
            btnInsertCustomer.Text = "Insert Customer";
            btnInsertCustomer.UseVisualStyleBackColor = false;
            btnInsertCustomer.Click += btnInsertCustomer_Click;
            // 
            // btnUpdateCustomer
            // 
            btnUpdateCustomer.BackColor = Color.Aqua;
            btnUpdateCustomer.Font = new Font("Segoe Print", 10F, FontStyle.Bold);
            btnUpdateCustomer.Location = new Point(23, 356);
            btnUpdateCustomer.Name = "btnUpdateCustomer";
            btnUpdateCustomer.Size = new Size(190, 43);
            btnUpdateCustomer.TabIndex = 40;
            btnUpdateCustomer.Text = "Update Customer";
            btnUpdateCustomer.UseVisualStyleBackColor = false;
            btnUpdateCustomer.Click += btnUpdateCustomer_Click;
            // 
            // btnDeleteCustomer
            // 
            btnDeleteCustomer.BackColor = Color.Chartreuse;
            btnDeleteCustomer.Font = new Font("Segoe Print", 10F, FontStyle.Bold);
            btnDeleteCustomer.Location = new Point(431, 356);
            btnDeleteCustomer.Name = "btnDeleteCustomer";
            btnDeleteCustomer.Size = new Size(165, 43);
            btnDeleteCustomer.TabIndex = 41;
            btnDeleteCustomer.Text = "Delete Customer";
            btnDeleteCustomer.UseVisualStyleBackColor = false;
            btnDeleteCustomer.Click += btnDeleteCustomer_Click;
            // 
            // btnOrderForCustomer
            // 
            btnOrderForCustomer.BackColor = Color.Coral;
            btnOrderForCustomer.Font = new Font("Segoe Print", 11F, FontStyle.Bold);
            btnOrderForCustomer.ForeColor = Color.Cornsilk;
            btnOrderForCustomer.Location = new Point(64, 437);
            btnOrderForCustomer.Name = "btnOrderForCustomer";
            btnOrderForCustomer.Size = new Size(230, 43);
            btnOrderForCustomer.TabIndex = 42;
            btnOrderForCustomer.Text = "Order For Customer";
            btnOrderForCustomer.UseVisualStyleBackColor = false;
            btnOrderForCustomer.Click += btnOrderForCustomer_Click;
            // 
            // btnReloadCustomer
            // 
            btnReloadCustomer.BackColor = SystemColors.ActiveCaption;
            btnReloadCustomer.Font = new Font("Segoe Script", 11F, FontStyle.Bold);
            btnReloadCustomer.Location = new Point(671, 286);
            btnReloadCustomer.Name = "btnReloadCustomer";
            btnReloadCustomer.Size = new Size(200, 43);
            btnReloadCustomer.TabIndex = 43;
            btnReloadCustomer.Text = "Reload Database";
            btnReloadCustomer.UseVisualStyleBackColor = false;
            // 
            // btnReturn
            // 
            btnReturn.BackColor = Color.CornflowerBlue;
            btnReturn.Font = new Font("Segoe Print", 10F, FontStyle.Bold);
            btnReturn.ForeColor = Color.Cornsilk;
            btnReturn.Location = new Point(336, 437);
            btnReturn.Name = "btnReturn";
            btnReturn.Size = new Size(212, 43);
            btnReturn.TabIndex = 44;
            btnReturn.Text = "Return Main Screen";
            btnReturn.UseVisualStyleBackColor = false;
            btnReturn.Click += btnReturn_Click;
            // 
            // CustomerForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientActiveCaption;
            ClientSize = new Size(1448, 598);
            Controls.Add(btnReturn);
            Controls.Add(btnReloadCustomer);
            Controls.Add(btnOrderForCustomer);
            Controls.Add(btnDeleteCustomer);
            Controls.Add(btnUpdateCustomer);
            Controls.Add(btnInsertCustomer);
            Controls.Add(dgvCustomerView);
            Controls.Add(txtZipCode);
            Controls.Add(label7);
            Controls.Add(txtPhoneNumber);
            Controls.Add(label9);
            Controls.Add(txtCity);
            Controls.Add(label8);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(cboState);
            Controls.Add(txtAddress);
            Controls.Add(txtEmail);
            Controls.Add(txtCustomerName);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(pictureBoxCustomer);
            Name = "CustomerForm";
            Text = "CustomerForm";
            Load += CustomerForm_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBoxCustomer).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvCustomerView).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBoxCustomer;
        private Label label1;
        private TextBox txtPhoneNumber;
        private Label label9;
        private TextBox txtCity;
        private Label label8;
        private Label label6;
        private Label label5;
        private ComboBox cboState;
        private TextBox txtAddress;
        private TextBox txtEmail;
        private TextBox txtCustomerName;
        private Label label4;
        private Label label3;
        private Label label2;
        private TextBox txtZipCode;
        private Label label7;
        private DataGridView dgvCustomerView;
        private Button btnInsertCustomer;
        private Button btnUpdateCustomer;
        private Button btnDeleteCustomer;
        private Button btnOrderForCustomer;
        private Button btnReloadCustomer;
        private Button btnReturn;
    }
}