﻿namespace SupermarketManagementSystem
{
    partial class ViewCustomerOrderForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtQuantity = new TextBox();
            txtCustomer = new TextBox();
            label12 = new Label();
            label10 = new Label();
            label2 = new Label();
            txtProductName = new TextBox();
            label3 = new Label();
            txtTotalPrice = new TextBox();
            label4 = new Label();
            btnDeleteOrder = new Button();
            btnReturnMain = new Button();
            pictureBox1 = new PictureBox();
            dgvViewCustomerOrder = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvViewCustomerOrder).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.DarkCyan;
            label1.Font = new Font("Segoe Print", 13F, FontStyle.Bold);
            label1.Location = new Point(502, 9);
            label1.Name = "label1";
            label1.Size = new Size(265, 38);
            label1.TabIndex = 0;
            label1.Text = "View Customer Order ";
            // 
            // txtQuantity
            // 
            txtQuantity.BackColor = SystemColors.InactiveCaption;
            txtQuantity.Location = new Point(208, 459);
            txtQuantity.Name = "txtQuantity";
            txtQuantity.ReadOnly = true;
            txtQuantity.Size = new Size(193, 27);
            txtQuantity.TabIndex = 47;
            // 
            // txtCustomer
            // 
            txtCustomer.BackColor = SystemColors.InactiveCaption;
            txtCustomer.Location = new Point(208, 365);
            txtCustomer.Name = "txtCustomer";
            txtCustomer.ReadOnly = true;
            txtCustomer.Size = new Size(193, 27);
            txtCustomer.TabIndex = 46;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold);
            label12.Location = new Point(102, 459);
            label12.Name = "label12";
            label12.Size = new Size(85, 20);
            label12.TabIndex = 45;
            label12.Text = "Quantity:";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold);
            label10.Location = new Point(43, 368);
            label10.Name = "label10";
            label10.Size = new Size(150, 20);
            label10.TabIndex = 44;
            label10.Text = "Customer Name:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.DarkCyan;
            label2.Font = new Font("Segoe Print", 13F, FontStyle.Bold);
            label2.ForeColor = Color.Cornsilk;
            label2.Location = new Point(180, 313);
            label2.Name = "label2";
            label2.Size = new Size(237, 38);
            label2.TabIndex = 48;
            label2.Text = "Order's Information";
            // 
            // txtProductName
            // 
            txtProductName.BackColor = SystemColors.InactiveCaption;
            txtProductName.Location = new Point(208, 414);
            txtProductName.Name = "txtProductName";
            txtProductName.ReadOnly = true;
            txtProductName.Size = new Size(193, 27);
            txtProductName.TabIndex = 50;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold);
            label3.Location = new Point(53, 417);
            label3.Name = "label3";
            label3.Size = new Size(134, 20);
            label3.TabIndex = 49;
            label3.Text = "Product Name:";
            // 
            // txtTotalPrice
            // 
            txtTotalPrice.BackColor = SystemColors.InactiveCaption;
            txtTotalPrice.Location = new Point(208, 509);
            txtTotalPrice.Name = "txtTotalPrice";
            txtTotalPrice.ReadOnly = true;
            txtTotalPrice.Size = new Size(193, 27);
            txtTotalPrice.TabIndex = 52;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold);
            label4.Location = new Point(80, 512);
            label4.Name = "label4";
            label4.Size = new Size(107, 20);
            label4.TabIndex = 51;
            label4.Text = "Total Price:";
            // 
            // btnDeleteOrder
            // 
            btnDeleteOrder.BackColor = Color.Lime;
            btnDeleteOrder.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnDeleteOrder.Location = new Point(457, 379);
            btnDeleteOrder.Name = "btnDeleteOrder";
            btnDeleteOrder.Size = new Size(161, 43);
            btnDeleteOrder.TabIndex = 53;
            btnDeleteOrder.Text = "Delete Order";
            btnDeleteOrder.UseVisualStyleBackColor = false;
            btnDeleteOrder.Click += btnDeleteOrder_Click;
            // 
            // btnReturnMain
            // 
            btnReturnMain.BackColor = Color.Maroon;
            btnReturnMain.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnReturnMain.ForeColor = SystemColors.ControlLightLight;
            btnReturnMain.Location = new Point(457, 448);
            btnReturnMain.Name = "btnReturnMain";
            btnReturnMain.Size = new Size(161, 43);
            btnReturnMain.TabIndex = 54;
            btnReturnMain.Text = "Return Main Screen";
            btnReturnMain.UseVisualStyleBackColor = false;
            btnReturnMain.Click += btnReturnMain_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.ViewCustomerOrder;
            pictureBox1.Location = new Point(714, 63);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(485, 428);
            pictureBox1.TabIndex = 55;
            pictureBox1.TabStop = false;
            // 
            // dgvViewCustomerOrder
            // 
            dgvViewCustomerOrder.CellBorderStyle = DataGridViewCellBorderStyle.Raised;
            dgvViewCustomerOrder.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvViewCustomerOrder.Location = new Point(12, 51);
            dgvViewCustomerOrder.Name = "dgvViewCustomerOrder";
            dgvViewCustomerOrder.ReadOnly = true;
            dgvViewCustomerOrder.RowHeadersWidth = 51;
            dgvViewCustomerOrder.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvViewCustomerOrder.Size = new Size(682, 261);
            dgvViewCustomerOrder.TabIndex = 56;
            dgvViewCustomerOrder.CellClick += dgvViewCustomerOrder_CellClick;
            // 
            // ViewCustomerOrderForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkCyan;
            ClientSize = new Size(1242, 583);
            Controls.Add(dgvViewCustomerOrder);
            Controls.Add(pictureBox1);
            Controls.Add(btnReturnMain);
            Controls.Add(btnDeleteOrder);
            Controls.Add(txtTotalPrice);
            Controls.Add(label4);
            Controls.Add(txtProductName);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(txtQuantity);
            Controls.Add(txtCustomer);
            Controls.Add(label12);
            Controls.Add(label10);
            Controls.Add(label1);
            Name = "ViewCustomerOrderForm";
            Text = "ViewCustomerOrderForm";
            Load += ViewCustomerOrderForm_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvViewCustomerOrder).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtQuantity;
        private TextBox txtCustomer;
        private Label label12;
        private Label label10;
        private Label label2;
        private TextBox txtProductName;
        private Label label3;
        private TextBox txtTotalPrice;
        private Label label4;
        private Button btnDeleteOrder;
        private Button btnReturnMain;
        private PictureBox pictureBox1;
        private DataGridView dgvViewCustomerOrder;
    }
}