﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace SupermarketManagementSystem
{
    public partial class ModifyProductForm : Form
    {
        // This is connect string to connect with database.
        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=SupermarketProductManagementSystem.accdb";

        // Constructor to initialize the form.
        public ModifyProductForm()
        {
            InitializeComponent();
        }

        // Event handler for the form's load event. 
        private void ModifyProductForm_Load(object sender, EventArgs e)
        {
            LoadCategory(); // This would be load categories into the combo box
            LoadProductToDatagridView(); // Populate the datagridview with product data.
        }

        // Method to Load categories into the combo box
        private void LoadCategory()
        {
            // Array of category name to add to the combo box.
            string[] nameCategogy = { "Select a Category", "Fruits", "Bakery", "Dairy", "Frozen Food", "Vegetables", "Pantry", "Meat" };
            foreach (string name in nameCategogy)
            {
                cboCategory.Items.Add(name); // Add each category to the combo box. 
            }
            cboCategory.SelectedIndex = 0;
        }

        // This is method to load all products into the DataGridView.
        private void LoadProductToDatagridView()
        { 
            Product pro = new Product(); // Create a new Product Object. 
            DataTable dataTable = pro.LoadDataFromDatabase("Category"); // Load Product Data. 
            dgvProductInventory.DataSource = dataTable; // Bind the data to the grid. 
        }

        // Envent to select all the product with the 
        private void cboCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedItem = cboCategory.SelectedItem.ToString(); // This one for get the selected row
            Product pro = new Product(); // Create a new product object
            DataTable dataTable = pro.LoadProductByCategory(selectedItem); // Load products of the selected category
            dgvProductInventory.DataSource = dataTable; // Bind the filtered data to grid. 
        }
        private void dgvProductInventory_SelectionChanged(object sender, EventArgs e)
        {
            // I will be check if the count of the product selected is greater than 0
            if (dgvProductInventory.SelectedRows.Count > 0)
            {
                // Intialize the DataGridViewRow
                DataGridViewRow row = dgvProductInventory.SelectedRows[0];
                txtName.Text = row.Cells["ProductName"].Value.ToString();
                txtDescription2.Text = row.Cells["ProductDescription"].Value.ToString();
                txtPrice2.Text = row.Cells["Price"].Value.ToString();
                txtStockLevel2.Text = row.Cells["StockLevel"].Value.ToString();
                txtImageURL.Text = row.Cells["ProductImageURL"].Value.ToString();

                string imageURL = row.Cells["ProductImageURL"].Value?.ToString();

                if (!string.IsNullOrWhiteSpace(imageURL))
                {
                    try
                    {
                        pictureBoxImage.Load(imageURL); // Try to load the image from the URL or file path
                    }
                    catch
                    {
                        // Fallback to  Not found image if loading fails
                        pictureBoxImage.Image = Image.FromFile(@"Images\ImageNotFound.jpg");
                    }
                }
                else
                {
                    // Show the "Not Found" image if the URL is empty or null
                    pictureBoxImage.Image = Image.FromFile(@"Images\ImageNotFound.jpg");
                }

            }
        }

        // Event handler for the Save changes button click. 
        private void btnSaveChange_Click(object sender, EventArgs e)
        {
            try
            {
                Product product = new Product(); // Create e new product object
                // Update product properties with data from the form.
                product.ProductDescription = txtDescription2.Text;
                product.ProductPrice = Convert.ToDouble(txtPrice2.Text);
                product.StockLevel = Convert.ToInt32(txtStockLevel2.Text);
                product.ProductImageURL = txtImageURL.Text;
                product.SaveChangeProductToDatabase(txtName.Text); // Save changes to the database

                LoadProductFromDatabase(); // Reload product data to reflect changes. 
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving: " + ex.Message);
            }

        }

        // Method to reload all product data from the database. 
        private void LoadProductFromDatabase()
        {
            string query = "SELECT * FROM Products"; // Query to select all products. 

            using (OleDbConnection conn = new OleDbConnection(connectionString)) // Create a database connection. 
            {
                conn.Open(); // Open the connection. 
                using (OleDbDataAdapter adap = new OleDbDataAdapter(query, conn))
                {

                    DataTable dt = new DataTable(); // Create a data table
                    adap.Fill(dt); // Fill the data table with query results.
                    dgvProductInventory.DataSource = dt; // Bind data to the 
                }
            }
        }

        // Event handler for the return button click. 
        private void btnReturn_Click(object sender, EventArgs e)
        {
            this.Close(); // Close the form 
        }



    }
}
