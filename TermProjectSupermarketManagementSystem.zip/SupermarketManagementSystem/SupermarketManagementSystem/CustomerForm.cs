﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SupermarketManagementSystem
{
    public partial class CustomerForm : Form
    {
        public CustomerForm() // Constructor for the form.
        {
            InitializeComponent(); // Initializes form components
        }

        private void CustomerForm_Load(object sender, EventArgs e)
        {
            LoadCustomerIntoDataGridView(); // Call Load Customer data into the DataGridView
            LoadAllStates(); // Populates the state with U.S states. 
        }


        private void LoadAllStates()
        {
            string[] states = { "Select A state",
        "Alabama",
        "Alaska",
        "Arizona",
        "Arkansas",
        "California",
        "Colorado",
        "Connecticut",
        "Delaware",
        "Florida",
        "Georgia",
        "Hawaii",
        "Idaho",
        "Illinois",
        "Indiana",
        "Iowa",
        "Kansas",
        "Kentucky",
        "Louisiana",
        "Maine",
        "Maryland",
        "Massachusetts",
        "Michigan",
        "Minnesota",
        "Mississippi",
        "Missouri",
        "Montana",
        "Nebraska",
        "Nevada",
        "New Hampshire",
        "New Jersey",
        "New Mexico",
        "New York",
        "North Carolina",
        "North Dakota",
        "Ohio",
        "Oklahoma",
        "Oregon",
        "Pennsylvania",
        "Rhode Island",
        "South Carolina",
        "South Dakota",
        "Tennessee",
        "Texas",
        "Utah",
        "Vermont",
        "Virginia",
        "Washington",
        "West Virginia",
        "Wisconsin",
        "Wyoming"
    };

            foreach (string state in states) // Iterates over each  state in the angry
            {
                cboState.Items.Add(state); // Adds each state to the
            }
            cboState.SelectedIndex = 0;
        }


        // This section for add the customer into the database
        // Showing the customer into the datagridciew
        public void LoadCustomerIntoDataGridView() // Populates the DataGridView with customer data.
        {
            Customer customer = new Customer(); // Creates a new Customer Object
            DataTable customerData = customer.LoadCustomerIntoDataGridView(); //Load customer data. 
            if (customerData != null) // Check if the customer data was retrieval was successful. 
            {
                dgvCustomerView.DataSource = customerData; // Bind the data into the DataGridView. 
            }
            else
            {
                MessageBox.Show("Failed to load products for the selected category.", "Error");
            }

        }

        private void btnInsertCustomer_Click(object sender, EventArgs e)
        {
            // I would need to be check all the any field  if they
            // are empty or Null

            // Check if any field is empty or null
            if (string.IsNullOrWhiteSpace(txtCustomerName.Text) ||
                string.IsNullOrWhiteSpace(txtPhoneNumber.Text) ||
                string.IsNullOrWhiteSpace(txtEmail.Text) ||
                string.IsNullOrWhiteSpace(txtAddress.Text) ||
                string.IsNullOrWhiteSpace(txtCity.Text) ||
                cboState.SelectedItem == null ||
                string.IsNullOrWhiteSpace(txtZipCode.Text))
            {
                MessageBox.Show("Please fill in all fields.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning); // Alert  the users. 
                return; // Exits the method if validation fails. 
            }

            // Check the validate the ZipCode as well. 
            if (txtZipCode.Text.Length != 5)
            {
                MessageBox.Show("Zipcode must be exactly 5 digit number");
                return;
            }

            if (txtPhoneNumber.Text.Length != 10) // Validates  the phone number Length. 
            {
                MessageBox.Show("Phone number must be exactly 10 digit number.");
                return;
            }

            // Collect input data for the new customer. 
            string customerName = txtCustomerName.Text;
            string customerPhone = FormatPhoneNumber(txtPhoneNumber.Text);
            string customerEmail = txtEmail.Text;
            string customerAddress = txtAddress.Text;
            string customerCity = txtCity.Text;
            string customerState = cboState.SelectedItem.ToString();
            string customerZipcode = txtZipCode.Text;


            // Create a new Customer object and insert it into the database. 
            Customer customer = new Customer(customerName, customerPhone, customerEmail, customerAddress, customerCity, customerState, customerZipcode);

            customer.InsertCustomerDatabase(customer);
            LoadCustomerIntoDataGridView();
            ClearCutomerFormFields();
        }


        // Check the Format of the Phone Number
        private string FormatPhoneNumber(string phoneNumber) // Formats a phone number. 
        {
            return $"({phoneNumber.Substring(0, 3)}) {phoneNumber.Substring(3, 3)} - {phoneNumber.Substring(6)}";
        }


        private void ClearCutomerFormFields() // Clears all input field in the form. 
        {
            txtCustomerName.Clear();
            txtPhoneNumber.Clear();
            txtEmail.Clear();
            txtAddress.Clear();
            txtCity.Clear();
            cboState.SelectedIndex = -1;
            txtZipCode.Clear();
        }

        private int selectedCustomerID = -1;// I just want to check track the currently selected customer ID. 
        private string customerName; // Stores the selected customer's name. 
        private string customerPhone; // store the selected customer's phone number
        private string customerEmail; // Store the selected customer's email
        private string customerAddress; // Stores the selected customer's address.
        private string customerCity;   // Store the selecyted custoemer's city. 
        private string customerState; // // Store the selecyted custoemer's state
        private string customerZipcode; // Store the selecyted custoemer's ZipCode. 

        private void dgvCustomerView_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvCustomerView.SelectedRows.Count > 0)
            {
                // Retrieves customer details from the selected. 
                selectedCustomerID = Convert.ToInt32(dgvCustomerView.SelectedRows[0].Cells["CustomerID"].Value);
                customerName = dgvCustomerView.SelectedRows[0].Cells["CustomerName"].Value.ToString();
                customerPhone = dgvCustomerView.SelectedRows[0].Cells["PhoneNumber"].Value.ToString();
                customerEmail = dgvCustomerView.SelectedRows[0].Cells["Email"].Value.ToString();
                customerAddress = dgvCustomerView.SelectedRows[0].Cells["Address"].Value.ToString();
                customerCity = dgvCustomerView.SelectedRows[0].Cells["City"].Value.ToString();
                customerState = dgvCustomerView.SelectedRows[0].Cells["State"].Value.ToString();
                customerZipcode = dgvCustomerView.SelectedRows[0].Cells["ZipCode"].Value.ToString();

            }

        }

        public void btnUpdateCustomer_Click(object sender, EventArgs e)
        {
            if (selectedCustomerID != -1) // Ensure a customer is selected
            {
                Customer customer = new Customer();
                // Retrieve customer data from the database using the selected customer ID
                customer = customer.FindCustomerID(selectedCustomerID); // Use the correct method to retrieve the customer

                if (customer != null)
                {
                    // Show confirmation dialog with the customer name
                    DialogResult dialogResult = MessageBox.Show(
                        "Are you sure you want to update the customer: " + customer.customerName + "?",
                        "Confirm Update",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question
                    );

                    // If the user clicks 'Yes', open the update form
                    if (dialogResult == DialogResult.Yes)
                    {
                        // Open the UpdateForm and pass the customer data
                        UpdateCustomerForm updateForm = new UpdateCustomerForm(customer, selectedCustomerID);
                        updateForm.ShowDialog();

                        // After the update, refresh the data grid
                        LoadCustomerIntoDataGridView();
                    }
                }
                else
                {
                    MessageBox.Show("Customer not found.", "Update Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Please select a customer to update.", "Update Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnDeleteCustomer_Click(object sender, EventArgs e)
        {
            // Checking condition if selectedID is different with -1
            if (selectedCustomerID != -1)
            {
                Customer customer = new Customer();
                if (customer != null)
                {
                    // Show confirmation dialog with the customer name
                    // To ask the user again to confirm if they want really want to delete it.
                    DialogResult dialogResult = MessageBox.Show(
                        "Do you want to delete the customer: " + "\n" +
                        "Customer Name: " + customerName + "\n" +
                        "Phone Number: " + customerPhone + "\n" +
                        "Email: " + customerEmail + "\n" +
                        "Address: " + customerAddress + "\n" +
                        "City: " + customerCity + "\n" +
                        "States: " + customerState + "\n" +
                        "ZipCode: " + customerZipcode + "?",
                        "Confirm Update",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question
                    );

                    // If the user clicks 'Yes', open the update form
                    if (dialogResult == DialogResult.Yes)
                    {
                        // After the Delete, refresh the data grid
                        customer.DeleteCustomerInDatabase(selectedCustomerID);
                        LoadCustomerIntoDataGridView();
                    }
                }
                else
                {
                    MessageBox.Show("Customer not found.", "Update Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Please select a customer to update.", "Update Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnOrderForCustomer_Click(object sender, EventArgs e)
        {
            // Ask user again to confirm the action
            DialogResult result = MessageBox.Show(
                $"Do you want to order products for the customer: {customerName}?",
                "Confirm Order",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            // If they click "Yes" will be open another Form.
            if (result == DialogResult.Yes)
            {
                // Pass customer details to the OrderForm
                OrderForm orderForm = new OrderForm(selectedCustomerID, customerName);
                orderForm.ShowDialog(); // Open as a dialog
            }
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
