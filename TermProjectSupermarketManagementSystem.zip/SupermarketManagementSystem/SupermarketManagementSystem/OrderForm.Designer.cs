﻿namespace SupermarketManagementSystem
{
    partial class OrderForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            dgvProductIventory = new DataGridView();
            pictureBoxProductImage = new PictureBox();
            txtPrice = new TextBox();
            txtName = new TextBox();
            label13 = new Label();
            label12 = new Label();
            label10 = new Label();
            btnAddToCart = new Button();
            numQuantity = new NumericUpDown();
            dgvCart = new DataGridView();
            btnReturnCustomer = new Button();
            label2 = new Label();
            label3 = new Label();
            btnAddOrder = new Button();
            btnRemoveCart = new Button();
            lblCustomerInfor = new Label();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)dgvProductIventory).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxProductImage).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numQuantity).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvCart).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Violet;
            label1.Font = new Font("Segoe Print", 15F, FontStyle.Bold);
            label1.Location = new Point(447, 6);
            label1.Name = "label1";
            label1.Size = new Size(440, 44);
            label1.TabIndex = 2;
            label1.Text = "Customer's Order and Check Out";
            // 
            // dgvProductIventory
            // 
            dgvProductIventory.BackgroundColor = Color.BlanchedAlmond;
            dgvProductIventory.BorderStyle = BorderStyle.Fixed3D;
            dgvProductIventory.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvProductIventory.Location = new Point(12, 99);
            dgvProductIventory.Name = "dgvProductIventory";
            dgvProductIventory.ReadOnly = true;
            dgvProductIventory.RowHeadersWidth = 51;
            dgvProductIventory.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvProductIventory.Size = new Size(612, 192);
            dgvProductIventory.TabIndex = 3;
            dgvProductIventory.CellClick += dgvProductIventory_CellClick;
            dgvProductIventory.CellContentClick += dgvProductIventory_CellContentClick;
            // 
            // pictureBoxProductImage
            // 
            pictureBoxProductImage.Location = new Point(12, 297);
            pictureBoxProductImage.Name = "pictureBoxProductImage";
            pictureBoxProductImage.Size = new Size(267, 201);
            pictureBoxProductImage.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBoxProductImage.TabIndex = 4;
            pictureBoxProductImage.TabStop = false;
            // 
            // txtPrice
            // 
            txtPrice.BackColor = SystemColors.InactiveCaption;
            txtPrice.Location = new Point(371, 334);
            txtPrice.Name = "txtPrice";
            txtPrice.ReadOnly = true;
            txtPrice.Size = new Size(163, 27);
            txtPrice.TabIndex = 43;
            // 
            // txtName
            // 
            txtName.BackColor = SystemColors.InactiveCaption;
            txtName.Location = new Point(371, 301);
            txtName.Name = "txtName";
            txtName.ReadOnly = true;
            txtName.Size = new Size(163, 27);
            txtName.TabIndex = 41;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold);
            label13.Location = new Point(285, 396);
            label13.Name = "label13";
            label13.Size = new Size(144, 20);
            label13.TabIndex = 39;
            label13.Text = "Select Quantity:";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold);
            label12.Location = new Point(306, 337);
            label12.Name = "label12";
            label12.Size = new Size(59, 20);
            label12.TabIndex = 38;
            label12.Text = "Price:";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold);
            label10.Location = new Point(302, 304);
            label10.Name = "label10";
            label10.Size = new Size(63, 20);
            label10.TabIndex = 36;
            label10.Text = "Name:";
            // 
            // btnAddToCart
            // 
            btnAddToCart.BackColor = Color.Yellow;
            btnAddToCart.Font = new Font("Segoe Print", 9F, FontStyle.Bold);
            btnAddToCart.Location = new Point(302, 451);
            btnAddToCart.Name = "btnAddToCart";
            btnAddToCart.Size = new Size(194, 47);
            btnAddToCart.TabIndex = 45;
            btnAddToCart.Text = "Add to Cart";
            btnAddToCart.UseVisualStyleBackColor = false;
            btnAddToCart.Click += btnAddToCart_Click;
            // 
            // numQuantity
            // 
            numQuantity.Location = new Point(435, 394);
            numQuantity.Maximum = new decimal(new int[] { 200, 0, 0, 0 });
            numQuantity.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            numQuantity.Name = "numQuantity";
            numQuantity.Size = new Size(112, 27);
            numQuantity.TabIndex = 46;
            numQuantity.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // 
            // dgvCart
            // 
            dgvCart.BackgroundColor = Color.BlanchedAlmond;
            dgvCart.BorderStyle = BorderStyle.Fixed3D;
            dgvCart.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvCart.Location = new Point(761, 99);
            dgvCart.Name = "dgvCart";
            dgvCart.ReadOnly = true;
            dgvCart.RowHeadersWidth = 51;
            dgvCart.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvCart.Size = new Size(660, 192);
            dgvCart.TabIndex = 47;
            // 
            // btnReturnCustomer
            // 
            btnReturnCustomer.BackColor = Color.RoyalBlue;
            btnReturnCustomer.Font = new Font("Segoe Print", 9F, FontStyle.Bold);
            btnReturnCustomer.ForeColor = Color.Cornsilk;
            btnReturnCustomer.Location = new Point(302, 515);
            btnReturnCustomer.Name = "btnReturnCustomer";
            btnReturnCustomer.Size = new Size(194, 47);
            btnReturnCustomer.TabIndex = 49;
            btnReturnCustomer.Text = "Return Customer'Site";
            btnReturnCustomer.UseVisualStyleBackColor = false;
            btnReturnCustomer.Click += btnReturnCustomer_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe Print", 14F, FontStyle.Bold);
            label2.Location = new Point(1065, 53);
            label2.Name = "label2";
            label2.Size = new Size(73, 43);
            label2.TabIndex = 50;
            label2.Text = "Cart";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe Print", 14F, FontStyle.Bold);
            label3.Location = new Point(159, 53);
            label3.Name = "label3";
            label3.Size = new Size(242, 43);
            label3.TabIndex = 51;
            label3.Text = "Product Inventory";
            // 
            // btnAddOrder
            // 
            btnAddOrder.BackColor = Color.Turquoise;
            btnAddOrder.Font = new Font("Segoe Print", 10F, FontStyle.Bold);
            btnAddOrder.ForeColor = Color.Blue;
            btnAddOrder.Location = new Point(1156, 297);
            btnAddOrder.Name = "btnAddOrder";
            btnAddOrder.Size = new Size(182, 46);
            btnAddOrder.TabIndex = 52;
            btnAddOrder.Text = "Add To Order";
            btnAddOrder.UseVisualStyleBackColor = false;
            btnAddOrder.Click += btnAddOrder_Click;
            // 
            // btnRemoveCart
            // 
            btnRemoveCart.BackColor = SystemColors.MenuText;
            btnRemoveCart.Font = new Font("Segoe Print", 10F, FontStyle.Bold);
            btnRemoveCart.ForeColor = SystemColors.ControlLight;
            btnRemoveCart.Location = new Point(864, 297);
            btnRemoveCart.Name = "btnRemoveCart";
            btnRemoveCart.Size = new Size(207, 46);
            btnRemoveCart.TabIndex = 53;
            btnRemoveCart.Text = "Remove From Cart";
            btnRemoveCart.UseVisualStyleBackColor = false;
            btnRemoveCart.Click += btnRemoveCart_Click;
            // 
            // lblCustomerInfor
            // 
            lblCustomerInfor.AutoSize = true;
            lblCustomerInfor.BackColor = Color.Tomato;
            lblCustomerInfor.Font = new Font("Segoe Print", 17F, FontStyle.Bold);
            lblCustomerInfor.Location = new Point(940, 2);
            lblCustomerInfor.Name = "lblCustomerInfor";
            lblCustomerInfor.Size = new Size(346, 51);
            lblCustomerInfor.TabIndex = 54;
            lblCustomerInfor.Text = "Customer Information";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.GroceryShopping;
            pictureBox1.Location = new Point(724, 349);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(697, 319);
            pictureBox1.TabIndex = 55;
            pictureBox1.TabStop = false;
            // 
            // OrderForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1433, 680);
            Controls.Add(pictureBox1);
            Controls.Add(lblCustomerInfor);
            Controls.Add(btnRemoveCart);
            Controls.Add(btnAddOrder);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(btnReturnCustomer);
            Controls.Add(dgvCart);
            Controls.Add(numQuantity);
            Controls.Add(btnAddToCart);
            Controls.Add(txtPrice);
            Controls.Add(txtName);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(label10);
            Controls.Add(pictureBoxProductImage);
            Controls.Add(dgvProductIventory);
            Controls.Add(label1);
            Name = "OrderForm";
            Text = "OrderForm";
            Load += OrderForm_Load;
            ((System.ComponentModel.ISupportInitialize)dgvProductIventory).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxProductImage).EndInit();
            ((System.ComponentModel.ISupportInitialize)numQuantity).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvCart).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private DataGridView dgvProductIventory;
        private PictureBox pictureBoxProductImage;
        private TextBox txtPrice;
        private TextBox txtName;
        private Label label13;
        private Label label12;
        private Label label10;
        private Button btnAddToCart;
        private NumericUpDown numQuantity;
        private DataGridView dgvCart;
        private Button btnReturnCustomer;
        private Label label2;
        private Label label3;
        private Button btnAddOrder;
        private Button btnRemoveCart;
        private Label lblCustomerInfor;
        private PictureBox pictureBox1;
    }
}