﻿    using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SupermarketManagementSystem
{
    internal class Order
    {
        public int OrderID;
        public string CustomerName;
        public int CustomerID;
        public int ProductID;
        public string ProductName;
        public int Quantity;
        public decimal TotalPrice;
        public DateTime OrderDate;


        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=SupermarketProductManagementSystem.accdb";

        public Order(int CustomerID, int ProductID, int Quantity, decimal TotalPrice)
        {
            this.CustomerID = CustomerID;
            this.ProductID = ProductID;
            this.Quantity = Quantity;
            this.TotalPrice = TotalPrice;
            OrderDate = DateTime.Now;
        }

        public Order()
        {
        }

        public Order(string CustomerName, int CustomerID, int ProductID, string ProductName, int Quantity, decimal TotalPrice)
        {
            this.CustomerName = CustomerName;
            this.CustomerID = CustomerID;
            this.ProductID = ProductID;
            this.ProductName = ProductName;
            this.Quantity = Quantity;
            this.TotalPrice = TotalPrice;
            OrderDate = DateTime.Now;
        }

        public int orderID
        {
            get { return this.OrderID; }
            set { this.OrderID = value; }
        }

        public string customerName
        {
            get { return this.CustomerName; }
            set { this.CustomerName = value; }
        }


        public int customerID
        {
            get { return this.CustomerID; }
            set { this.CustomerID = value; }
        }

        public string productName
        {
            get { return this.ProductName; }
            set { this.ProductName = value; }
        }

        public int productID
        {
            get { return this.ProductID; }
            set { this.ProductID = value; }
        }

        public int quantity
        {
            get { return this.Quantity; }
            set { this.Quantity = value; }
        }

        public decimal totalPrice
        {
            get { return this.TotalPrice; }
            set { this.TotalPrice = value; }
        }

        public DateTime orderDate
        {
            get { return this.OrderDate; }
            set { this.OrderDate = value; }
        }

        // Method to save the order to the database
        public void SaveToDatabase()
        {
            string query = "INSERT INTO Orders (CustomerID, CustomerName, ProductID, ProductName, Quantity, TotalPrice, OrderDate) " +
                           "VALUES (@CustomerID, @CustomerName, @ProductID, @ProductName, @Quantity, @TotalPrice, @OrderDate)";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                conn.Open();
                using (OleDbCommand cmd = new OleDbCommand(query, conn))
                {
                    // Add parameters
                    cmd.Parameters.AddWithValue("@CustomerID", customerID);
                    cmd.Parameters.AddWithValue("@CustomerName", customerName);
                    cmd.Parameters.AddWithValue("@ProductID", productID);
                    cmd.Parameters.AddWithValue("@ProductName", productName);
                    cmd.Parameters.AddWithValue("@Quantity", quantity);
                    cmd.Parameters.AddWithValue("@TotalPrice", totalPrice);
                    cmd.Parameters.AddWithValue("@OrderDate", orderDate);

                    // Execute the query
                    cmd.ExecuteNonQuery();

                }
            }
        }

        // Update Stock Level from the product. 
        public void UpdateStockLevelInDatabase(int productID, int newStockLevel)
        {
            string query = "UPDATE Products SET StockLevel = @StockLevel WHERE ProductID = @ProductID";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                conn.Open();
                using (OleDbCommand cmd = new OleDbCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@StockLevel", newStockLevel);
                    cmd.Parameters.AddWithValue("@ProductID", productID);

                    cmd.ExecuteNonQuery();
                }
            }
        }


        public void DeleteViewCustomerFromDatabase(int OrderID)
        {
            string query = "DELETE FROM Orders WHERE OrderID = @OrderID";
            try
            {
                using (OleDbConnection connection = new OleDbConnection(connectionString))
                {
                    connection.Open();
                    using (OleDbCommand cmd = new OleDbCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("OrderID", OrderID);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Deleted Customer Order Successfully!");
                    }
                }
            }
            catch (Exception ex) 
            {
                MessageBox.Show("Error while deleting customre order" + ex.Message);
            }


        }


    }
}
