﻿namespace SupermarketManagementSystem
{
    partial class UpdateCustomerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtZipCode = new TextBox();
            label7 = new Label();
            txtPhoneNumber = new TextBox();
            label9 = new Label();
            txtCity = new TextBox();
            label8 = new Label();
            label6 = new Label();
            label5 = new Label();
            cboState = new ComboBox();
            txtAddress = new TextBox();
            txtEmail = new TextBox();
            txtCustomerName = new TextBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            btnSaveChangeCustomer = new Button();
            btnReturnCustomer = new Button();
            SuspendLayout();
            // 
            // txtZipCode
            // 
            txtZipCode.BackColor = SystemColors.InactiveCaption;
            txtZipCode.Location = new Point(206, 347);
            txtZipCode.Name = "txtZipCode";
            txtZipCode.Size = new Size(280, 27);
            txtZipCode.TabIndex = 52;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label7.Location = new Point(102, 351);
            label7.Name = "label7";
            label7.Size = new Size(82, 23);
            label7.TabIndex = 51;
            label7.Text = "ZipCode:";
            // 
            // txtPhoneNumber
            // 
            txtPhoneNumber.BackColor = SystemColors.InactiveCaption;
            txtPhoneNumber.Location = new Point(206, 137);
            txtPhoneNumber.Name = "txtPhoneNumber";
            txtPhoneNumber.Size = new Size(280, 27);
            txtPhoneNumber.TabIndex = 50;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label9.Location = new Point(52, 137);
            label9.Name = "label9";
            label9.Size = new Size(136, 23);
            label9.TabIndex = 49;
            label9.Text = "Phone Number:";
            // 
            // txtCity
            // 
            txtCity.BackColor = SystemColors.InactiveCaption;
            txtCity.Location = new Point(206, 266);
            txtCity.Name = "txtCity";
            txtCity.Size = new Size(280, 27);
            txtCity.TabIndex = 48;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label8.Location = new Point(127, 308);
            label8.Name = "label8";
            label8.Size = new Size(57, 23);
            label8.TabIndex = 47;
            label8.Text = "State:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(108, 311);
            label6.Name = "label6";
            label6.Size = new Size(0, 20);
            label6.TabIndex = 46;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label5.Location = new Point(137, 270);
            label5.Name = "label5";
            label5.Size = new Size(47, 23);
            label5.TabIndex = 45;
            label5.Text = "City:";
            // 
            // cboState
            // 
            cboState.BackColor = SystemColors.HighlightText;
            cboState.FormattingEnabled = true;
            cboState.Location = new Point(206, 303);
            cboState.Name = "cboState";
            cboState.Size = new Size(280, 28);
            cboState.TabIndex = 44;
            // 
            // txtAddress
            // 
            txtAddress.BackColor = SystemColors.InactiveCaption;
            txtAddress.Location = new Point(206, 222);
            txtAddress.Name = "txtAddress";
            txtAddress.Size = new Size(280, 27);
            txtAddress.TabIndex = 43;
            // 
            // txtEmail
            // 
            txtEmail.BackColor = SystemColors.InactiveCaption;
            txtEmail.Location = new Point(206, 183);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(280, 27);
            txtEmail.TabIndex = 42;
            // 
            // txtCustomerName
            // 
            txtCustomerName.BackColor = SystemColors.InactiveCaption;
            txtCustomerName.BorderStyle = BorderStyle.FixedSingle;
            txtCustomerName.Location = new Point(206, 89);
            txtCustomerName.Name = "txtCustomerName";
            txtCustomerName.Size = new Size(280, 27);
            txtCustomerName.TabIndex = 41;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label4.Location = new Point(105, 222);
            label4.Name = "label4";
            label4.Size = new Size(79, 23);
            label4.TabIndex = 40;
            label4.Text = "Address:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label3.Location = new Point(124, 183);
            label3.Name = "label3";
            label3.Size = new Size(64, 23);
            label3.TabIndex = 39;
            label3.Text = "Email: ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label2.Location = new Point(52, 89);
            label2.Name = "label2";
            label2.Size = new Size(144, 23);
            label2.TabIndex = 38;
            label2.Text = "Customer Name:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe Print", 12F, FontStyle.Bold);
            label1.Location = new Point(206, 9);
            label1.Name = "label1";
            label1.Size = new Size(285, 35);
            label1.TabIndex = 37;
            label1.Text = "Add Customer Information";
            // 
            // btnSaveChangeCustomer
            // 
            btnSaveChangeCustomer.BackColor = Color.Yellow;
            btnSaveChangeCustomer.Font = new Font("Segoe Script", 10F, FontStyle.Bold);
            btnSaveChangeCustomer.Location = new Point(124, 431);
            btnSaveChangeCustomer.Name = "btnSaveChangeCustomer";
            btnSaveChangeCustomer.Size = new Size(165, 43);
            btnSaveChangeCustomer.TabIndex = 53;
            btnSaveChangeCustomer.Text = "Save Change";
            btnSaveChangeCustomer.UseVisualStyleBackColor = false;
            btnSaveChangeCustomer.Click += btnSaveChangeCustomer_Click;
            // 
            // btnReturnCustomer
            // 
            btnReturnCustomer.BackColor = Color.Yellow;
            btnReturnCustomer.Font = new Font("Segoe Script", 10F, FontStyle.Bold);
            btnReturnCustomer.Location = new Point(326, 431);
            btnReturnCustomer.Name = "btnReturnCustomer";
            btnReturnCustomer.Size = new Size(194, 43);
            btnReturnCustomer.TabIndex = 54;
            btnReturnCustomer.Text = "Return Customer";
            btnReturnCustomer.UseVisualStyleBackColor = false;
            btnReturnCustomer.Click += btnReturnCustomer_Click;
            // 
            // UpdateCustomerForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.CadetBlue;
            ClientSize = new Size(761, 556);
            Controls.Add(btnReturnCustomer);
            Controls.Add(btnSaveChangeCustomer);
            Controls.Add(txtZipCode);
            Controls.Add(label7);
            Controls.Add(txtPhoneNumber);
            Controls.Add(label9);
            Controls.Add(txtCity);
            Controls.Add(label8);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(cboState);
            Controls.Add(txtAddress);
            Controls.Add(txtEmail);
            Controls.Add(txtCustomerName);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "UpdateCustomerForm";
            Text = "UpdateCustomerForm";
            Load += UpdateCustomerForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtZipCode;
        private Label label7;
        private TextBox txtPhoneNumber;
        private Label label9;
        private TextBox txtCity;
        private Label label8;
        private Label label6;
        private Label label5;
        private ComboBox cboState;
        private TextBox txtAddress;
        private TextBox txtEmail;
        private TextBox txtCustomerName;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private Button btnSaveChangeCustomer;
        private Button btnReturnCustomer;
    }
}