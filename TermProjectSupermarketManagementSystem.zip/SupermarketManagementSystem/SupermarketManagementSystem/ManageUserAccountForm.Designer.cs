﻿namespace SupermarketManagementSystem
{
    partial class ManageUserAccountForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtPassword = new TextBox();
            label9 = new Label();
            txtEmail = new TextBox();
            txtConfirmPassword = new TextBox();
            txtUserName = new TextBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            btnUpdatePassword = new Button();
            btnDeleteUserAccount = new Button();
            btnCreateNewAccount = new Button();
            dgvViewUserAccount = new DataGridView();
            btnReloadUser = new Button();
            btnReturnUser = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvViewUserAccount).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Black", 13F);
            label1.Location = new Point(482, 9);
            label1.Name = "label1";
            label1.Size = new Size(250, 30);
            label1.TabIndex = 1;
            label1.Text = "Manage User Account";
            // 
            // txtPassword
            // 
            txtPassword.BackColor = SystemColors.InactiveCaption;
            txtPassword.Location = new Point(703, 118);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(280, 27);
            txtPassword.TabIndex = 29;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label9.Location = new Point(603, 119);
            label9.Name = "label9";
            label9.Size = new Size(90, 23);
            label9.TabIndex = 28;
            label9.Text = "Password:";
            // 
            // txtEmail
            // 
            txtEmail.BackColor = SystemColors.InactiveCaption;
            txtEmail.Location = new Point(703, 203);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(280, 27);
            txtEmail.TabIndex = 27;
            // 
            // txtConfirmPassword
            // 
            txtConfirmPassword.BackColor = SystemColors.InactiveCaption;
            txtConfirmPassword.Location = new Point(703, 164);
            txtConfirmPassword.Name = "txtConfirmPassword";
            txtConfirmPassword.Size = new Size(280, 27);
            txtConfirmPassword.TabIndex = 26;
            // 
            // txtUserName
            // 
            txtUserName.BackColor = SystemColors.InactiveCaption;
            txtUserName.BorderStyle = BorderStyle.FixedSingle;
            txtUserName.Location = new Point(703, 70);
            txtUserName.Name = "txtUserName";
            txtUserName.Size = new Size(280, 27);
            txtUserName.TabIndex = 25;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label4.Location = new Point(629, 203);
            label4.Name = "label4";
            label4.Size = new Size(59, 23);
            label4.TabIndex = 24;
            label4.Text = "Email:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label3.Location = new Point(536, 168);
            label3.Name = "label3";
            label3.Size = new Size(161, 23);
            label3.TabIndex = 23;
            label3.Text = "Confirm Password:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label2.Location = new Point(586, 74);
            label2.Name = "label2";
            label2.Size = new Size(102, 23);
            label2.TabIndex = 22;
            label2.Text = "User Name:";
            // 
            // btnUpdatePassword
            // 
            btnUpdatePassword.BackColor = Color.Fuchsia;
            btnUpdatePassword.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnUpdatePassword.Location = new Point(914, 245);
            btnUpdatePassword.Name = "btnUpdatePassword";
            btnUpdatePassword.Size = new Size(159, 43);
            btnUpdatePassword.TabIndex = 32;
            btnUpdatePassword.Text = "Update Password";
            btnUpdatePassword.UseVisualStyleBackColor = false;
            btnUpdatePassword.Click += btnUpdatePassword_Click;
            // 
            // btnDeleteUserAccount
            // 
            btnDeleteUserAccount.BackColor = Color.Yellow;
            btnDeleteUserAccount.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnDeleteUserAccount.Location = new Point(552, 245);
            btnDeleteUserAccount.Name = "btnDeleteUserAccount";
            btnDeleteUserAccount.Size = new Size(136, 43);
            btnDeleteUserAccount.TabIndex = 31;
            btnDeleteUserAccount.Text = "Delete User";
            btnDeleteUserAccount.UseVisualStyleBackColor = false;
            btnDeleteUserAccount.Click += btnDeleteUserAccount_Click;
            // 
            // btnCreateNewAccount
            // 
            btnCreateNewAccount.BackColor = Color.Lime;
            btnCreateNewAccount.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnCreateNewAccount.ForeColor = Color.Black;
            btnCreateNewAccount.Location = new Point(723, 245);
            btnCreateNewAccount.Name = "btnCreateNewAccount";
            btnCreateNewAccount.Size = new Size(163, 43);
            btnCreateNewAccount.TabIndex = 30;
            btnCreateNewAccount.Text = "Create New User";
            btnCreateNewAccount.UseVisualStyleBackColor = false;
            btnCreateNewAccount.Click += btnCreateNewAccount_Click;
            // 
            // dgvViewUserAccount
            // 
            dgvViewUserAccount.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvViewUserAccount.Location = new Point(12, 51);
            dgvViewUserAccount.Name = "dgvViewUserAccount";
            dgvViewUserAccount.ReadOnly = true;
            dgvViewUserAccount.RowHeadersWidth = 51;
            dgvViewUserAccount.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvViewUserAccount.Size = new Size(504, 249);
            dgvViewUserAccount.TabIndex = 33;
            dgvViewUserAccount.CellContentClick += dgvViewUserAccount_CellContentClick;
            // 
            // btnReloadUser
            // 
            btnReloadUser.BackColor = Color.WhiteSmoke;
            btnReloadUser.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnReloadUser.Location = new Point(380, 306);
            btnReloadUser.Name = "btnReloadUser";
            btnReloadUser.Size = new Size(136, 43);
            btnReloadUser.TabIndex = 34;
            btnReloadUser.Text = "Reload User";
            btnReloadUser.UseVisualStyleBackColor = false;
            btnReloadUser.Click += btnReloadUser_Click;
            // 
            // btnReturnUser
            // 
            btnReturnUser.BackColor = Color.Yellow;
            btnReturnUser.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnReturnUser.Location = new Point(723, 319);
            btnReturnUser.Name = "btnReturnUser";
            btnReturnUser.Size = new Size(183, 54);
            btnReturnUser.TabIndex = 35;
            btnReturnUser.Text = "Return User Form";
            btnReturnUser.UseVisualStyleBackColor = false;
            btnReturnUser.Click += btnReturnUser_Click;
            // 
            // ManageUserAccountForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkCyan;
            ClientSize = new Size(1179, 426);
            Controls.Add(btnReturnUser);
            Controls.Add(btnReloadUser);
            Controls.Add(dgvViewUserAccount);
            Controls.Add(btnUpdatePassword);
            Controls.Add(btnDeleteUserAccount);
            Controls.Add(btnCreateNewAccount);
            Controls.Add(txtPassword);
            Controls.Add(label9);
            Controls.Add(txtEmail);
            Controls.Add(txtConfirmPassword);
            Controls.Add(txtUserName);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "ManageUserAccountForm";
            Text = "ManageUserAccountForm";
            Load += ManageUserAccountForm_Load;
            ((System.ComponentModel.ISupportInitialize)dgvViewUserAccount).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label1;
        private TextBox txtPassword;
        private Label label9;
        private TextBox txtEmail;
        private TextBox txtConfirmPassword;
        private TextBox txtUserName;
        private Label label4;
        private Label label3;
        private Label label2;
        private Button btnUpdatePassword;
        private Button btnDeleteUserAccount;
        private Button btnCreateNewAccount;
        private DataGridView dgvViewUserAccount;
        private Button btnReloadUser;
        private Button btnReturnUser;
    }
}