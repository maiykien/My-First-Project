﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Mail;

namespace SupermarketManagementSystem
{
    public partial class RegisterForm : Form
    {
        public RegisterForm()
        {
            InitializeComponent();
        }

        private void RegisterForm_Load(object sender, EventArgs e)
        {

        }

        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=SupermarketProductManagementSystem.accdb";

        // Let do continure to do in the RegisterUser
        private bool RegisterUser(string username, string password, string email)
        {
            // I put the coulumn name in the Bracket
            // SQL query to insert new user data into the Users table
            string query = "INSERT INTO Users ([Username], [Password], [Email]) " +
                           "VALUES (@Username, @Password, @Email)";

            try
            {
                // create a connection to the database.
                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    conn.Open(); // Open a command to execute the SQL query.

                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        // Add parameters in the correct order
                        cmd.Parameters.AddWithValue("@Username", username);
                        cmd.Parameters.AddWithValue("@Password", password);
                        cmd.Parameters.AddWithValue("@Email", email);

                        // Execute query and check affected rows
                        int rowsAffected = cmd.ExecuteNonQuery();
                        return rowsAffected > 0;
                    }
                }
            }
            catch (Exception ex)
            {   
                // Show detailed error message
                MessageBox.Show("Error while connecting to the database: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;

            }
        }
        // I will do on checking the valid email as well.
        private bool isValidEmail(string email)
        {
            try
            {
                // Using MailAddress class to check email validity. 
                var addr = new MailAddress(email);
                return addr.Address == email; // return true if the email is valid.
            }
            catch
            {
                return false; // Return false if email is invalid. 
            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            // I will get user input from text fields, trimming some extra space. 
            string user = txtUserName.Text.Trim();
            string password = txtPassword.Text.Trim();
            string confirmPassword = txtConfirmPassword.Text.Trim();
            string email = txtEmail.Text.Trim();

            // I will go over to check the Validation of the Input
            // and I want to make sure all the field is not empty. 

            if (string.IsNullOrEmpty(user) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("All fields are required.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validate the input for Confirmpassword
            // and validate for the Email

            if (string.IsNullOrEmpty(confirmPassword) || string.IsNullOrEmpty(email))
            {
                MessageBox.Show("All fields are required.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Check the password and confirmpassword of the 
            // User will be match to each other.

            if (password != confirmPassword)
            {
                MessageBox.Show("Password Do Not Match!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (isValidEmail(email))
            {
                MessageBox.Show("Email is valid!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Please enter a valid email address.", "Invalid Email", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }


            // Called the method RegisterUser
            // If registration successfully,
            // It would be add into the database.
            if (RegisterUser(user, password, email))
            {
                MessageBox.Show("Registration Successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            else
            {
                MessageBox.Show("Registration failed. Try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return ;
            }

        }
        

        // Event handler for cancel button click event

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close(); // Close the form when the Cancel button is clicked. 
        }
    }
}
