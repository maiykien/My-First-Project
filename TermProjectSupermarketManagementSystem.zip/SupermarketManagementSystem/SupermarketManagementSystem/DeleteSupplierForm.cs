﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SupermarketManagementSystem
{
    public partial class DeleteSupplierForm : Form
    {

        SupplierForm supplierForm;
        public DeleteSupplierForm()
        {
            InitializeComponent(); // Initialize form component
            LoadSupplierFromDatabase(); // Loads supplier data into the form. 
            //LoadCategory();

        }
        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=SupermarketProductManagementSystem.accdb";

    
        private void DeleteSupplierForm_Load(object sender, EventArgs e)
        {

        }
        private void LoadSupplierFromDatabase()
        {
            string query = "SELECT * FROM Suppliers"; // SQL query to fetch all suppliers. 

            using (OleDbConnection conn = new OleDbConnection(connectionString)) // Establish a databsae connection. 
            {
                conn.Open(); // Open the database connection

                using (OleDbDataAdapter adap = new OleDbDataAdapter(query, conn)) // Create a data adapter to execute the query. 
                {

                    DataTable dt = new DataTable(); // Create DataTable to hold the fetched data. 
                    adap.Fill(dt); // Fill the DataTable with data from the query. 
                    dgvSupplier.DataSource = dt; // Bind the data to the DataGridView for display. 
                }
            }
        }

        private int SupplierID; // Stores the ID of the selected suppliers. 
        private void btnDelete_Click(object sender, EventArgs e)
        {

            Supplier sup = new Supplier(); // Create a new Supplier object

            // Populate the supplier object withd data from form field. 
            sup.SupplierName = txtSupplierName.Text;
            sup.ContactNumber = txtContactNumber.Text;
            sup.SupplierEmail = txtEmail.Text;
            sup.SupplierAddress = txtAddress.Text;
            var confirmResult = MessageBox.Show($" Do you want to Delete" + sup.SupplierName.ToString() + "?", "Confirm Save", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            
            // Display a confirmation dialog before deletion. 
            try
            {
                if (confirmResult == DialogResult.Yes)
                {
                    sup.DeleteSupplierToDatabase(SupplierID); // This would be call the method to delete the supplier form the database. 
                    LoadSupplierFromDatabase(); //Reload the supplier data to reflect changes. 
                    ClearSupplierFormFields(); // This would be clear form fields after deletion. 
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while saving the supplier: " + ex.Message);
            }

        }
        private void ClearSupplierFormFields()
        {
            // Clear the text fields in the Form. 
            txtSupplierName.Clear();
            txtContactNumber.Clear();
            txtEmail.Clear();
            txtAddress.Clear();

        }

        private void dgvSupplier_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvSupplier.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dgvSupplier.SelectedRows[0];

                //Populate form field with data from the selected row. 
                SupplierID = Convert.ToInt32(row.Cells["SupplierID"].Value); // Get the SupplierID
                txtSupplierName.Text = row.Cells["SupplierName"].Value.ToString(); // Get SupplierName
                txtContactNumber.Text = row.Cells["ContactNumber"].Value.ToString(); // Get ContactNumber
                txtEmail.Text = row.Cells["SupplierEmail"].Value.ToString(); // Get SupplierEmail
                txtAddress.Text = row.Cells["SupplierAddress"].Value.ToString(); // Get SupplierAddress. 
            }
        }

        public void btnReturnSupplier_Click(object sender, EventArgs e)
        {
            this.Close(); // Close the Form. 
        }
    }
}
