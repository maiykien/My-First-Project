﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace SupermarketManagementSystem
{
    public partial class CustomerProductAnalysisForm : Form
    {
        public CustomerProductAnalysisForm()
        {
            InitializeComponent(); // Initalizes the form and its components
            UpdateChart(); // Updates the chart with customer spending data upon form creation. 
        }

        // Connection string to connect to the Access Database. 
        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=SupermarketProductManagementSystem.accdb";
        // Fetch customer spending data from the database
        private DataTable GetTotalSpendingPerCustomer()
        {
            string query = "SELECT CustomerName, SUM(TotalPrice) AS TotalSpending FROM Orders GROUP BY CustomerName";
            // SQL query to calculate total spending per customer. 
            DataTable dataTable = new DataTable(); // Create a DataTable to store the fetched data. 

            try
            {
                using (OleDbConnection conn = new OleDbConnection(connectionString)) // Set up the database connection. 
                {
                    conn.Open(); // Open the database connection

                    using (OleDbDataAdapter adapter = new OleDbDataAdapter(query, conn))
                    {
                        adapter.Fill(dataTable); // Populate the DataTable with query results
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error fetching data: " + ex.Message);
            }

            return dataTable;
        }

        // Update the chart with customer data
        public void UpdateChart()
        {
            // Fetch data from the database
            DataTable spendingData = GetTotalSpendingPerCustomer();
            
            // Check if there is data to display
            if (spendingData == null || spendingData.Rows.Count == 0)
            {
                MessageBox.Show("No data found to display in the chart!"); // Display a message if no data is available 
                return; // Exit the method. 
            }

            // Clear existing chart data
            chartCustomerAnalysis.Series.Clear();

            // Create a new series for the column chart
            Series series = new Series("Customer Spending")
            {
                ChartType = SeriesChartType.Column, // I will set the chart to column
                XValueType = ChartValueType.String, // X-axis values
                YValueType = ChartValueType.Double // This is Y-Axis will be doubles. 
            };

            chartCustomerAnalysis.Series.Add(series);

            // Add data points to the chart
            foreach (DataRow row in spendingData.Rows)
            {
                string customerName = row["CustomerName"]?.ToString() ?? "Unknown"; // This condition to get Customer name or we will find the Unknow Name
                if (double.TryParse(row["TotalSpending"]?.ToString(), out double totalSpending)) // Parse total spending value
                {
                    series.Points.AddXY(customerName, totalSpending); // This code will be add data point to the chart. 
                }
            }

            // Customize the chart
            var chartArea = chartCustomerAnalysis.ChartAreas[0]; // Access the chart's primary chart area. 
            chartArea.AxisX.Title = "Customer Name"; // Set the X-axis title. 
            chartArea.AxisY.Title = "Total Spending"; // Set the Y-axis title.
            chartArea.AxisX.Interval = 1; // Set the interval between X-axis labels. 
            chartArea.AxisX.IsLabelAutoFit = false; // Disable automaic label fitting. 
             
            // Adjust label angle if necessary (e.g., when there are many customers)
            if (spendingData.Rows.Count > 10) // Arbitrary threshold
            {
                chartArea.AxisX.LabelStyle.Angle = -45; // Rotate labels for better readability
            }
            else
            {
                chartArea.AxisX.LabelStyle.Angle = 0; // Keep Labels horizontal. 
            }

        }

        private void btnReturnMain_Click(object sender, EventArgs e)
        {
            this.Close(); // Close the form when the "Return To Main" button is clicked. 
        }

        private void chartCustomerAnalysis_Click(object sender, EventArgs e)
        {

        }
    }
}
