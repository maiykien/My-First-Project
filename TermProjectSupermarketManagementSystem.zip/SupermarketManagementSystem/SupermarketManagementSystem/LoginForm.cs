
using System.Data.OleDb;
using System.Security.Cryptography;
using System.Text;


namespace SupermarketManagementSystem


{
    public partial class LoginForm : Form
    {
        // Field to store the username entered by the user. 
        string userName;

        // Constructor for the Login Form class. 
        public LoginForm()
        {
            InitializeComponent();
        }

        // I will call the Event Handler when the LoginForm Loads. 
        private void LoginForm_Load(object sender, EventArgs e)
        {
            showImageLogo();
        }


        // Method to display the logo image in the Picture Box
        private void showImageLogo()
        {
            // Set the image for the PictureBox.
            pictureBoxLogo.Image = Image.FromFile(@"Images\ProductManagementLogo.jpg");
            // Adjust the image to fit the Picture size
            pictureBoxLogo.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        // Event handler when "Log In" button is clicked.
        private void btnLogIn_Click(object sender, EventArgs e)
        {
            // get and trim the username and pass entered by the user.
            userName = txtUserName.Text.Trim();
            string passWord = txtPassword.Text.Trim();


            // this One I was using the verification the user using the provided credentials
            if (AuthenticatedUser(userName, passWord))
            {
                // If it successful, I will open the MainScreen and pass the username
                MainScreen main = new MainScreen(userName);
                main.ShowDialog();


            }
            else
            {
                // If authentication fails, display an error message.
                MessageBox.Show("Invalid username or password!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return; // Exit the method. 
            }

        }

        // I will write the function to check 
        // if the account of the user match with the databse
        // Checking autenticated. 

        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=SupermarketProductManagementSystem.accdb";
        private bool AuthenticatedUser(string username, string password)
        {
            string query = "SELECT COUNT(1) FROM Users WHERE Username = @Username AND Password = @Password";

            try
            {
                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    conn.Open();
                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {

                        cmd.Parameters.AddWithValue("@Username", username);
                        cmd.Parameters.AddWithValue("@Password", password);
                        int userCount = Convert.ToInt32(cmd.ExecuteScalar());

                        // Because user count is 1, it's imposible 2 happing. 
                        // I will return user count is 1. 

                        return userCount == 1;

                    }

                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Error while connecting to the database: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;

            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            RegisterForm frm = new RegisterForm();
            frm.ShowDialog();

        }
        private void chkShowPassword_CheckedChange(object sender, EventArgs e)
        {
            // Toggle the visibility of the password
            if (chkShowPassword.Checked)
            {
                txtPassword.PasswordChar = '\0'; // Show password
            }
            else
            {
                txtPassword.PasswordChar = '*'; // Hide password
            }

        }

        private void btnLogIn_Enter(object sender, EventArgs e)
        {
            // get and trim the username and pass entered by the user.
            userName = txtUserName.Text.Trim();
            string passWord = txtPassword.Text.Trim();


            // this One I was using the verification the user using the provided credentials
            if (AuthenticatedUser(userName, passWord))
            {
                // If it successful, I will open the MainScreen and pass the username
                MainScreen main = new MainScreen(userName);
                main.ShowDialog();


            }
            else
            {
                // If authentication fails, display an error message.
                MessageBox.Show("Invalid username or password!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return; // Exit the method. 
            }

        }
    }
}
