﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.VisualStyles;

namespace SupermarketManagementSystem
{
    class Supplier 
    {
        // Private field for storing supplier information
        private int SupplierId;
        private string supplierName;
        private string contactNumber;
        private string supplierEmail;
        private string supplierAddress;
        private string supplierCategory;


        public Supplier() { } // Default constructor,


        // Public property for SupplierID with getter and setter. 
        public int SupplierID
        {
            get { return SupplierId; }
            set { SupplierId = value; }
        }

        // Public property for SupplierName with getter and setter. 
        public string SupplierName
        {
            get { return supplierName; }
            set { supplierName = value; }
        }

        // Public property for ContactNumber
        public string ContactNumber
        {
            get { return contactNumber; }
            set { contactNumber = value; }
        }

        // Public property for SupplierEmail
        public string SupplierEmail
        {
            get { return supplierEmail; }
            set { supplierEmail = value; }
        }


        // Public property for SupplierAddress
        public string SupplierAddress
        {
            get { return supplierAddress; }
            set { supplierAddress = value;}
        }



        // Public property for SupplierCategory
        public string SupplierCategory
        {
            get { return supplierCategory; }
            set { supplierCategory = value; }
        }

        // OverLoaded constructor to initialize supplier properties. 
        public Supplier(string supplierName, string contactNumber, string supplierEmail, string supplierAddress, string supplierCategory)
        {
            this.supplierName = supplierName;
            this.contactNumber = contactNumber;
            this.supplierEmail = supplierEmail;
            this.supplierAddress = supplierAddress;
            this.supplierCategory = supplierCategory;
        }

        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=SupermarketProductManagementSystem.accdb";


        // Method a add supplier to the database. 
        public void AddSupplierToDatabase(Supplier sup)
        {
            string query = "INSERT INTO Suppliers (SupplierName, ContactNumber, SupplierEmail, SupplierAddress, Category)" +
                "VALUES (@SupplierName, @ContactNumber, @SupplierEmail, @SupplierAddress, @Category)";
            try
            {
                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    conn.Open();
                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@SupplierName", SupplierName);
                        cmd.Parameters.AddWithValue("@ContactNumber", ContactNumber);
                        cmd.Parameters.AddWithValue("@SupplierEmail", SupplierEmail);
                        cmd.Parameters.AddWithValue("@SupplierAddress", SupplierAddress);
                        cmd.Parameters.AddWithValue("@Category", supplierCategory);
                        cmd.ExecuteNonQuery();

                        MessageBox.Show("Added Supplier Sucesfully");

                    }
                }
            }

            catch (Exception ex)
            {
                // Catches exceptions and shows an error message. 
                MessageBox.Show("We have an error while adding: " + ex.Message);
            
            }

        }

        // Method to update a supplier in the database. 

        public void UpdateSupplierToDatabase(int SupplierID)
        {
            string query = "UPDATE Suppliers SET SupplierName = @SupplierName, ContactNumber = @ContactNumber, SupplierEmail = @SupplierEmail, SupplierAddress = @SupplierAddress, Category = @Category WHERE SupplierID = @SupplierID";

            try
            {
                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    conn.Open(); // Opens the connection. 
                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        // Add parameters for the query
                        cmd.Parameters.AddWithValue("@SupplierName", SupplierName);
                        cmd.Parameters.AddWithValue("@ContactNumber", ContactNumber);
                        cmd.Parameters.AddWithValue("@SupplierEmail", SupplierEmail);
                        cmd.Parameters.AddWithValue("@SupplierAddress", SupplierAddress);
                        cmd.Parameters.AddWithValue("@Category", SupplierCategory);
                        cmd.Parameters.AddWithValue("@SupplierID", SupplierID);

                        // Execute the query
                        cmd.ExecuteNonQuery();

                        MessageBox.Show("Supplier updated successfully!");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("We have an error while updating supplier: " + ex.Message);
            }
        }


        // Public property for SupplierEmail
        public void DeleteSupplierToDatabase(int SupplierID)
        {
            string query = "DELETE FROM Suppliers WHERE SupplierID = @SupplierID";
            try
            {
                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    conn.Open(); // Opens the connection
                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@SupplierID", SupplierID); // Adds the SupplierID parameter
                        cmd.ExecuteNonQuery(); // Executes the deletions
                        MessageBox.Show("Supplier Deteled Successfully!"); // Success message. 
                    }
                }
            }
            catch (Exception ex) 
            {
                // Handles any error during the deletion. 
                MessageBox.Show("We have an error while deleting: " + ex.Message);
            }


        }

    }
}
