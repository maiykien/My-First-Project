﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices.Marshalling;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace SupermarketManagementSystem
{

    public partial class ProductForm : Form
    {
        // This is constructor: Initializes the form components and loads category data into the dropdown. 
        public ProductForm()
        {
            InitializeComponent(); // Initialize from components
            LoadCategory(); // Populates the category combo box. 
        }

        // Loads perdefined categories into the combo box.
        private void LoadCategory()
        {
            // Array of category names
            string[] nameCategogy = { "Select a Category", "Fruits", "Bakery", "Dairy", "Frozen Food", "Vegetables", "Pantry", "Meat" };
            // Add each category to the combo box
            foreach (string name in nameCategogy)
            {
                cboCategory.Items.Add(name);
            }
            // Set default selection to the first item. 
            cboCategory.SelectedIndex = 0;
        }

        // Event handler for form load event. 
        private void ProductFrom_Load(object sender, EventArgs e)
        {
            LoadProductsByCategory("Category"); // Call the method to Load products by default category.

            try
            {
                LoadProductFromDatabase(); // Loads all products into the grid.

                if (dgvProductInventory.Rows.Count > 0) // Check if any rows are load. 
                {
                    // Select the first row
                    dgvProductInventory.Rows[0].Selected = true;
                    LoadProductDetails(0); // Load details of the first product. 
                }
            }
            catch (Exception ex) // Handle exception during data loading. 
            {
                MessageBox.Show($"Error to Loading product detail: " + ex.Message);
            }
        }

        // Loads products filter product. 
        private void LoadProductsByCategory(string category)
        {
            // I created the Product Instance.
            Product product = new Product();

            DataTable productData = product.LoadDataFromDatabase(category); // Fetch data based on category

            if (productData != null) // If data is successully fetched. 
            {
                dgvProductInventory.DataSource = productData; // This code to binding data to grid.
            }
            else
            {
                MessageBox.Show("Failed to load products for the selected category.", "Error");
            }

        }

        // Event handler for Reload Button to refresh product data. 
        private void btnReloadProduct_Click(object sender, EventArgs e)
        {
            LoadProductFromDatabase(); // Reload all product data. 

        }

        // connection string for the database.
        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=SupermarketProductManagementSystem.accdb";

        // Load all products from database.
        private void LoadProductFromDatabase()
        {
            string query = "SELECT * FROM Products"; // Query to fetch all products

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                conn.Open(); // Open connection

                using (OleDbDataAdapter adap = new OleDbDataAdapter(query, conn))
                {

                    DataTable dt = new DataTable(); // Create a data table
                    adap.Fill(dt); // Fill Data Table with query result
                    dgvProductInventory.DataSource = dt; // Bind data to grid. 
                }
            }
        }

        // Event handler for category selecttion changes in the combo box
        private void cboCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedItem = "";

            if (cboCategory.SelectedIndex >= 0) // Ensure a valid selection. 
            {
                selectedItem = cboCategory.SelectedItem.ToString();
                // Handle selected category 
            }
            else
            {
                Console.WriteLine("No category selected.");
            }

            // I need to use the switch case for each category product I was using 
            // to select. 

            // Repeat similar logic for other categories.
            switch (selectedItem)
            {
                case "Fruits":
                    PictureBoxProductImage.Image = Image.FromFile(@"Images\Fruit.jpg");
                    PictureBoxProductImage.SizeMode = PictureBoxSizeMode.StretchImage;
                    break;

                case "Bakery":
                    PictureBoxProductImage.Image = Image.FromFile(@"Images\Bakery.jpg");
                    PictureBoxProductImage.SizeMode = PictureBoxSizeMode.StretchImage;
                    break;

                case "Dairy":
                    PictureBoxProductImage.Image = Image.FromFile(@"Images\DairyMilk.png");
                    PictureBoxProductImage.SizeMode = PictureBoxSizeMode.StretchImage;
                    break;

                case "Frozen Food":
                    PictureBoxProductImage.Image = Image.FromFile(@"Images\FrozenFood.jpg");
                    PictureBoxProductImage.SizeMode = PictureBoxSizeMode.StretchImage;
                    break;

                case "Vegetables":
                    PictureBoxProductImage.Image = Image.FromFile(@"Images\Vegetables.jpg");
                    PictureBoxProductImage.SizeMode = PictureBoxSizeMode.StretchImage;
                    break;

                case "Pantry":
                    PictureBoxProductImage.Image = Image.FromFile(@"Images\Pantry.jpg");
                    PictureBoxProductImage.SizeMode = PictureBoxSizeMode.StretchImage;
                    break;

                case "Meat":
                    PictureBoxProductImage.Image = Image.FromFile(@"Images\Meat.jpg");
                    PictureBoxProductImage.SizeMode = PictureBoxSizeMode.StretchImage;
                    break;

                default:
                    // If no category selected or unexpected selection, clear the image
                    PictureBoxProductImage.Image = null;
                    break;
            }

        }

        // Event handler for adding a new product.
        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtProductName.Text) ||
                string.IsNullOrWhiteSpace(txtPrice.Text) ||
                string.IsNullOrWhiteSpace(txtStockLevel.Text) ||
        cboCategory.SelectedItem == null)
            {
                MessageBox.Show("Please fill all required fields and select a category.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return; // Stop execution if validation fails. 
            }

            // Initialize some of the
            string productName = txtProductName.Text;
            string productDescription = txtDescription.Text;
            double productPrice = Convert.ToDouble(txtPrice.Text);
            int stockLevel = Convert.ToInt32(txtStockLevel.Text);
            string productCategory = cboCategory.SelectedItem.ToString();
            string productImageURL = txtProductImageURL.Text;

            Product pro = new Product(productName, productDescription, productPrice, stockLevel, productCategory, productImageURL);

            // Check for duplicate ProductName
            if (pro.IsDuplicateName(productName))
            {
                MessageBox.Show("A product with this name already exists. Please choose a different name.", "Duplicate Product", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // Exit without adding the product
            }

            pro.AddProductToDatabase(pro); // Add product to database
            pro.UpdateSupplierNamesByCategory(); // Update supplier names
            LoadProductFromDatabase(); // Refresh grid with new data. 
            ClearProductFormFields(); // Clear form fields. 
        }

        // I want to make when I run the product. 
        // It's showing the first auto slected row. 

        private void LoadProductDetails(int rowIndex)
        {
            // Using try-catch in case of unexpected errors
            try
            {
                // Ensure the data clicked is valid
                if (rowIndex >= 0 && dgvProductInventory.Rows.Count > rowIndex)
                {
                    // Get the selected row
                    DataGridViewRow selectedRow = dgvProductInventory.Rows[rowIndex];

                    // Populate the text boxes with product details
                    txtName.Text = selectedRow.Cells["ProductName"].Value?.ToString() ?? string.Empty;
                    txtDescription2.Text = selectedRow.Cells["ProductDescription"].Value?.ToString() ?? string.Empty;
                    txtPrice2.Text = selectedRow.Cells["price"].Value?.ToString() ?? string.Empty;
                    txtStockLevel2.Text = selectedRow.Cells["StockLevel"].Value?.ToString() ?? string.Empty;
                    txtCategory2.Text = selectedRow.Cells["Category"].Value?.ToString() ?? string.Empty;

                    // Load the image
                    string imageURL = selectedRow.Cells["ProductImageURL"].Value?.ToString();

                    if (!string.IsNullOrWhiteSpace(imageURL))
                    {
                        try
                        {
                            pictureBoxImage.Load(imageURL); // Try to load the image from the URL or file path
                        }
                        catch
                        {
                            // Fallback to a "Not Found" image if loading fails
                            pictureBoxImage.Image = Image.FromFile(@"Images\ImageNotFound.jpg");
                        }
                    }
                    else
                    {
                        // Show the "Not Found" image if the URL is empty or null
                        pictureBoxImage.Image = Image.FromFile(@"Images\ImageNotFound.jpg");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading product details: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Clears all input fields in the product form. 
        private void ClearProductFormFields()
        {
            // Clears the text from the text box product name.
            txtProductName.Clear();
            txtDescription.Clear(); // clear the text box description
            txtPrice.Clear(); // clear the text box for the price
            txtStockLevel.Clear(); // Clear the text box for the stock level.
            cboCategory.SelectedIndex = -1; // clear the combo box for Category
            txtProductImageURL.Clear(); // Also clear the textbox for product Image
            pictureBoxImage.Image = null;
        }


        // Using the cell click to load all the picture box 
        // And all the product detail in the form
        private void dgvProductInventory_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                LoadProductDetails(e.RowIndex); // I called this function cause I want to load details of the product from the clicked row.
            }
            catch (Exception ex)
            {
                // Display an error message If I get the loading product details fails.
                MessageBox.Show($"Error to Loading product detail: " + ex.Message);

            }

        }

        // Handle the Click event for the modify Product button
        // Opens the ModifyProductForm allow the user to edit product details.
        private void btnModifyProduct_Click(object sender, EventArgs e)
        {
            ModifyProductForm modify = new ModifyProductForm();
            modify.ShowDialog(); // Show the form as modal dialog
        }

        private string productName;

        // Handles the Click event for the delete Product Button
        // Opens the DeleteForm to allow the user to confirm or manage product. 
        private void btnDeleteProduct_Click(object sender, EventArgs e)
        {

            DeleteForm deleteForm = new DeleteForm();
            deleteForm.ShowDialog();

        }


        // This handle for SelectionChanged event for the DataGridVuew control
        // That would be update the "productName" field with the name of the currently selected product. 
        private void dgvProductInventory_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvProductInventory.SelectedRows.Count > 0)
            {
                // Retrieve the product name from the "ProductName" column of the selected row.
                productName = dgvProductInventory.SelectedRows[0].Cells["ProductName"].Value.ToString();
            }
        }

        private void btnReturnDashBoard_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
