﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace SupermarketManagementSystem
{
    public partial class ManageUserAccountForm : Form // Represents the form for managing user accounts. 
    {
        public ManageUserAccountForm() // Constructor for the form.
        {
            InitializeComponent(); // Initializes the form's components
            LoadUserAccountIntoGrid(); // Loads user accounts into the DataGridView Upon form initialization. 
        }

        private void ManageUserAccountForm_Load(object sender, EventArgs e) //Event handler for form load. 
        {

            LoadUserAccountIntoGrid(); // Ensure the user account are Loaded into the DataGridView. 

        }

        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=SupermarketProductManagementSystem.accdb";
        // Connection string for accessing the database. 

        public void LoadUserAccountIntoGrid() // Loads user account data into the DataGridView. 
        {
            string query = "SELECT * FROM Users"; // SQL query to fetch all user data. 

            using (OleDbConnection conn = new OleDbConnection(connectionString)) // Set up the connection to the database.
            {

                conn.Open(); // opens the database connection. 

                using (OleDbDataAdapter adapt = new OleDbDataAdapter(query, conn))
                {
                    DataTable dt = new DataTable();
                    adapt.Fill(dt);
                    dgvViewUserAccount.DataSource = dt;
                }
            }
        }

        private void btnCreateNewAccount_Click(object sender, EventArgs e)
        {
            string userName = txtUserName.Text; // Retrieves the entered username
            string password = txtPassword.Text; // Retrieves the entered password.
            string confirmPassword = txtConfirmPassword.Text; // Retrieves the entered confirmation password.
            string email = txtEmail.Text; // Retrieves the entered email

            // I will go over to check the Validation of the Input
            // and I want to make sure all the field is not empty. 

            if (string.IsNullOrEmpty(userName) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("All fields are required.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validate the input for Confirmpassword
            // and validate for the Email
            if (string.IsNullOrEmpty(confirmPassword) || string.IsNullOrEmpty(email))
            {
                MessageBox.Show("All fields are required.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Check the password and confirmpassword of the 
            // User will be match to each other.

            if (password != confirmPassword)
            {
                MessageBox.Show("Password Do Not Match!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (isValidEmail(email))
            {
                MessageBox.Show("Email is valid!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {

                MessageBox.Show("Please enter a valid email address.", "Invalid Email", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }

            User user = new User(userName, password, email);

            user.AddUserAccount(user);

            LoadUserAccountIntoGrid();

            ClearUserFormField();


        }
        // Sometime I need to check the valid email as well.
        private bool isValidEmail(string email)
        {
            try
            {
                var addr = new MailAddress(email); // Attempts to parse the email address.
                return addr.Address == email; // Confirms if the parsed address matches with the input. 
            }
            catch
            {
                return false; // Returns false if the email is invalid. 
            }
        }
        string userName; // this is to hold the username of the selected user.
        string password; // Hold the password of the selected user.
        private void btnDeleteUserAccount_Click(object sender, EventArgs e)
        {
            User user = new User(); // Create a new user object. 

            if (dgvViewUserAccount.Rows.Count > 0)
            {
                // Retrieves the selected username and password. 
                userName = dgvViewUserAccount.SelectedRows[0].Cells["Username"].Value.ToString();
                password = dgvViewUserAccount.SelectedRows[0].Cells["Password"].Value.ToString();
            }

            // Show confirmation dialog with the customer name
            DialogResult dialogResult = MessageBox.Show(
                "Are you sure you want to delete the user account: " + userName + "?",
                "Confirm Delete",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            // If the user clicks 'Yes', open the update form
            if (dialogResult == DialogResult.Yes)
            {
                // Open the UpdateForm and pass the customer data
                user.DeleteUserAccount(userName);

                // After the delete, refresh the data grid
                LoadUserAccountIntoGrid();
            }


        }

        private void btnUpdatePassword_Click(object sender, EventArgs e)
        {
            // Check if there are rows in the DataGridView. 
            if (dgvViewUserAccount.Rows.Count > 0)
            {
                // Retrieve the username from the selected row in the datagridview.
                userName = dgvViewUserAccount.SelectedRows[0].Cells["Username"].Value.ToString();
                // Retrieve the password from the selected row in the datagridview.
                password = dgvViewUserAccount.SelectedRows[0].Cells["Password"].Value.ToString();

            }

            DialogResult dialogResult = MessageBox.Show(
                "Are you sure you want to update the password for " + userName + "?",
                "Confirm Delete",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            // If the user clicks 'Yes', open the update form
            if (dialogResult == DialogResult.Yes)
            {

                UpdatePasswordForm update = new UpdatePasswordForm(password, userName); // Open the password update form. 
                update.ShowDialog(); // Display the form as a model dialog.

            }
        }

        // Clear the input field in the forms. 
        private void ClearUserFormField()
        {
            txtUserName.Clear();
            txtPassword.Clear();
            txtConfirmPassword.Clear();
            txtEmail.Clear();
        }

        // Event handler for the "ReLoad User" button click. 
        private void btnReloadUser_Click(object sender, EventArgs e)
        {
            LoadUserAccountIntoGrid(); // Refreshes the DataGrideView with update user data. 
        }

        private void btnReturnUser_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgvViewUserAccount_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
