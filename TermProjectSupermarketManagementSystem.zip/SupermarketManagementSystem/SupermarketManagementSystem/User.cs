﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SupermarketManagementSystem
{
    internal class User
    {
        public string UserName; // Field to store the username
        public string Password; // Field to store the password.
        public string Email; // Field to store the email.

        public User()
        {


        }

        public User(string UserName, string PassWord, string Email)
        {
            this.UserName = UserName; // that would be assign the provided username to the "Username" field
            this.Password = PassWord; //Assign the provided password to the "Password" field
            this.Email = Email; //Assigns the provided email to the "Email" field.
        }

        public string userName
        {
            get { return this.UserName; } // Returns the user name
            set { this.UserName = value; } // Sets the username.
        }

        public string passWord
        {
            get { return this.Password; } // Return the password
            set { this.Password = value; } // Sets the password. 
        }

        public string email
        {
            get { return this.Email; } // return the email
            set { this.Email = value; } // Sets the email
        }

        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=SupermarketProductManagementSystem.accdb";
        // Connection string to the database. 

        public void AddUserAccount(User user)
        {
            string query = "INSERT INTO Users ([Username], [Password], [Email]) VALUES (@Username, @Password, @Email)";
            // SQL query to insert a new user. 
            try
            {
                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    conn.Open(); // Open the database connection. 

                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Username", userName); // Binds the username to the query.
                        cmd.Parameters.AddWithValue("@Password", passWord); // Bind the password to the query.
                        cmd.Parameters.AddWithValue("@Email", email); // Binds the email to the query
                        cmd.ExecuteNonQuery(); // Execute the query
                        MessageBox.Show("Create User Successfully"); // Display a success massgae. 
                    }
                }
            }
            catch (Exception ex)  // Catches any errors that occur during execution. 
            {
                MessageBox.Show("Error while adding the new User Account " + ex.Message);
            }

        }
        public void DeleteUserAccount(String userName)
        {
            // SQL query to delete a user by username
            string query = "DELETE FROM Users WHERE Username = @Username";
            try
            {
                // Create a connection to the database. 
                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    // Opens the database connection
                    conn.Open();
                    // Prepares the SQL command for execution.
                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        // Binds the username to the query.
                        cmd.Parameters.AddWithValue("@Username", userName);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Delete User Account Successfully");
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while deleting the user account " + ex.Message);
            }

        }

        public void UpdateUserPassword(String userName, String password) 
        {

            string query = "UPDATE [Users] SET [Password] = @Password WHERE [Username] = @Username";
            // SQL query to update the password for a specific username.
            try
            {
                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    conn.Open(); // Opens the database connection
                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Password", password); // Binds the new password to the query
                        cmd.Parameters.AddWithValue("@Username", userName); // Binds the username to the query
                        cmd.ExecuteNonQuery(); //Executes the query
                        MessageBox.Show("Password updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }
                }
            }
            catch (Exception ex)  // Catches any error that occurs during execution. 
            { 
                MessageBox.Show("Error while updating the password " + ex.Message);
            }
        }
    }
}
