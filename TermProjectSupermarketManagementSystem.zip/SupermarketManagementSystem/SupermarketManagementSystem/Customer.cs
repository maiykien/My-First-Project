﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SupermarketManagementSystem
{
    public class Customer
    {
        public int CustomerID;
        private string CustomerName;
        private string CustomerPhone;
        private string CustomerEmail;
        private string CustomerAddress;
        private string CustomerCity;
        private string CustomerState;
        private string CustomerZipCode;

        public Customer(string CustomerName, string CustomerPhone, string CustomerEmail, string CustomerAddress, string CustomerCity, string CustomerState, string CustomerZipCode)
        {

            this.CustomerName = CustomerName;
            this.CustomerPhone = CustomerPhone;
            this.CustomerEmail = CustomerEmail;
            this.CustomerAddress = CustomerAddress;
            this.CustomerCity = CustomerCity;
            this.CustomerState = CustomerState;
            this.CustomerZipCode = CustomerZipCode;
        }


        public int customerID
        {
            get { return this.CustomerID; }
            set { CustomerID = value; }
        }
        public string customerName
        {
            get { return CustomerName; } 
            set { this.CustomerName = value; }
        }

        public string customerPhone
        {
            get { return CustomerPhone; }
            set { CustomerPhone = value; }
        }

        public string customerEmail
        {
            get { return CustomerEmail; }
            set { CustomerEmail = value; }
        }

        public string customerAddress
        {
            get { return CustomerAddress; }
            set { CustomerAddress = value; }
        }

        public string customerCity
        {
            get { return CustomerCity; }
            set { CustomerCity = value; }
        }

        public string customerState
        {
            get { return CustomerState; }
            set { CustomerState = value; }
        }

        public string customerZipCode
        {
            get { return CustomerZipCode; }
            set { CustomerZipCode = value; }
        }

        public Customer()
        {

        }

        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=SupermarketProductManagementSystem.accdb";
        public void InsertCustomerDatabase(Customer customer)
        {
            string query = "INSERT INTO Customers(CustomerName, PhoneNumber, Email, Address, City, State, ZipCode)" +
                 "VALUES(@CustomerName, @PhoneNumber, @Email, @Address, @City, @State, @ZipCode)";

            try
            {
                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    conn.Open();

                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {

                        cmd.Parameters.AddWithValue("@CustomerName", customerName);
                        cmd.Parameters.AddWithValue("@PhoneNumber", customerPhone);
                        cmd.Parameters.AddWithValue("@Email", customerEmail);
                        cmd.Parameters.AddWithValue("@Address", customerAddress);
                        cmd.Parameters.AddWithValue("@City", customerCity);
                        cmd.Parameters.AddWithValue("@State", customerState);
                        cmd.Parameters.AddWithValue("@ZipCode", customerZipCode);

                        // I will process to Execute the query
                        cmd.ExecuteNonQuery();
                        MessageBox.Show(" Saved Customer into database successfully! ");
                        conn.Close();

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while saving product!!" + ex.Message);
            }

        }
        public DataTable LoadCustomerIntoDataGridView()
        {
            string query = "SELECT * FROM Customers";

            try
            {
                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {

                    conn.Open();

                    using (OleDbDataAdapter adapter = new OleDbDataAdapter(query, conn))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        return dt;
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Error loading data from the database: " + ex.Message, "Error");
                return null;  // Return null instead of an integer on error


            }
        }


        // This section to get the Customer ID 

        // Method to read the object customer from the datagrid view
        // After we found the SelectedID.
        public Customer FindCustomerID(int customerID)
        {
            // Assign the Customer is Null
            Customer customer = null;
            // need to be query to find all the customer information
            // need to be update.
            string query = "SELECT * FROM Customers WHERE CustomerID = @CustomerID";

            using (OleDbConnection conn = new OleDbConnection(connectionString)) { 
                conn.Open();
                using (OleDbCommand cmd = new OleDbCommand(query, conn)) { 
                
                    cmd.Parameters.AddWithValue("@CustomerID", customerID);
                    
                    // Read the data for each column and getting the data
                    // This step to prepare to pass into the Update Form.
                    using(OleDbDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read()) {
                            customer = new Customer(
                            reader["CustomerName"].ToString(),
                            reader["PhoneNumber"].ToString(),
                            reader["Email"].ToString(),
                            reader["Address"].ToString(),
                            reader["City"].ToString(),
                            reader["State"].ToString(),
                            reader["ZipCode"].ToString()
                            );
                        }

                    }
                }
            }

            return customer;

        }

        // This method to update the customer to the database: 
        public void UpdateCustomerInDatabase(Customer customer)
        {
            string query = "UPDATE Customers SET CustomerName = @CustomerName, PhoneNumber = @PhoneNumber, " +
                           "Email = @Email, Address = @Address, City = @City, State = @State, ZipCode = @ZipCode " +
                           "WHERE CustomerID = @CustomerID";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                conn.Open();

                using (OleDbCommand cmd = new OleDbCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@CustomerName",customer.customerName);
                    cmd.Parameters.AddWithValue("@PhoneNumber", customer.customerPhone);
                    cmd.Parameters.AddWithValue("@Email", customer.customerEmail);
                    cmd.Parameters.AddWithValue("@Address", customer.customerAddress);
                    cmd.Parameters.AddWithValue("@City", customer.customerCity);
                    cmd.Parameters.AddWithValue("@State", customer.customerState);
                    cmd.Parameters.AddWithValue("@ZipCode", customer.customerZipCode);
                    cmd.Parameters.AddWithValue("@CustomerID",customer.customerID); // Use the stored CustomerID

                    int rowsAffected = cmd.ExecuteNonQuery();




                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Customer updated successfully!");
                    }
                    else
                    {
                        MessageBox.Show("Update failed. Please check the CustomerID or data.");
                    }
                }
            }
        }

        // Method to delete customer from the order. 

        public void DeleteCustomerInDatabase(int customerID)
        {
            string query = "DELETE FROM Customers WHERE CustomerID = @CustomerID";

            try
            {
                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    conn.Open();
                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@CustomerID", customerID);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Deleted Customer" + customerName + "Sucessfully!");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while deleting: " + ex.Message);
            }
        }

    }
}
