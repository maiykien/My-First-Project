﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SupermarketManagementSystem
{
    public partial class UpdatePasswordForm : Form
    {
        private string oldPassword; // This code to stores the user's current password for validation. 
        private string userName; // Stores the username of the account being updatd. 
        ManageUserAccountForm ManageUserAccountForm; // I use to reference to the parent form (not used directly in this video). 
        public UpdatePasswordForm(string oldPassword, string userName)
        {
            InitializeComponent(); // Initializes the form and its component
            this.oldPassword = oldPassword; // Assigns the username to the class-level variable
            this.userName = userName; // This is to assign the username.
            txtCurrentPassword.Text = oldPassword; //Pre-fills the current password field

        }

        private void UpdatePasswordForm_Load(object sender, EventArgs e)
        {

        }

        private void btnUpdateNewPassword_Click(object sender, EventArgs e)
        {
            User user = new User(); // Creates an instance of the User class. 

            // Retrieve input values
            string currentPassword = txtCurrentPassword.Text; // Get the current password entered by the user. 
            string newPassword = txtNewPassword.Text; // Gets the new password entered by the user. 
            string confirmNewPassword = txtConfirmPassword.Text; // Gets the confirmation password entered by the user. 

            // Check if the New Password and Confirm New Password fields are empty
            if (string.IsNullOrWhiteSpace(newPassword) || string.IsNullOrWhiteSpace(confirmNewPassword))
            {
                MessageBox.Show("Please enter both the New Password and Confirm New Password.", "Input Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Check if the new password is the same as the old password
            if (newPassword == currentPassword)
            {
                MessageBox.Show("The new password cannot be the same as the current password.", "Invalid Password", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Check if the new password and confirm password match
            if (newPassword != confirmNewPassword)
            {
                MessageBox.Show("The new password and confirmation password do not match.", "Mismatch", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Proceed with password update logic
            try
            {
                user.UpdateUserPassword(userName, newPassword);
                MessageBox.Show("Password updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while updating the password: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void btnReturnUser_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
