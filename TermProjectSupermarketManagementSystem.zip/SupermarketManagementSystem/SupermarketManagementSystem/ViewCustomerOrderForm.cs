﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace SupermarketManagementSystem
{
    public partial class ViewCustomerOrderForm : Form
    {
        public ViewCustomerOrderForm() // Constructor for initializing the form
        {
            InitializeComponent(); // Initializes.
        }

        private void ViewCustomerOrderForm_Load(object sender, EventArgs e) // Event  handler for Form Load. 
        {

            LoadCustomerViewOrder(); // Call method to load customer orders into the View. 

        }

        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=SupermarketProductManagementSystem.accdb";

        // Connection string for accessing the database. 
        private void LoadCustomerViewOrder() // Loads customer orders into a data grid view. 
        {
            string query = "SELECT OrderID, CustomerID, CustomerName, ProductName, Quantity, TotalPrice FROM Orders;";

            try
            {
                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    conn.Open(); // Opens the database connection.

                    using (OleDbDataAdapter adap = new OleDbDataAdapter(query, conn))
                    {
                        DataTable dt = new DataTable(); // DataTable to hold query results. 
                        adap.Fill(dt); // Fills datatable with data from the query.
                        dgvViewCustomerOrder.DataSource = dt; // Binds the data to the DataGridView. 
                    }
                }
            }
            catch (Exception ex) // Handles any exceptions during the database operation.
            {
                MessageBox.Show("Error for loading the view customer." + ex.Message);
            }

        }

        private int OrderID = -1; // Store the selected order ID
        private string prductName; // Stores the selected product name
        private string customerName; // Stores the selected customer name. 

        // Load details of a selected order. 
        private void LoadViewCustomerOrderDetails(int rowIndex)
        {
            try
            {
                // Check if the provided rowIndex is valid
                if (rowIndex >= 0 && dgvViewCustomerOrder.Rows.Count > rowIndex)
                {
                    DataGridViewRow selectedRow = dgvViewCustomerOrder.Rows[rowIndex];
                    // this code would be retrieves the selected row.
                    OrderID = Convert.ToInt32(selectedRow.Cells["OrderID"].Value);
                    // Extracts and stores the OrderID.

                    // Extracts and sets the details of the selected order. 
                    txtCustomer.Text = selectedRow.Cells["CustomerName"].Value?.ToString() ?? string.Empty;
                    txtProductName.Text = selectedRow.Cells["ProductName"].Value?.ToString() ?? string.Empty;
                    txtQuantity.Text = selectedRow.Cells["Quantity"].Value?.ToString() ?? string.Empty;
                    txtTotalPrice.Text = selectedRow.Cells["TotalPrice"].Value?.ToString() ?? string.Empty;
                    customerName = txtCustomer.Text; // Sets the customer name
                    prductName = txtProductName.Text; // Sets the product name.
                }
                else
                {
                    // Displays a warning for invalid row selection. 
                    MessageBox.Show("Invalid row selection. Please select a valid order row.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex) // Handle any exceptions while loading details. 
            {
                MessageBox.Show($"Error loading customer order details: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDeleteOrder_Click(object sender, EventArgs e)
        {

            Order order = new Order
            {
                productName = txtProductName.Text, // Set the product name
                customerName = txtCustomer.Text // Set the customer name

            };

            if (order != null) // Checks if the order object is valid
            {
                // Show confirmation dialog with the customer name
                DialogResult dialogResult = MessageBox.Show(
                    "Are you sure you want to delete order " + order.productName + " for the customer: " + order.customerName + "?",
                    "Confirm Delete",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question

                );

                // If the user clicks 'Yes', open the update form
                if (dialogResult == DialogResult.Yes)
                {

                    order.DeleteViewCustomerFromDatabase(OrderID);
                    LoadCustomerViewOrder();
                }
                else
                {
                    this.Close();
                }

            }
        }


        // This would be handles cell click event in the DataGridView. 
        private void dgvViewCustomerOrder_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                LoadViewCustomerOrderDetails(e.RowIndex); // Loads details of the clicked row. 
            }
            catch (Exception ex) // Handles any exception  during operations. 
            {
                MessageBox.Show($"Error to Loading View Customer Order detail: " + ex.Message);

            }
        }

        private void btnReturnMain_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
