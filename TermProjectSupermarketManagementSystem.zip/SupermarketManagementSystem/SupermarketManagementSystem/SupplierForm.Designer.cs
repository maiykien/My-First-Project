﻿namespace SupermarketManagementSystem
{
    partial class SupplierForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtContactNumber = new TextBox();
            lblContactNumber = new Label();
            txtAddress = new TextBox();
            txtEmail = new TextBox();
            txtSupplierName = new TextBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            btnAddSupplier = new Button();
            btnEditSupplier = new Button();
            btnDeleteSupplier = new Button();
            dgvSupplier = new DataGridView();
            btnReturnDashboard = new Button();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            btnReload = new Button();
            label8 = new Label();
            cboCategory = new ComboBox();
            ((System.ComponentModel.ISupportInitialize)dgvSupplier).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Chartreuse;
            label1.CausesValidation = false;
            label1.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            label1.Location = new Point(543, 9);
            label1.Name = "label1";
            label1.Size = new Size(175, 32);
            label1.TabIndex = 0;
            label1.Text = "Supplier Form";
            // 
            // txtContactNumber
            // 
            txtContactNumber.BackColor = SystemColors.InactiveCaption;
            txtContactNumber.Location = new Point(877, 133);
            txtContactNumber.Name = "txtContactNumber";
            txtContactNumber.Size = new Size(280, 27);
            txtContactNumber.TabIndex = 38;
            // 
            // lblContactNumber
            // 
            lblContactNumber.AutoSize = true;
            lblContactNumber.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblContactNumber.Location = new Point(709, 134);
            lblContactNumber.Name = "lblContactNumber";
            lblContactNumber.Size = new Size(149, 23);
            lblContactNumber.TabIndex = 37;
            lblContactNumber.Text = "Contact Number:";
            // 
            // txtAddress
            // 
            txtAddress.BackColor = SystemColors.InactiveCaption;
            txtAddress.Location = new Point(877, 222);
            txtAddress.Name = "txtAddress";
            txtAddress.Size = new Size(280, 27);
            txtAddress.TabIndex = 29;
            // 
            // txtEmail
            // 
            txtEmail.BackColor = SystemColors.InactiveCaption;
            txtEmail.Location = new Point(877, 179);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(280, 27);
            txtEmail.TabIndex = 28;
            // 
            // txtSupplierName
            // 
            txtSupplierName.BackColor = SystemColors.InactiveCaption;
            txtSupplierName.BorderStyle = BorderStyle.FixedSingle;
            txtSupplierName.Location = new Point(877, 85);
            txtSupplierName.Name = "txtSupplierName";
            txtSupplierName.Size = new Size(280, 27);
            txtSupplierName.TabIndex = 27;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label4.Location = new Point(761, 222);
            label4.Name = "label4";
            label4.Size = new Size(79, 23);
            label4.TabIndex = 26;
            label4.Text = "Address:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label3.Location = new Point(791, 179);
            label3.Name = "label3";
            label3.Size = new Size(64, 23);
            label3.TabIndex = 25;
            label3.Text = "Email: ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label2.Location = new Point(723, 85);
            label2.Name = "label2";
            label2.Size = new Size(135, 23);
            label2.TabIndex = 24;
            label2.Text = "Supplier Name:";
            // 
            // btnAddSupplier
            // 
            btnAddSupplier.BackColor = Color.Lime;
            btnAddSupplier.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnAddSupplier.Location = new Point(947, 318);
            btnAddSupplier.Name = "btnAddSupplier";
            btnAddSupplier.Size = new Size(135, 43);
            btnAddSupplier.TabIndex = 49;
            btnAddSupplier.Text = "Add Supplier";
            btnAddSupplier.UseVisualStyleBackColor = false;
            btnAddSupplier.Click += btnAddSupplier_Click;
            // 
            // btnEditSupplier
            // 
            btnEditSupplier.BackColor = Color.LightCoral;
            btnEditSupplier.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnEditSupplier.Location = new Point(947, 367);
            btnEditSupplier.Name = "btnEditSupplier";
            btnEditSupplier.Size = new Size(135, 43);
            btnEditSupplier.TabIndex = 50;
            btnEditSupplier.Text = "Edit Supplier";
            btnEditSupplier.UseVisualStyleBackColor = false;
            btnEditSupplier.Click += btnEditSupplier_Click;
            // 
            // btnDeleteSupplier
            // 
            btnDeleteSupplier.BackColor = Color.MediumTurquoise;
            btnDeleteSupplier.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnDeleteSupplier.ForeColor = SystemColors.ActiveCaptionText;
            btnDeleteSupplier.Location = new Point(947, 418);
            btnDeleteSupplier.Name = "btnDeleteSupplier";
            btnDeleteSupplier.Size = new Size(135, 43);
            btnDeleteSupplier.TabIndex = 51;
            btnDeleteSupplier.Text = "Delete Supplier";
            btnDeleteSupplier.UseVisualStyleBackColor = false;
            btnDeleteSupplier.Click += btnDeleteSupplier_Click;
            // 
            // dgvSupplier
            // 
            dgvSupplier.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvSupplier.Location = new Point(12, 76);
            dgvSupplier.Name = "dgvSupplier";
            dgvSupplier.ReadOnly = true;
            dgvSupplier.RowHeadersWidth = 51;
            dgvSupplier.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvSupplier.Size = new Size(693, 239);
            dgvSupplier.TabIndex = 52;
            // 
            // btnReturnDashboard
            // 
            btnReturnDashboard.BackColor = Color.Maroon;
            btnReturnDashboard.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnReturnDashboard.ForeColor = SystemColors.Control;
            btnReturnDashboard.Location = new Point(920, 467);
            btnReturnDashboard.Name = "btnReturnDashboard";
            btnReturnDashboard.Size = new Size(210, 43);
            btnReturnDashboard.TabIndex = 53;
            btnReturnDashboard.Text = "Return To DashBoard";
            btnReturnDashboard.UseVisualStyleBackColor = false;
            btnReturnDashboard.Click += btnReturnDashboard_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(974, 38);
            label5.Name = "label5";
            label5.Size = new Size(0, 20);
            label5.TabIndex = 54;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label6.ForeColor = SystemColors.ControlText;
            label6.Location = new Point(920, 30);
            label6.Name = "label6";
            label6.Size = new Size(183, 28);
            label6.TabIndex = 55;
            label6.Text = "Add New Supplier";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = SystemColors.ControlDark;
            label7.CausesValidation = false;
            label7.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label7.Location = new Point(209, 45);
            label7.Name = "label7";
            label7.Size = new Size(161, 28);
            label7.TabIndex = 56;
            label7.Text = "List All Supplier";
            // 
            // btnReload
            // 
            btnReload.BackColor = Color.MediumTurquoise;
            btnReload.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnReload.ForeColor = SystemColors.ActiveCaptionText;
            btnReload.Location = new Point(570, 321);
            btnReload.Name = "btnReload";
            btnReload.Size = new Size(135, 43);
            btnReload.TabIndex = 57;
            btnReload.Text = "Reload Supplier";
            btnReload.UseVisualStyleBackColor = false;
            btnReload.Click += btnReload_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label8.Location = new Point(751, 267);
            label8.Name = "label8";
            label8.Size = new Size(89, 23);
            label8.TabIndex = 59;
            label8.Text = "Category:";
            // 
            // cboCategory
            // 
            cboCategory.BackColor = SystemColors.HighlightText;
            cboCategory.FormattingEnabled = true;
            cboCategory.Location = new Point(877, 266);
            cboCategory.Name = "cboCategory";
            cboCategory.Size = new Size(280, 28);
            cboCategory.TabIndex = 58;
            // 
            // SupplierForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Chocolate;
            ClientSize = new Size(1229, 524);
            Controls.Add(label8);
            Controls.Add(cboCategory);
            Controls.Add(btnReload);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(btnReturnDashboard);
            Controls.Add(dgvSupplier);
            Controls.Add(btnDeleteSupplier);
            Controls.Add(btnEditSupplier);
            Controls.Add(btnAddSupplier);
            Controls.Add(txtContactNumber);
            Controls.Add(lblContactNumber);
            Controls.Add(txtAddress);
            Controls.Add(txtEmail);
            Controls.Add(txtSupplierName);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "SupplierForm";
            Text = "SupplierForm";
            Load += SupplierForm_Load_1;
            ((System.ComponentModel.ISupportInitialize)dgvSupplier).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtContactNumber;
        private Label lblContactNumber;
        private TextBox txtAddress;
        private TextBox txtEmail;
        private TextBox txtSupplierName;
        private Label label4;
        private Label label3;
        private Label label2;
        private Button btnAddSupplier;
        private Button btnEditSupplier;
        private Button btnDeleteSupplier;
        private DataGridView dgvSupplier;
        private Button btnReturnDashboard;
        private Label label5;
        private Label label6;
        private Label label7;
        private Button btnReload;
        private Label label8;
        private ComboBox cboCategory;
    }
}