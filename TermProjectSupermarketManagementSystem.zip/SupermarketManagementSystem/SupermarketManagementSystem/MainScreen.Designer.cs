﻿namespace SupermarketManagementSystem
{
    partial class MainScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainScreen));
            btnLogOut = new Button();
            btnViewCustomerOrder = new Button();
            btnSupplier = new Button();
            btnCustomers = new Button();
            btnProduct = new Button();
            btnAnalysis = new Button();
            label1 = new Label();
            lblGreeting = new Label();
            lblDate = new Label();
            btnMangeUserAccount = new Button();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            SuspendLayout();
            // 
            // btnLogOut
            // 
            btnLogOut.BackColor = Color.Red;
            btnLogOut.BackgroundImage = Properties.Resources.Log_Out;
            btnLogOut.BackgroundImageLayout = ImageLayout.Stretch;
            btnLogOut.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnLogOut.Location = new Point(1061, 430);
            btnLogOut.Name = "btnLogOut";
            btnLogOut.Size = new Size(337, 206);
            btnLogOut.TabIndex = 4;
            btnLogOut.UseVisualStyleBackColor = false;
            btnLogOut.Click += btnLogOut_Click;
            // 
            // btnViewCustomerOrder
            // 
            btnViewCustomerOrder.AllowDrop = true;
            btnViewCustomerOrder.BackColor = Color.DarkGoldenrod;
            btnViewCustomerOrder.BackgroundImage = Properties.Resources.View_Customer_Order;
            btnViewCustomerOrder.BackgroundImageLayout = ImageLayout.Stretch;
            btnViewCustomerOrder.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold);
            btnViewCustomerOrder.Location = new Point(1061, 187);
            btnViewCustomerOrder.Name = "btnViewCustomerOrder";
            btnViewCustomerOrder.Size = new Size(329, 206);
            btnViewCustomerOrder.TabIndex = 4;
            btnViewCustomerOrder.UseVisualStyleBackColor = false;
            btnViewCustomerOrder.Click += btnViewCustomerOrder_Click;
            // 
            // btnSupplier
            // 
            btnSupplier.BackColor = Color.Lime;
            btnSupplier.BackgroundImage = Properties.Resources.ManageSupplier;
            btnSupplier.BackgroundImageLayout = ImageLayout.Stretch;
            btnSupplier.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnSupplier.Location = new Point(740, 187);
            btnSupplier.Name = "btnSupplier";
            btnSupplier.Size = new Size(283, 208);
            btnSupplier.TabIndex = 4;
            btnSupplier.UseVisualStyleBackColor = false;
            btnSupplier.Click += btnSupplier_Click;
            // 
            // btnCustomers
            // 
            btnCustomers.BackColor = Color.Yellow;
            btnCustomers.BackgroundImage = Properties.Resources.Manage_Customer_;
            btnCustomers.BackgroundImageLayout = ImageLayout.Stretch;
            btnCustomers.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnCustomers.ForeColor = Color.Crimson;
            btnCustomers.Location = new Point(28, 187);
            btnCustomers.Name = "btnCustomers";
            btnCustomers.Size = new Size(307, 215);
            btnCustomers.TabIndex = 4;
            btnCustomers.Text = "Manage Customers";
            btnCustomers.TextAlign = ContentAlignment.BottomCenter;
            btnCustomers.UseVisualStyleBackColor = false;
            btnCustomers.Click += btnCustomers_Click;
            // 
            // btnProduct
            // 
            btnProduct.BackColor = Color.Fuchsia;
            btnProduct.BackgroundImage = Properties.Resources.Product_Inventory;
            btnProduct.BackgroundImageLayout = ImageLayout.Stretch;
            btnProduct.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnProduct.Location = new Point(395, 187);
            btnProduct.Name = "btnProduct";
            btnProduct.Size = new Size(283, 208);
            btnProduct.TabIndex = 4;
            btnProduct.UseVisualStyleBackColor = false;
            btnProduct.Click += btnProduct_Click;
            // 
            // btnAnalysis
            // 
            btnAnalysis.AutoSize = true;
            btnAnalysis.BackColor = Color.RosyBrown;
            btnAnalysis.BackgroundImage = Properties.Resources.DashBoard2;
            btnAnalysis.BackgroundImageLayout = ImageLayout.Stretch;
            btnAnalysis.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnAnalysis.ForeColor = Color.Crimson;
            btnAnalysis.Location = new Point(96, 430);
            btnAnalysis.Name = "btnAnalysis";
            btnAnalysis.Size = new Size(336, 215);
            btnAnalysis.TabIndex = 3;
            btnAnalysis.Text = "Analysis Product Customer";
            btnAnalysis.TextAlign = ContentAlignment.BottomCenter;
            btnAnalysis.UseVisualStyleBackColor = false;
            btnAnalysis.Click += btnAnalysis_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.ActiveCaption;
            label1.Font = new Font("Arial", 24F, FontStyle.Bold);
            label1.ForeColor = SystemColors.ControlLightLight;
            label1.Location = new Point(202, 9);
            label1.Name = "label1";
            label1.Size = new Size(1093, 46);
            label1.TabIndex = 7;
            label1.Text = "Welcome To Suppermarket Product Management System";
            label1.TextAlign = ContentAlignment.TopCenter;
            // 
            // lblGreeting
            // 
            lblGreeting.AutoSize = true;
            lblGreeting.Font = new Font("Bahnschrift SemiBold", 18F);
            lblGreeting.Location = new Point(28, 81);
            lblGreeting.Name = "lblGreeting";
            lblGreeting.Size = new Size(91, 36);
            lblGreeting.TabIndex = 8;
            lblGreeting.Text = "Hello,";
            // 
            // lblDate
            // 
            lblDate.AutoSize = true;
            lblDate.Font = new Font("Arial", 18F);
            lblDate.Location = new Point(28, 132);
            lblDate.Name = "lblDate";
            lblDate.Size = new Size(85, 35);
            lblDate.TabIndex = 9;
            lblDate.Text = "Date:";
            lblDate.TextAlign = ContentAlignment.TopCenter;
            // 
            // btnMangeUserAccount
            // 
            btnMangeUserAccount.AllowDrop = true;
            btnMangeUserAccount.BackColor = Color.DarkGreen;
            btnMangeUserAccount.BackgroundImage = (Image)resources.GetObject("btnMangeUserAccount.BackgroundImage");
            btnMangeUserAccount.BackgroundImageLayout = ImageLayout.Stretch;
            btnMangeUserAccount.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold);
            btnMangeUserAccount.Location = new Point(595, 430);
            btnMangeUserAccount.Name = "btnMangeUserAccount";
            btnMangeUserAccount.Size = new Size(320, 206);
            btnMangeUserAccount.TabIndex = 10;
            btnMangeUserAccount.UseVisualStyleBackColor = false;
            btnMangeUserAccount.Click += btnMangeUserAccount_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(1156, 396);
            label2.Name = "label2";
            label2.Size = new Size(167, 20);
            label2.TabIndex = 11;
            label2.Text = "View Customer Order";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(685, 639);
            label3.Name = "label3";
            label3.Size = new Size(167, 20);
            label3.TabIndex = 12;
            label3.Text = "Manage User Account";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(1202, 639);
            label4.Name = "label4";
            label4.Size = new Size(67, 20);
            label4.TabIndex = 13;
            label4.Text = "Log Out";
            // 
            // MainScreen
            // 
            AutoScaleDimensions = new SizeF(9F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoScroll = true;
            AutoScrollMargin = new Size(0, 60);
            AutoScrollMinSize = new Size(0, 60);
            AutoSize = true;
            BackColor = Color.DarkCyan;
            ClientSize = new Size(1475, 735);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(btnMangeUserAccount);
            Controls.Add(lblDate);
            Controls.Add(lblGreeting);
            Controls.Add(label1);
            Controls.Add(btnAnalysis);
            Controls.Add(btnProduct);
            Controls.Add(btnCustomers);
            Controls.Add(btnLogOut);
            Controls.Add(btnSupplier);
            Controls.Add(btnViewCustomerOrder);
            Font = new Font("Segoe UI Black", 9F, FontStyle.Bold);
            ForeColor = Color.Cornsilk;
            Name = "MainScreen";
            Text = "MainScreen";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button btnLogOut;
        private Button btnViewCustomerOrder;
        private Button btnSupplier;
        private Button btnCustomers;
        private Button btnProduct;
        private Button btnAnalysis;
        private Label label1;
        private Label lblGreeting;
        private Label lblDate;
        private Button btnMangeUserAccount;
        private Label label2;
        private Label label3;
        private Label label4;
    }
}