﻿namespace SupermarketManagementSystem
{
    partial class CustomerProductAnalysisForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title1 = new System.Windows.Forms.DataVisualization.Charting.Title();
            label1 = new Label();
            btnReturnMain = new Button();
            chartCustomerAnalysis = new System.Windows.Forms.DataVisualization.Charting.Chart();
            ((System.ComponentModel.ISupportInitialize)chartCustomerAnalysis).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 13F);
            label1.Location = new Point(444, 9);
            label1.Name = "label1";
            label1.Size = new Size(279, 30);
            label1.TabIndex = 1;
            label1.Text = "Analysis Customer Product";
            // 
            // btnReturnMain
            // 
            btnReturnMain.BackColor = Color.LightCoral;
            btnReturnMain.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnReturnMain.Location = new Point(782, 262);
            btnReturnMain.Name = "btnReturnMain";
            btnReturnMain.Size = new Size(200, 59);
            btnReturnMain.TabIndex = 51;
            btnReturnMain.Text = "Return to Main";
            btnReturnMain.UseVisualStyleBackColor = false;
            btnReturnMain.Click += btnReturnMain_Click;
            // 
            // chartCustomerAnalysis
            // 
            chartArea1.Name = "ChartArea1";
            chartCustomerAnalysis.ChartAreas.Add(chartArea1);
            chartCustomerAnalysis.Location = new Point(62, 67);
            chartCustomerAnalysis.Name = "chartCustomerAnalysis";
            chartCustomerAnalysis.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.EarthTones;
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.StackedColumn;
            series1.IsXValueIndexed = true;
            series1.Name = "CustomerName";
            series1.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Double;
            series1.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Double;
            chartCustomerAnalysis.Series.Add(series1);
            chartCustomerAnalysis.Size = new Size(701, 454);
            chartCustomerAnalysis.TabIndex = 52;
            chartCustomerAnalysis.Text = "chart1";
            title1.Name = "Custmer Chart Analysis";
            chartCustomerAnalysis.Titles.Add(title1);
            chartCustomerAnalysis.Click += chartCustomerAnalysis_Click;
            // 
            // CustomerProductAnalysisForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkCyan;
            ClientSize = new Size(1095, 554);
            Controls.Add(chartCustomerAnalysis);
            Controls.Add(btnReturnMain);
            Controls.Add(label1);
            Name = "CustomerProductAnalysisForm";
            Text = "CustomerProductAnalysisForm";
            ((System.ComponentModel.ISupportInitialize)chartCustomerAnalysis).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label1;
        private Button btnReturnMain;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartCustomerAnalysis;
    }
}