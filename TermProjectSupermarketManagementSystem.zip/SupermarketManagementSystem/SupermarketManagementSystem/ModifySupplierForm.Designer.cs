﻿namespace SupermarketManagementSystem
{
    partial class ModifySupplierForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label3 = new Label();
            btnReturnSupplier = new Button();
            btnSaveChange = new Button();
            label1 = new Label();
            dgvSupplier = new DataGridView();
            txtContactNumber = new TextBox();
            lblContactNumber = new Label();
            txtAddress = new TextBox();
            txtEmail = new TextBox();
            txtSupplierName = new TextBox();
            label4 = new Label();
            label2 = new Label();
            label5 = new Label();
            label6 = new Label();
            cboCategory = new ComboBox();
            ((System.ComponentModel.ISupportInitialize)dgvSupplier).BeginInit();
            SuspendLayout();
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.DarkBlue;
            label3.Font = new Font("Segoe UI Black", 11F, FontStyle.Bold);
            label3.ForeColor = Color.White;
            label3.Location = new Point(1034, 14);
            label3.Name = "label3";
            label3.Size = new Size(163, 25);
            label3.TabIndex = 67;
            label3.Text = "Modify Supplier";
            // 
            // btnReturnSupplier
            // 
            btnReturnSupplier.BackColor = Color.Red;
            btnReturnSupplier.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnReturnSupplier.ForeColor = SystemColors.ButtonHighlight;
            btnReturnSupplier.Location = new Point(1170, 309);
            btnReturnSupplier.Name = "btnReturnSupplier";
            btnReturnSupplier.Size = new Size(169, 43);
            btnReturnSupplier.TabIndex = 66;
            btnReturnSupplier.Text = "Return Supplier Form";
            btnReturnSupplier.UseVisualStyleBackColor = false;
            btnReturnSupplier.Click += btnReturnSupplier_Click;
            // 
            // btnSaveChange
            // 
            btnSaveChange.BackColor = Color.Lime;
            btnSaveChange.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnSaveChange.Location = new Point(935, 309);
            btnSaveChange.Name = "btnSaveChange";
            btnSaveChange.Size = new Size(209, 43);
            btnSaveChange.TabIndex = 65;
            btnSaveChange.Text = "Save Supplier Changes";
            btnSaveChange.UseVisualStyleBackColor = false;
            btnSaveChange.Click += btnSaveChange_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.SeaShell;
            label1.Font = new Font("Segoe UI Black", 13F, FontStyle.Bold);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(527, 9);
            label1.Name = "label1";
            label1.Size = new Size(327, 30);
            label1.TabIndex = 52;
            label1.Text = "Modify Supplier Information";
            // 
            // dgvSupplier
            // 
            dgvSupplier.CellBorderStyle = DataGridViewCellBorderStyle.Raised;
            dgvSupplier.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvSupplier.Location = new Point(12, 63);
            dgvSupplier.Name = "dgvSupplier";
            dgvSupplier.ReadOnly = true;
            dgvSupplier.RowHeadersWidth = 51;
            dgvSupplier.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvSupplier.Size = new Size(809, 289);
            dgvSupplier.TabIndex = 51;
            dgvSupplier.SelectionChanged += dgvSupplier_SelectionChanged;
            // 
            // txtContactNumber
            // 
            txtContactNumber.BackColor = SystemColors.InactiveBorder;
            txtContactNumber.Location = new Point(995, 103);
            txtContactNumber.Name = "txtContactNumber";
            txtContactNumber.Size = new Size(280, 27);
            txtContactNumber.TabIndex = 75;
            // 
            // lblContactNumber
            // 
            lblContactNumber.AutoSize = true;
            lblContactNumber.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblContactNumber.Location = new Point(827, 104);
            lblContactNumber.Name = "lblContactNumber";
            lblContactNumber.Size = new Size(149, 23);
            lblContactNumber.TabIndex = 74;
            lblContactNumber.Text = "Contact Number:";
            // 
            // txtAddress
            // 
            txtAddress.BackColor = SystemColors.InactiveBorder;
            txtAddress.Location = new Point(995, 192);
            txtAddress.Name = "txtAddress";
            txtAddress.Size = new Size(280, 27);
            txtAddress.TabIndex = 73;
            // 
            // txtEmail
            // 
            txtEmail.BackColor = SystemColors.InactiveBorder;
            txtEmail.Location = new Point(995, 149);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(280, 27);
            txtEmail.TabIndex = 72;
            // 
            // txtSupplierName
            // 
            txtSupplierName.BackColor = SystemColors.InactiveBorder;
            txtSupplierName.BorderStyle = BorderStyle.FixedSingle;
            txtSupplierName.Location = new Point(995, 55);
            txtSupplierName.Name = "txtSupplierName";
            txtSupplierName.Size = new Size(280, 27);
            txtSupplierName.TabIndex = 71;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label4.Location = new Point(879, 192);
            label4.Name = "label4";
            label4.Size = new Size(79, 23);
            label4.TabIndex = 70;
            label4.Text = "Address:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label2.Location = new Point(909, 149);
            label2.Name = "label2";
            label2.Size = new Size(64, 23);
            label2.TabIndex = 69;
            label2.Text = "Email: ";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label5.Location = new Point(841, 55);
            label5.Name = "label5";
            label5.Size = new Size(135, 23);
            label5.TabIndex = 68;
            label5.Text = "Supplier Name:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label6.Location = new Point(874, 242);
            label6.Name = "label6";
            label6.Size = new Size(89, 23);
            label6.TabIndex = 92;
            label6.Text = "Category:";
            // 
            // cboCategory
            // 
            cboCategory.BackColor = SystemColors.HighlightText;
            cboCategory.FormattingEnabled = true;
            cboCategory.Location = new Point(995, 237);
            cboCategory.Name = "cboCategory";
            cboCategory.Size = new Size(280, 28);
            cboCategory.TabIndex = 91;
            // 
            // ModifySupplierForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.CadetBlue;
            ClientSize = new Size(1382, 411);
            Controls.Add(label6);
            Controls.Add(cboCategory);
            Controls.Add(txtContactNumber);
            Controls.Add(lblContactNumber);
            Controls.Add(txtAddress);
            Controls.Add(txtEmail);
            Controls.Add(txtSupplierName);
            Controls.Add(label4);
            Controls.Add(label2);
            Controls.Add(label5);
            Controls.Add(label3);
            Controls.Add(btnReturnSupplier);
            Controls.Add(btnSaveChange);
            Controls.Add(label1);
            Controls.Add(dgvSupplier);
            Name = "ModifySupplierForm";
            Text = "DeleteSupplierForm";
            Load += DeleteSupplierForm_Load;
            ((System.ComponentModel.ISupportInitialize)dgvSupplier).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label3;
        private Button btnReturnSupplier;
        private Button btnSaveChange;
        private Label label1;
        private DataGridView dgvSupplier;
        private TextBox txtContactNumber;
        private Label lblContactNumber;
        private TextBox txtAddress;
        private TextBox txtEmail;
        private TextBox txtSupplierName;
        private Label label4;
        private Label label2;
        private Label label5;
        private Label label6;
        private ComboBox cboCategory;
    }
}