﻿namespace SupermarketManagementSystem
{
    partial class DeleteForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            label3 = new Label();
            btnReturn = new Button();
            btnDelete = new Button();
            txtImageURL = new TextBox();
            txtStockLevel2 = new TextBox();
            txtPrice2 = new TextBox();
            txtDescription2 = new TextBox();
            txtName = new TextBox();
            label14 = new Label();
            label13 = new Label();
            label12 = new Label();
            label11 = new Label();
            label10 = new Label();
            lblProductImage = new Label();
            pictureBoxImage = new PictureBox();
            cboCategory = new ComboBox();
            label2 = new Label();
            label1 = new Label();
            dgvProductInventory = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxImage).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvProductInventory).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Delete;
            pictureBox1.Location = new Point(1012, 338);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(337, 328);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.DarkBlue;
            label3.Font = new Font("Segoe UI Black", 11F, FontStyle.Bold);
            label3.ForeColor = Color.White;
            label3.Location = new Point(956, 34);
            label3.Name = "label3";
            label3.Size = new Size(270, 25);
            label3.TabIndex = 69;
            label3.Text = "Delete Product Information";
            // 
            // btnReturn
            // 
            btnReturn.BackColor = Color.Red;
            btnReturn.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnReturn.ForeColor = SystemColors.ButtonHighlight;
            btnReturn.Location = new Point(1081, 289);
            btnReturn.Name = "btnReturn";
            btnReturn.Size = new Size(169, 43);
            btnReturn.TabIndex = 68;
            btnReturn.Text = "Return Product Form";
            btnReturn.UseVisualStyleBackColor = false;
            btnReturn.Click += btnReturn_Click;
            // 
            // btnDelete
            // 
            btnDelete.BackColor = Color.Lime;
            btnDelete.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnDelete.Location = new Point(880, 289);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(161, 43);
            btnDelete.TabIndex = 67;
            btnDelete.Text = "Delete Product";
            btnDelete.UseVisualStyleBackColor = false;
            btnDelete.Click += btnDelete_Click;
            // 
            // txtImageURL
            // 
            txtImageURL.BackColor = SystemColors.ControlLightLight;
            txtImageURL.Location = new Point(946, 227);
            txtImageURL.Name = "txtImageURL";
            txtImageURL.ReadOnly = true;
            txtImageURL.Size = new Size(291, 27);
            txtImageURL.TabIndex = 66;
            // 
            // txtStockLevel2
            // 
            txtStockLevel2.BackColor = SystemColors.ControlLightLight;
            txtStockLevel2.Location = new Point(946, 187);
            txtStockLevel2.Name = "txtStockLevel2";
            txtStockLevel2.ReadOnly = true;
            txtStockLevel2.Size = new Size(291, 27);
            txtStockLevel2.TabIndex = 65;
            // 
            // txtPrice2
            // 
            txtPrice2.BackColor = SystemColors.ControlLightLight;
            txtPrice2.Location = new Point(946, 152);
            txtPrice2.Name = "txtPrice2";
            txtPrice2.ReadOnly = true;
            txtPrice2.Size = new Size(291, 27);
            txtPrice2.TabIndex = 64;
            // 
            // txtDescription2
            // 
            txtDescription2.BackColor = SystemColors.ControlLightLight;
            txtDescription2.Location = new Point(946, 117);
            txtDescription2.Name = "txtDescription2";
            txtDescription2.ReadOnly = true;
            txtDescription2.Size = new Size(291, 27);
            txtDescription2.TabIndex = 63;
            // 
            // txtName
            // 
            txtName.BackColor = SystemColors.ControlLightLight;
            txtName.Location = new Point(946, 84);
            txtName.Name = "txtName";
            txtName.ReadOnly = true;
            txtName.Size = new Size(291, 27);
            txtName.TabIndex = 62;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold);
            label14.Location = new Point(836, 234);
            label14.Name = "label14";
            label14.Size = new Size(102, 20);
            label14.TabIndex = 61;
            label14.Text = "ImageURL:";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold);
            label13.Location = new Point(828, 194);
            label13.Name = "label13";
            label13.Size = new Size(113, 20);
            label13.TabIndex = 60;
            label13.Text = "Stock Level:";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold);
            label12.Location = new Point(836, 159);
            label12.Name = "label12";
            label12.Size = new Size(59, 20);
            label12.TabIndex = 59;
            label12.Text = "Price:";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold);
            label11.Location = new Point(828, 122);
            label11.Name = "label11";
            label11.Size = new Size(112, 20);
            label11.TabIndex = 58;
            label11.Text = "Description:";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold);
            label10.Location = new Point(828, 87);
            label10.Name = "label10";
            label10.Size = new Size(63, 20);
            label10.TabIndex = 57;
            label10.Text = "Name:";
            // 
            // lblProductImage
            // 
            lblProductImage.AutoSize = true;
            lblProductImage.BackColor = Color.Cyan;
            lblProductImage.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblProductImage.Location = new Point(117, 338);
            lblProductImage.Name = "lblProductImage";
            lblProductImage.Size = new Size(128, 23);
            lblProductImage.TabIndex = 56;
            lblProductImage.Text = "Product Image";
            // 
            // pictureBoxImage
            // 
            pictureBoxImage.Location = new Point(12, 364);
            pictureBoxImage.Name = "pictureBoxImage";
            pictureBoxImage.Size = new Size(377, 286);
            pictureBoxImage.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBoxImage.TabIndex = 55;
            pictureBoxImage.TabStop = false;
            // 
            // cboCategory
            // 
            cboCategory.BackColor = SystemColors.ControlLightLight;
            cboCategory.DropDownWidth = 260;
            cboCategory.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            cboCategory.FormattingEnabled = true;
            cboCategory.Location = new Point(318, 28);
            cboCategory.Name = "cboCategory";
            cboCategory.Size = new Size(250, 31);
            cboCategory.TabIndex = 54;
            cboCategory.SelectedIndexChanged += cboCategory_SelectedIndexChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Cyan;
            label2.Font = new Font("Segoe UI Black", 11F, FontStyle.Bold);
            label2.ForeColor = Color.Black;
            label2.Location = new Point(12, 31);
            label2.Name = "label2";
            label2.Size = new Size(300, 25);
            label2.TabIndex = 53;
            label2.Text = "Searching Product by Category";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.SeaShell;
            label1.Font = new Font("Segoe UI Black", 13F, FontStyle.Bold);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(574, -6);
            label1.Name = "label1";
            label1.Size = new Size(311, 30);
            label1.TabIndex = 52;
            label1.Text = "Delete Product by Category";
            // 
            // dgvProductInventory
            // 
            dgvProductInventory.CellBorderStyle = DataGridViewCellBorderStyle.Raised;
            dgvProductInventory.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvProductInventory.Location = new Point(12, 71);
            dgvProductInventory.Name = "dgvProductInventory";
            dgvProductInventory.ReadOnly = true;
            dgvProductInventory.RowHeadersWidth = 51;
            dgvProductInventory.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvProductInventory.Size = new Size(789, 261);
            dgvProductInventory.TabIndex = 51;
            dgvProductInventory.SelectionChanged += dgvProductInventory_SelectionChanged;
            // 
            // DeleteForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientActiveCaption;
            ClientSize = new Size(1361, 656);
            Controls.Add(label3);
            Controls.Add(btnReturn);
            Controls.Add(btnDelete);
            Controls.Add(txtImageURL);
            Controls.Add(txtStockLevel2);
            Controls.Add(txtPrice2);
            Controls.Add(txtDescription2);
            Controls.Add(txtName);
            Controls.Add(label14);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(lblProductImage);
            Controls.Add(pictureBoxImage);
            Controls.Add(cboCategory);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(dgvProductInventory);
            Controls.Add(pictureBox1);
            Name = "DeleteForm";
            Text = "DeleteForm";
            //Load += DeleteForm_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxImage).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvProductInventory).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Label label3;
        private Button btnReturn;
        private Button btnDelete;
        private TextBox txtImageURL;
        private TextBox txtStockLevel2;
        private TextBox txtPrice2;
        private TextBox txtDescription2;
        private TextBox txtName;
        private Label label14;
        private Label label13;
        private Label label12;
        private Label label11;
        private Label label10;
        private Label lblProductImage;
        private PictureBox pictureBoxImage;
        private ComboBox cboCategory;
        private Label label2;
        private Label label1;
        private DataGridView dgvProductInventory;
    }
}