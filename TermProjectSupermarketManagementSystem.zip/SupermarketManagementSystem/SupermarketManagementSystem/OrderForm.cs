﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SupermarketManagementSystem
{
    public partial class OrderForm : Form
    {

        private int customerID;
        private string customerName;


        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=SupermarketProductManagementSystem.accdb";

        public OrderForm(int customerID, string customerName)
        {
            InitializeComponent();
            SetCartDataGrid();
            this.customerID = customerID;
            this.customerName = customerName;
            DisplayCustomer();
            LoadProductIntoGridView();

        }

        private void DisplayCustomer()
        {
            lblCustomerInfor.Text = $"Order for: {customerName} (ID: {customerID})";
        }

        private void OrderForm_Load(object sender, EventArgs e)
        {

            LoadProductIntoGridView();

        }

        // I would like to just load the product table into datagridview.
        private void LoadProductIntoGridView()
        {
            string query = "SELECT * FROM Products";


            try
            {
                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    conn.Open();
                    using (OleDbDataAdapter adap = new OleDbDataAdapter(query, conn))
                    {
                        DataTable dt = new DataTable();
                        adap.Fill(dt);
                        dgvProductIventory.DataSource = dt;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while loading the Product: " + ex.Message);
            }
        }


        // This method let the user view the product information once they seleced on the 
        // Data gridview to view the Product Name, Price and Quantity.
        private void LoadProductDetail(int rowIndex)
        {
            if (rowIndex >= 0 && dgvProductIventory.Rows.Count > rowIndex)
            {
                DataGridViewRow selectedRow = dgvProductIventory.Rows[rowIndex];

                // Populate the text boxes with product details
                txtName.Text = selectedRow.Cells["ProductName"].Value.ToString();
                txtPrice.Text = selectedRow.Cells["price"].Value.ToString();
                int stockLevel = Convert.ToInt32(selectedRow.Cells["StockLevel"].Value);
                numQuantity.Value = 1;
                numQuantity.Maximum = stockLevel;
                // Load the image
                string imageURL = selectedRow.Cells["ProductImageURL"].Value?.ToString();

                if (!string.IsNullOrWhiteSpace(imageURL))
                {
                    try
                    {
                        pictureBoxProductImage.Load(imageURL); // Try to load the image from the URL or file path
                    }
                    catch
                    {
                        // Fallback to a "Not Found" image if loading fails
                        pictureBoxProductImage.Image = Image.FromFile(@"Images\ImageNotFound.jpg");
                    }
                }
                else
                {
                    // Show the "Not Found" image if the URL is empty or null
                    pictureBoxProductImage.Image = Image.FromFile(@"Images\ImageNotFound.jpg");
                }
            }

        }
        private void dgvProductIventory_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                LoadProductDetail(e.RowIndex);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error to Loading product detail: " + ex.Message);

            }
        }

        // I'm going to add some of the column to show to add the cart on the right side. 
        private void SetCartDataGrid()
        {
            dgvCart.Columns.Clear();

            // we will add some of the column 
            // to prepare for check out. 
            dgvCart.Columns.Add("CustomerName", "CustomerName");
            dgvCart.Columns.Add("ProductID", "ProductID");
            dgvCart.Columns.Add("ProductName", "ProductName");
            dgvCart.Columns.Add("UnitPrice", "Unit Price");
            dgvCart.Columns.Add("Quantity", "Quantity");
            dgvCart.Columns.Add("TotalPrice", "Total Price");

            dgvCart.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

        }

        // This would be update the stock level after using the button Add Cart.

        private void UpdateProductStocklLevelDatabase()
        {
            string query = "SELECT * FROM Products";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                conn.Open();
                using (OleDbDataAdapter adap = new OleDbDataAdapter(query, conn))
                {

                    DataTable dt = new DataTable();
                    adap.Fill(dt);
                    dgvProductIventory.DataSource = dt;

                }
            }
        }

        private void btnAddToCart_Click(object sender, EventArgs e)
        {
            if (dgvProductIventory.Rows.Count > 0)
            {
                // Select the row to view and prepare to add to the cart
                DataGridViewRow selectedRow = dgvProductIventory.SelectedRows[0];
                int productID = Convert.ToInt32(selectedRow.Cells["ProductID"].Value);
                string productName = selectedRow.Cells["ProductName"].Value.ToString();
                decimal unitPrice = Convert.ToDecimal(selectedRow.Cells["Price"].Value);
                int stockLevel = Convert.ToInt32(selectedRow.Cells["StockLevel"].Value);
                int newQuantity = (int)numQuantity.Value;

                // Check stock level
                if (newQuantity > stockLevel)
                {
                    MessageBox.Show("Quantity cannot exceed stock level.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Check if the product already exists in the cart
                foreach (DataGridViewRow row in dgvCart.Rows)
                {
                    if (Convert.ToInt32(row.Cells["ProductID"].Value) == productID)
                    {
                        // Adjust the quantity to match the user's input
                        int previousQuantity = Convert.ToInt32(row.Cells["Quantity"].Value);
                        int stockAdjustment = newQuantity - previousQuantity;

                        if (newQuantity > stockLevel)
                        {
                            MessageBox.Show("Adjusted quantity cannot exceed stock level.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }

                        row.Cells["Quantity"].Value = newQuantity;
                        row.Cells["TotalPrice"].Value = unitPrice * newQuantity;

                        // Update stock level in inventory
                        selectedRow.Cells["StockLevel"].Value = stockLevel - stockAdjustment;

                        // Update stock level in the database
                        Order order = new Order();
                        order.UpdateStockLevelInDatabase(productID, stockLevel - stockAdjustment);

                        return;
                    }
                }

                // If product does not exist in the cart, add it
                decimal totalPrice = unitPrice * newQuantity;
                dgvCart.Rows.Add(customerName, productID, productName, unitPrice, newQuantity, totalPrice);

                // Update stock level in inventory
                selectedRow.Cells["StockLevel"].Value = stockLevel - newQuantity;
            }
            else
            {
                MessageBox.Show("Please select a product to add to the cart.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }
        private void btnReloadProduct_Click(object sender, EventArgs e)
        {

            UpdateProductStocklLevelDatabase();

        }

        private void btnRemoveCart_Click(object sender, EventArgs e)
        {
            Order order = new Order();
            if (dgvCart.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dgvCart.SelectedRows[0];
                int productID = Convert.ToInt32(selectedRow.Cells["ProductID"].Value);
                int quantity = Convert.ToInt32(selectedRow.Cells["Quantity"].Value);
                decimal unitPrice = Convert.ToDecimal(selectedRow.Cells["UnitPrice"].Value);

                // Find the corresponding product in the inventory
                foreach (DataGridViewRow inventoryRow in dgvProductIventory.Rows)
                {
                    // I will check the inventoryRow in the row and if they match the productID
                    // Would be process the to Remove from the Cart and update it in the
                    // Data Grid View Product Inventory
                    if (Convert.ToInt32(inventoryRow.Cells["ProductID"].Value) == productID)
                    {
                        // Update stock level
                        int stockLevel = Convert.ToInt32(inventoryRow.Cells["StockLevel"].Value);
                        inventoryRow.Cells["StockLevel"].Value = stockLevel + quantity;

                        // Update stock level in the database
                        order.UpdateStockLevelInDatabase(productID, stockLevel + quantity);
                        UpdateProductStocklLevelDatabase();
                        break;

                    }
                }
                // Remove the selected row from the cart
                dgvCart.Rows.Remove(selectedRow);
            }
            else
            {
                MessageBox.Show("Please select a product to remove from the cart.");
            }
        }
        private void btnAddOrder_Click(object sender, EventArgs e)
        {
            // We will check if the  datagridview Car is empty. 
            if (dgvCart.Rows.Count == 0)
            {
                MessageBox.Show("Cart is empty. Can you add the product into the cart");
                return;
            }

            try
            {

                // Ensure a row is selected
                if (dgvCart.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Please select a row to place an order.");
                    return;
                }


                DataGridViewRow row = dgvCart.Rows[0];
                // Retrieve data from the cart
                int productID = Convert.ToInt32(row.Cells["ProductID"].Value);
                string productName = row.Cells["ProductName"].Value.ToString();
                int quantity = Convert.ToInt32(row.Cells["Quantity"].Value);
                decimal totalPrice = Convert.ToDecimal(row.Cells["TotalPrice"].Value);

                Order order = new Order
                {
                    CustomerID = customerID,
                    CustomerName = customerName,
                    ProductID = productID,
                    ProductName = productName,
                    Quantity = quantity,
                    TotalPrice = totalPrice,
                    OrderDate = DateTime.Now,

                };

                order.SaveToDatabase();

                MessageBox.Show("Order Placed Successfully!", "Success");

                // I'm going to clear the Row after we save to order already.
                dgvCart.Rows.Remove(row);

            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occured while placing  the order: " + ex.Message);
            }
        }

        private void btnReturnCustomer_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgvProductIventory_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
