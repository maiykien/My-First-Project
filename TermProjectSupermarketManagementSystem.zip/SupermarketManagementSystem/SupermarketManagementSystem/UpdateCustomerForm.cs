﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SupermarketManagementSystem
{
    public partial class UpdateCustomerForm : Form
    {

        private Customer customer; // I will create the instance of the Customer Object
        private int customerID; //Stores the ID of the customer to be updated. 
        public UpdateCustomerForm(Customer customer, int customerID) // Constructor for initializing.
        {
            InitializeComponent(); // Initialize component on the form. 
            LoadAllStates(); // Populate the states dropdown. 
            this.customer = customer; //  Assign the passed customer to the local variable.
            LoadCustomerForm(customer); // Loads the customer details into the form fields. 
            this.customerID = customerID; // Stores the customer ID Locally. 
        }

        public void LoadCustomerForm(Customer customer)
        {
            customerID = customer.customerID;//  Assign the customer ID to the Local variabls
            txtCustomerName.Text = customer.customerName;// Set the text box for customer name
            txtPhoneNumber.Text = customer.customerPhone; // text box for customer Phone
            txtEmail.Text = customer.customerEmail; //Text box for customer email
            txtAddress.Text = customer.customerAddress; // text box for customer Address
            txtCity.Text = customer.customerCity; // text box for customer City.
            cboState.SelectedItem = customer.customerState; // combo box for customerState.
            txtZipCode.Text = customer.customerZipCode; //Text box for Zipcode. 

        }

        private void LoadAllStates()
        {
            string[] states = { "Select A state",
        "Alabama",
        "Alaska",
        "Arizona",
        "Arkansas",
        "California",
        "Colorado",
        "Connecticut",
        "Delaware",
        "Florida",
        "Georgia",
        "Hawaii",
        "Idaho",
        "Illinois",
        "Indiana",
        "Iowa",
        "Kansas",
        "Kentucky",
        "Louisiana",
        "Maine",
        "Maryland",
        "Massachusetts",
        "Michigan",
        "Minnesota",
        "Mississippi",
        "Missouri",
        "Montana",
        "Nebraska",
        "Nevada",
        "New Hampshire",
        "New Jersey",
        "New Mexico",
        "New York",
        "North Carolina",
        "North Dakota",
        "Ohio",
        "Oklahoma",
        "Oregon",
        "Pennsylvania",
        "Rhode Island",
        "South Carolina",
        "South Dakota",
        "Tennessee",
        "Texas",
        "Utah",
        "Vermont",
        "Virginia",
        "Washington",
        "West Virginia",
        "Wisconsin",
        "Wyoming"
    };

            foreach (string state in states)
            {
                cboState.Items.Add(state);
            }
            cboState.SelectedIndex = 0;
        }

        private void UpdateCustomerForm_Load(object sender, EventArgs e)
        {
        }

        private void btnSaveChangeCustomer_Click(object sender, EventArgs e)
        {

            Customer updatedCustomer = new Customer
            {
                customerID = customerID,  // Preserves the existing customer. 
                customerName = txtCustomerName.Text, // Get update customer name
                customerPhone = txtPhoneNumber.Text, // update the phone number
                customerEmail = txtEmail.Text, // update the email text.
                customerAddress = txtAddress.Text, // update the Address
                customerCity = txtCity.Text, // update the customer city
                customerState = cboState.Text, // Update the customer state.
                customerZipCode = txtZipCode.Text // Update the customer Zipcode. 
            };


            customer.UpdateCustomerInDatabase(updatedCustomer); // Call the method update the customer in the database. 


        }

        private void btnReturnCustomer_Click(object sender, EventArgs e)
        {

            this.Close();  // Closes the current form and returns to the previous form.

        }
    }
}
