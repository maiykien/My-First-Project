﻿namespace SupermarketManagementSystem
{
    partial class DeleteSupplierForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtContactNumber = new TextBox();
            lblContactNumber = new Label();
            txtAddress = new TextBox();
            txtEmail = new TextBox();
            txtSupplierName = new TextBox();
            label4 = new Label();
            label2 = new Label();
            label5 = new Label();
            label3 = new Label();
            btnReturnSupplier = new Button();
            btnDelete = new Button();
            label1 = new Label();
            dgvSupplier = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dgvSupplier).BeginInit();
            SuspendLayout();
            // 
            // txtContactNumber
            // 
            txtContactNumber.BackColor = SystemColors.InactiveBorder;
            txtContactNumber.Location = new Point(1017, 151);
            txtContactNumber.Name = "txtContactNumber";
            txtContactNumber.ReadOnly = true;
            txtContactNumber.Size = new Size(280, 27);
            txtContactNumber.TabIndex = 88;
            // 
            // lblContactNumber
            // 
            lblContactNumber.AutoSize = true;
            lblContactNumber.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblContactNumber.Location = new Point(849, 152);
            lblContactNumber.Name = "lblContactNumber";
            lblContactNumber.Size = new Size(149, 23);
            lblContactNumber.TabIndex = 87;
            lblContactNumber.Text = "Contact Number:";
            // 
            // txtAddress
            // 
            txtAddress.BackColor = SystemColors.InactiveBorder;
            txtAddress.Location = new Point(1017, 240);
            txtAddress.Name = "txtAddress";
            txtAddress.ReadOnly = true;
            txtAddress.Size = new Size(280, 27);
            txtAddress.TabIndex = 86;
            // 
            // txtEmail
            // 
            txtEmail.BackColor = SystemColors.InactiveBorder;
            txtEmail.Location = new Point(1017, 197);
            txtEmail.Name = "txtEmail";
            txtEmail.ReadOnly = true;
            txtEmail.Size = new Size(280, 27);
            txtEmail.TabIndex = 85;
            // 
            // txtSupplierName
            // 
            txtSupplierName.BackColor = SystemColors.InactiveBorder;
            txtSupplierName.BorderStyle = BorderStyle.FixedSingle;
            txtSupplierName.Location = new Point(1017, 103);
            txtSupplierName.Name = "txtSupplierName";
            txtSupplierName.ReadOnly = true;
            txtSupplierName.Size = new Size(280, 27);
            txtSupplierName.TabIndex = 84;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label4.Location = new Point(901, 240);
            label4.Name = "label4";
            label4.Size = new Size(79, 23);
            label4.TabIndex = 83;
            label4.Text = "Address:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label2.Location = new Point(931, 197);
            label2.Name = "label2";
            label2.Size = new Size(64, 23);
            label2.TabIndex = 82;
            label2.Text = "Email: ";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label5.Location = new Point(863, 103);
            label5.Name = "label5";
            label5.Size = new Size(135, 23);
            label5.TabIndex = 81;
            label5.Text = "Supplier Name:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.DarkBlue;
            label3.Font = new Font("Segoe UI Black", 11F, FontStyle.Bold);
            label3.ForeColor = Color.White;
            label3.Location = new Point(1058, 62);
            label3.Name = "label3";
            label3.Size = new Size(156, 25);
            label3.TabIndex = 80;
            label3.Text = "Delete Supplier";
            // 
            // btnReturnSupplier
            // 
            btnReturnSupplier.BackColor = Color.Red;
            btnReturnSupplier.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnReturnSupplier.ForeColor = SystemColors.ButtonHighlight;
            btnReturnSupplier.Location = new Point(1170, 329);
            btnReturnSupplier.Name = "btnReturnSupplier";
            btnReturnSupplier.Size = new Size(169, 43);
            btnReturnSupplier.TabIndex = 79;
            btnReturnSupplier.Text = "Return Supplier Form";
            btnReturnSupplier.UseVisualStyleBackColor = false;
            btnReturnSupplier.Click += btnReturnSupplier_Click;
            // 
            // btnDelete
            // 
            btnDelete.BackColor = Color.Lime;
            btnDelete.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnDelete.Location = new Point(915, 329);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(209, 43);
            btnDelete.TabIndex = 78;
            btnDelete.Text = "Delete Supplier ";
            btnDelete.UseVisualStyleBackColor = false;
            btnDelete.Click += btnDelete_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Snow;
            label1.Font = new Font("Segoe UI Black", 13F, FontStyle.Bold);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(540, 29);
            label1.Name = "label1";
            label1.Size = new Size(317, 30);
            label1.TabIndex = 77;
            label1.Text = "Delete Supplier Information";
            // 
            // dgvSupplier
            // 
            dgvSupplier.CellBorderStyle = DataGridViewCellBorderStyle.Raised;
            dgvSupplier.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvSupplier.Location = new Point(25, 83);
            dgvSupplier.Name = "dgvSupplier";
            dgvSupplier.ReadOnly = true;
            dgvSupplier.RowHeadersWidth = 51;
            dgvSupplier.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvSupplier.Size = new Size(809, 289);
            dgvSupplier.TabIndex = 76;
            dgvSupplier.SelectionChanged += dgvSupplier_SelectionChanged;
            // 
            // DeleteSupplierForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.CadetBlue;
            ClientSize = new Size(1351, 550);
            Controls.Add(txtContactNumber);
            Controls.Add(lblContactNumber);
            Controls.Add(txtAddress);
            Controls.Add(txtEmail);
            Controls.Add(txtSupplierName);
            Controls.Add(label4);
            Controls.Add(label2);
            Controls.Add(label5);
            Controls.Add(label3);
            Controls.Add(btnReturnSupplier);
            Controls.Add(btnDelete);
            Controls.Add(label1);
            Controls.Add(dgvSupplier);
            Name = "DeleteSupplierForm";
            Text = "x";
            Load += DeleteSupplierForm_Load;
            ((System.ComponentModel.ISupportInitialize)dgvSupplier).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtContactNumber;
        private Label lblContactNumber;
        private TextBox txtAddress;
        private TextBox txtEmail;
        private TextBox txtSupplierName;
        private Label label4;
        private Label label2;
        private Label label5;
        private Label label3;
        private Button btnReturnSupplier;
        private Button btnDelete;
        private Label label1;
        private DataGridView dgvSupplier;
    }
}