﻿namespace SupermarketManagementSystem
{
    partial class ModifyProductForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvProductInventory = new DataGridView();
            label1 = new Label();
            label2 = new Label();
            cboCategory = new ComboBox();
            txtImageURL = new TextBox();
            txtStockLevel2 = new TextBox();
            txtPrice2 = new TextBox();
            txtDescription2 = new TextBox();
            txtName = new TextBox();
            label14 = new Label();
            label13 = new Label();
            label12 = new Label();
            label11 = new Label();
            label10 = new Label();
            lblProductImage = new Label();
            pictureBoxImage = new PictureBox();
            btnSaveChange = new Button();
            btnReturn = new Button();
            label3 = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvProductInventory).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxImage).BeginInit();
            SuspendLayout();
            // 
            // dgvProductInventory
            // 
            dgvProductInventory.CellBorderStyle = DataGridViewCellBorderStyle.Raised;
            dgvProductInventory.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvProductInventory.Location = new Point(12, 89);
            dgvProductInventory.Name = "dgvProductInventory";
            dgvProductInventory.ReadOnly = true;
            dgvProductInventory.RowHeadersWidth = 51;
            dgvProductInventory.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvProductInventory.Size = new Size(789, 261);
            dgvProductInventory.TabIndex = 1;
            dgvProductInventory.SelectionChanged += dgvProductInventory_SelectionChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.SeaShell;
            label1.Font = new Font("Segoe UI Black", 13F, FontStyle.Bold);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(532, 9);
            label1.Name = "label1";
            label1.Size = new Size(321, 30);
            label1.TabIndex = 2;
            label1.Text = "Modify Product by Category";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Cyan;
            label2.Font = new Font("Segoe UI Black", 11F, FontStyle.Bold);
            label2.ForeColor = Color.Black;
            label2.Location = new Point(12, 58);
            label2.Name = "label2";
            label2.Size = new Size(300, 25);
            label2.TabIndex = 3;
            label2.Text = "Searching Product by Category";
            // 
            // cboCategory
            // 
            cboCategory.BackColor = SystemColors.ControlLightLight;
            cboCategory.DropDownWidth = 260;
            cboCategory.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            cboCategory.FormattingEnabled = true;
            cboCategory.Location = new Point(318, 55);
            cboCategory.Name = "cboCategory";
            cboCategory.Size = new Size(250, 31);
            cboCategory.TabIndex = 4;
            cboCategory.SelectedIndexChanged += cboCategory_SelectedIndexChanged;
            // 
            // txtImageURL
            // 
            txtImageURL.BackColor = SystemColors.ControlLightLight;
            txtImageURL.Location = new Point(946, 254);
            txtImageURL.Name = "txtImageURL";
            txtImageURL.Size = new Size(291, 27);
            txtImageURL.TabIndex = 47;
            // 
            // txtStockLevel2
            // 
            txtStockLevel2.BackColor = SystemColors.ControlLightLight;
            txtStockLevel2.Location = new Point(946, 214);
            txtStockLevel2.Name = "txtStockLevel2";
            txtStockLevel2.Size = new Size(291, 27);
            txtStockLevel2.TabIndex = 46;
            // 
            // txtPrice2
            // 
            txtPrice2.BackColor = SystemColors.ControlLightLight;
            txtPrice2.Location = new Point(946, 179);
            txtPrice2.Name = "txtPrice2";
            txtPrice2.Size = new Size(291, 27);
            txtPrice2.TabIndex = 45;
            // 
            // txtDescription2
            // 
            txtDescription2.BackColor = SystemColors.ControlLightLight;
            txtDescription2.Location = new Point(946, 144);
            txtDescription2.Name = "txtDescription2";
            txtDescription2.Size = new Size(291, 27);
            txtDescription2.TabIndex = 44;
            // 
            // txtName
            // 
            txtName.BackColor = SystemColors.ControlLightLight;
            txtName.Location = new Point(946, 111);
            txtName.Name = "txtName";
            txtName.ReadOnly = true;
            txtName.Size = new Size(291, 27);
            txtName.TabIndex = 43;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold);
            label14.Location = new Point(836, 261);
            label14.Name = "label14";
            label14.Size = new Size(102, 20);
            label14.TabIndex = 42;
            label14.Text = "ImageURL:";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold);
            label13.Location = new Point(828, 221);
            label13.Name = "label13";
            label13.Size = new Size(113, 20);
            label13.TabIndex = 41;
            label13.Text = "Stock Level:";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold);
            label12.Location = new Point(836, 186);
            label12.Name = "label12";
            label12.Size = new Size(59, 20);
            label12.TabIndex = 40;
            label12.Text = "Price:";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold);
            label11.Location = new Point(828, 149);
            label11.Name = "label11";
            label11.Size = new Size(112, 20);
            label11.TabIndex = 39;
            label11.Text = "Description:";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold);
            label10.Location = new Point(828, 114);
            label10.Name = "label10";
            label10.Size = new Size(63, 20);
            label10.TabIndex = 38;
            label10.Text = "Name:";
            // 
            // lblProductImage
            // 
            lblProductImage.AutoSize = true;
            lblProductImage.BackColor = Color.Cyan;
            lblProductImage.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblProductImage.Location = new Point(107, 362);
            lblProductImage.Name = "lblProductImage";
            lblProductImage.Size = new Size(128, 23);
            lblProductImage.TabIndex = 37;
            lblProductImage.Text = "Product Image";
            // 
            // pictureBoxImage
            // 
            pictureBoxImage.Location = new Point(12, 388);
            pictureBoxImage.Name = "pictureBoxImage";
            pictureBoxImage.Size = new Size(377, 248);
            pictureBoxImage.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBoxImage.TabIndex = 36;
            pictureBoxImage.TabStop = false;
            // 
            // btnSaveChange
            // 
            btnSaveChange.BackColor = Color.Lime;
            btnSaveChange.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnSaveChange.Location = new Point(880, 316);
            btnSaveChange.Name = "btnSaveChange";
            btnSaveChange.Size = new Size(161, 43);
            btnSaveChange.TabIndex = 48;
            btnSaveChange.Text = "Save Changes";
            btnSaveChange.UseVisualStyleBackColor = false;
            btnSaveChange.Click += btnSaveChange_Click;
            // 
            // btnReturn
            // 
            btnReturn.BackColor = Color.Red;
            btnReturn.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btnReturn.ForeColor = SystemColors.ButtonHighlight;
            btnReturn.Location = new Point(1081, 316);
            btnReturn.Name = "btnReturn";
            btnReturn.Size = new Size(169, 43);
            btnReturn.TabIndex = 49;
            btnReturn.Text = "Return Product Form";
            btnReturn.UseVisualStyleBackColor = false;
            btnReturn.Click += btnReturn_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.DarkBlue;
            label3.Font = new Font("Segoe UI Black", 11F, FontStyle.Bold);
            label3.ForeColor = Color.White;
            label3.Location = new Point(1009, 61);
            label3.Name = "label3";
            label3.Size = new Size(158, 25);
            label3.TabIndex = 50;
            label3.Text = "Modify Product";
            // 
            // ModifyProductForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Coral;
            ClientSize = new Size(1288, 648);
            Controls.Add(label3);
            Controls.Add(btnReturn);
            Controls.Add(btnSaveChange);
            Controls.Add(txtImageURL);
            Controls.Add(txtStockLevel2);
            Controls.Add(txtPrice2);
            Controls.Add(txtDescription2);
            Controls.Add(txtName);
            Controls.Add(label14);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(lblProductImage);
            Controls.Add(pictureBoxImage);
            Controls.Add(cboCategory);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(dgvProductInventory);
            Name = "ModifyProductForm";
            Text = "ModifyProductForm";
            Load += ModifyProductForm_Load;
            ((System.ComponentModel.ISupportInitialize)dgvProductInventory).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxImage).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgvProductInventory;
        private Label label1;
        private Label label2;
        private ComboBox cboCategory;
        private TextBox txtImageURL;
        private TextBox txtStockLevel2;
        private TextBox txtPrice2;
        private TextBox txtDescription2;
        private TextBox txtName;
        private Label label14;
        private Label label13;
        private Label label12;
        private Label label11;
        private Label label10;
        private Label lblProductImage;
        private PictureBox pictureBoxImage;
        private Button btnSaveChange;
        private Button btnReturn;
        private Label label3;
    }
}